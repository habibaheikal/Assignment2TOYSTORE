var DIGIOH_CACHE_VERSION = CACHE_VERSION || '';

var bodInsert = "<div id='layout'></div>";
bodInsert += "<div id='modal_loading'><div id='modal_loading_spinner'></div></div>";
bodInsert += "<span style='display: none;' class='error-bubble' id='error_bubble'>";
bodInsert += "<span class='error-message' id='error_message'></span>";
bodInsert += "<span id='error_close'>x</span>";
bodInsert += "</span>";

var ie9 = "<!--[if lte IE 9]>";
ie9 += "<scr";
ie9 += "ipt type='text/javascript'>";
ie9 += "IS_IE_9_OR_LESS = true;";
ie9 += "<";
ie9 += "/scr" + "ipt>";
ie9 += "<![endif]-->";

PROTOCOL_USER_OVERRIDE = PROTOCOL_USER_OVERRIDE || "https://";

var loaderBg = "#modal_loading{display:none;position:fixed;z-index:90000;top:0;left:0;height:100%;width:100%;background:rgba(255,255,255,.8)}";
var loaderCss = "#modal_loading_spinner{position:fixed;z-index:90001;color:#0078d7;font-size:15px;margin:0;width:1em;height:1em;border-radius:50%;text-indent:-9999em;-webkit-animation:load4 1.3s infinite linear;animation:load4 1.3s infinite linear;-webkit-transform:translateZ(0);-ms-transform:translateZ(0);transform:translateZ(0)}@-webkit-keyframes load4{0%,100%{box-shadow:0 -3em 0 .2em,2em -2em 0 0,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 0}12.5%{box-shadow:0 -3em 0 0,2em -2em 0 .2em,3em 0 0 0,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 -1em}25%{box-shadow:0 -3em 0 -.5em,2em -2em 0 0,3em 0 0 .2em,2em 2em 0 0,0 3em 0 -1em,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 -1em}37.5%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 0,2em 2em 0 .2em,0 3em 0 0,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 -1em}50%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 0,0 3em 0 .2em,-2em 2em 0 0,-3em 0 0 -1em,-2em -2em 0 -1em}62.5%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 0,-2em 2em 0 .2em,-3em 0 0 0,-2em -2em 0 -1em}75%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 0,-3em 0 0 .2em,-2em -2em 0 0}87.5%{box-shadow:0 -3em 0 0,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 0,-3em 0 0 0,-2em -2em 0 .2em}}@keyframes load4{0%,100%{box-shadow:0 -3em 0 .2em,2em -2em 0 0,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 0}12.5%{box-shadow:0 -3em 0 0,2em -2em 0 .2em,3em 0 0 0,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 -1em}25%{box-shadow:0 -3em 0 -.5em,2em -2em 0 0,3em 0 0 .2em,2em 2em 0 0,0 3em 0 -1em,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 -1em}37.5%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 0,2em 2em 0 .2em,0 3em 0 0,-2em 2em 0 -1em,-3em 0 0 -1em,-2em -2em 0 -1em}50%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 0,0 3em 0 .2em,-2em 2em 0 0,-3em 0 0 -1em,-2em -2em 0 -1em}62.5%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 0,-2em 2em 0 .2em,-3em 0 0 0,-2em -2em 0 -1em}75%{box-shadow:0 -3em 0 -1em,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 0,-3em 0 0 .2em,-2em -2em 0 0}87.5%{box-shadow:0 -3em 0 0,2em -2em 0 -1em,3em 0 0 -1em,2em 2em 0 -1em,0 3em 0 -1em,-2em 2em 0 0,-3em 0 0 0,-2em -2em 0 .2em}}";
var loaderImg = "#modal_loading{display:none;position:fixed;z-index:90000;top:0;left:0;height:100%;width:100%;background:url(" + PROTOCOL_USER_OVERRIDE + "www.lightboxcdn.com/static/loading_animation.gif) 50% 50% no-repeat rgba(255,255,255,.8)}";
var pgStyle = "<style type='text/css'>.hidden_until_loaded, .hidden_until_loaded body, .hidden_until_loaded div {visibility: hidden !important;} body{margin:0;padding:0;border:none;}.error-bubble{-webkit-border-radius:3px;-moz-border-radius:3px;-ms-border-radius:3px;-o-border-radius:3px;border-radius:3px;padding:12px 15px;margin:0;text-align:left;position:fixed;top:30px;left:30px;color:red;background-color:#fff4f4;border:1px solid #d58a8a;font-size:13px;line-height:18px;font-family:'Open Sans','lucida grande','Segoe UI',arial,verdana,'lucida sans unicode',tahoma,sans-serif;z-index:10001;white-space:nowrap;font-weight:400}.error-bubble .error-message{color:#d58a8a;font-size:inherit;line-height:inherit}.error-message{color:#dd3b38;font-size:10px}#error_close{color:#dd3b38;font-size:18px;font-weight:700;display:inline-block;float:right;cursor:pointer;margin-top:-2px}.error-bubble .error-bubble-arrow-border{display:block;border-color:#d58a8a transparent transparent;border-style:solid;border-width:6px;height:0;width:0;position:absolute;bottom:-13px;left:10px}" + loaderCss + loaderBg + "body.loading{overflow:hidden}body.loading #modal_loading{display:block}</style>";
pgStyle += "<style id='element_styles' type='text/css'></style>";

var html_ele = document.getElementsByTagName("html")[0];
if (typeof html_ele.classList === 'object' && html_ele.classList !== null)
    html_ele.classList.add("hidden_until_loaded");

var basic_fonts = ["Arial, Helvetica, sans-serif", "'Comic Sans MS', cursive, sans-serif", "'lucida sans unicode', 'Lucida Grande', sans-serif", "Tahoma, Geneva, sans-serif", "Verdana, Geneva, sans-serif", "'Courier New', Courier, monospace", "'Lucida Console', Monaco, monospace", "'Trebuchet MS', Helvetica, sans-serif", "Impact, Charcoal, sans-serif"];
var google_fonts = [];
var custom_fonts = [];

var TIME_OF_OPEN = (new Date()).getTime();

var KEEN_CLIENT;
var EVENT_GUID = '';
var IS_SETTINGS_LOADED = false;
var IS_SCRIPTS_LOADED = false;
var BOX_CUSTOM_JS = {};

var LIGHTBOX_OR_VARIATION_GUID = '';

var STANDARD_OBJ = {};

var CUSTOM_JS_GUIDS_ARR = [];
var CUSTOM_JS_BOX_EMBED = {};

var CJSAPPS_ARR = [];
var CJSAPPS_BOXES = {};

var COUPONS_FOR_SUBMIT = {};
var COUPONS_FOR_DISPLAY = {};

var CURRENT_PAGE = 'main';
var CURRENT_WIDTH = 0;
var CURRENT_HEIGHT = 0;

var wasErrorBubbleAlreadyClosed = false;

var BugsnagInitAttempts = 0;

var processSubmitLock = false;

var hasAfterDomReadyJsFinished = false;

var settings;

var body;
var modal_loading;
var error_bubble;
var error_message;

var image_dims = {};

//Forms
var form_wrapper;
var form;
var thx_form_wrapper;
var thx_form;
var ep1_form_wrapper;
var ep1_form;
var ep2_form_wrapper;
var ep2_form;
var ep3_form_wrapper;
var ep3_form;
var ep4_form_wrapper;
var ep4_form;

//Form Values
var form_input_obj = {};


var pref_form_input_full_name = false;
var pref_form_input_first_name = false;
var pref_form_input_last_name = false;
var pref_form_input_email = false;
var pref_form_input_phone = false;
var pref_form_input_opt_in = false;

var pref_form_input_customN = false;

var form_input_full_name;
var form_input_first_name;
var form_input_last_name;
var form_input_email;
var form_input_phone;
var form_input_opt_in;

var thx_form_input_full_name;
var thx_form_input_first_name;
var thx_form_input_last_name;
var thx_form_input_email;
var thx_form_input_phone;
var thx_form_input_opt_in;

var ep1_form_input_full_name;
var ep1_form_input_first_name;
var ep1_form_input_last_name;
var ep1_form_input_email;
var ep1_form_input_phone;
var ep1_form_input_opt_in;

var ep2_form_input_full_name;
var ep2_form_input_first_name;
var ep2_form_input_last_name;
var ep2_form_input_email;
var ep2_form_input_phone;
var ep2_form_input_opt_in;

var ep3_form_input_full_name;
var ep3_form_input_first_name;
var ep3_form_input_last_name;
var ep3_form_input_email;
var ep3_form_input_phone;
var ep3_form_input_opt_in;

var ep4_form_input_full_name;
var ep4_form_input_first_name;
var ep4_form_input_last_name;
var ep4_form_input_email;
var ep4_form_input_phone;
var ep4_form_input_opt_in;

var using_form = false;
var using_form_thx = false;
var using_form_ep1 = false;
var using_form_ep2 = false;
var using_form_ep3 = false;
var using_form_ep4 = false;

var IsDatepickerScriptLoaded = false;
var IsDatepickerScriptLoading = false;

var jQuery = {};
var $ = {};

var AfterDomLoadedHasRun = false;
var BuiltExtraPageStyles = {};
var LoadedCustomFonts = {};
var LoadedPageImages = {};
var ImageSrcMap = {};


window.jQuery = function(selector) {
    return parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(selector, document);
};
jQuery = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH.extend(jQuery, parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH);
window.$ = window.jQuery;
$ = jQuery;


if (!String.prototype.trim) {
    String.prototype.trim = function() {
        return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
    };
}


var boxapi = {};

boxapi.showPage = function(pageName) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", "ep4", ....
        //changePages('thx_', ptn, prop, 'button');
        if (CURRENT_PAGE !== pageName)
            changePages(pageName, '', {}, 'api');
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.showPage");
    }
};

boxapi.changePages = boxapi.showPage;
boxapi.changePage = boxapi.showPage;

boxapi.showMainPage = function() {
    boxapi.showPage("main");
};

boxapi.showThankYouPage = function() {
    boxapi.showPage("thx");
};

boxapi.showExtraPage = function(pageNumber) {
    boxapi.showPage("ep" + pageNumber);
};

boxapi.isMainPage = function() {
    return CURRENT_PAGE === "main" || CURRENT_PAGE === "";
};

boxapi.isThankYouPage = function() {
    return CURRENT_PAGE === "thx" || CURRENT_PAGE === "thx_";
};

boxapi.isExtraPage = function(pageNumber) {
    return CURRENT_PAGE === ("ep" + pageNumber) || CURRENT_PAGE === ("ep" + pageNumber + "_");
};

boxapi.getPageName = function() {
    var cp = CURRENT_PAGE || 'main';
    return cp.replace('_', '');
};

boxapi.processSubmit = function(obj) {
    try {
        //processSubmit(pref, hideLoadingSpinner, bypassCoupons, useSubmitLock) 

        if (typeof obj !== 'object' || obj === null)
            obj = {};

        processSubmitObj(obj);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.processSubmit");
    }
};

boxapi.showLoading = function() {
    showLoading(CURRENT_PAGE);
};

boxapi.hideLoading = function() {
    hideLoading();
};

boxapi.showError = function(errorMsg) {
    showError(errorMsg);
};

boxapi.showInlineError = function(errorMsg, fieldName, obj) {
    var pref = CURRENT_PAGE;
    if (obj && obj.hasOwnProperty('pageName'))
        pref = obj.pageName;

    showInlineError(pref, fieldName, errorMsg);
};

boxapi.addBoxIntegration = function(integrationId) {
    parent.DIGIOH_API.addBoxIntegration(LIGHTBOX_GUID, integrationId);
};

boxapi.removeBoxIntegration = function(integrationId) {
    parent.DIGIOH_API.removeBoxIntegration(LIGHTBOX_GUID, integrationId);
};

boxapi.resetBoxIntegrations = function() {
    parent.DIGIOH_API.resetBoxIntegrations(LIGHTBOX_GUID);
};

boxapi.trackManualRedirect = function() {
    parent.DIGIOH_API.LIGHTBOX.registerAnalyticsManualRedirect(LIGHTBOX_GUID);
};

boxapi.getBoxType = function() {
    return parent.DIGIOH_API.getBoxType(LIGHTBOX_GUID);
};

boxapi.closeBox = function() {
    parent.DIGIOH_API.closeBox(LIGHTBOX_GUID);
};

boxapi.reloadWebPage = function(obj) {
    var delay = 0;
    if (obj && typeof obj === 'object' && obj.hasOwnProperty('delayMsecs'))
        delay = obj.delayMsecs;

    if (delay > 0) {
        setTimeout(function() {
            parent.location.reload();
        }, delay);
    } else {
        parent.location.reload();
    }
};

boxapi.scrollHandlerPreventDefault = function(e) {
    //helper function
    e.preventDefault();
};

boxapi.disableScroll = function() {
    if (parent.DIGIOH_API.isMobile())
        parent.document.addEventListener('touchmove', boxapi.scrollHandlerPreventDefault, {
            passive: false
        });
    else
        parent.document.addEventListener('scroll', boxapi.scrollHandlerPreventDefault, {
            passive: false
        });
};

boxapi.enableScroll = function() {
    if (parent.DIGIOH_API.isMobile())
        parent.document.removeEventListener('touchmove', boxapi.scrollHandlerPreventDefault, {
            passive: false
        });
    else
        parent.document.removeEventListener('scroll', boxapi.scrollHandlerPreventDefault, {
            passive: false
        });
};

boxapi.getFormFieldValue = function(fieldName, obj) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        var pref = CURRENT_PAGE;
        if (obj && typeof obj === 'object' && obj.hasOwnProperty('pageName'))
            pref = obj.pageName;

        pref = getUnfriendlyPagePrefix(pref);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        //form_input_first_name
        //form_input_full_name
        //form_input_first_name, form_input_last_name

        if (fieldName === 'name') {
            if ($('#' + pref + 'form_input_first_and_last_name_wrapper').length)
                return ($('#' + pref + 'form_input_first_name').val() + ' ' + $('#' + pref + 'form_input_last_name').val()).trim();
            if ($('#' + pref + 'form_input_full_name_wrapper').length)
                return $('#' + pref + 'form_input_full_name').val();
            if ($('#' + pref + 'form_input_first_name_wrapper').length)
                return $('#' + pref + 'form_input_first_name').val();
        } else if (fieldName === 'opt_in') {
            if (document.getElementById(pref + 'form_input_opt_in').checked)
                return '1';
            else
                return '0';
        } else if (settings[pref + fieldName].field_type === 'checkbox' && $('#' + pref + 'form_input_' + fieldName + '_checkbox_wrapper').length) {
            if (document.getElementById(pref + 'form_input_' + fieldName).checked)
                return settings[pref + fieldName].checkbox.checkedval;
            else
                return settings[pref + fieldName].checkbox.uncheckedval;
        } else if (settings[pref + fieldName].field_type === 'radio' && $('#' + pref + 'form_input_' + fieldName + '_radio_wrapper').length) {
            if ($('input[name="' + pref + 'form_input_' + fieldName + '"]:checked').length)
                return $('input[name="' + pref + 'form_input_' + fieldName + '"]:checked').val();
            else
                return '';
        } else if (settings[pref + fieldName].field_type === 'datedrop' && $('#' + pref + 'form_input_' + fieldName + '_datedrop_mm').length) {
            return $('#' + pref + 'form_input_' + fieldName + '_datedrop_mm').val() + '/' + $('#' + pref + 'form_input_' + fieldName + '_datedrop_dd').val() + '/' + $('#' + pref + 'form_input_' + fieldName + '_datedrop_yyyy').val();
        } else if ($('#' + pref + 'form_input_' + fieldName).length) {
            return $('#' + pref + 'form_input_' + fieldName).val();
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.getFormFieldValue");
    }

    return '';
};

boxapi.setFormFieldValue = function(fieldName, val, obj) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        var pref = CURRENT_PAGE;
        if (obj && typeof obj === 'object' && obj.hasOwnProperty('pageName'))
            pref = obj.pageName;

        pref = getUnfriendlyPagePrefix(pref);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        //form_input_first_name
        //form_input_full_name
        //form_input_first_name, form_input_last_name

        if (fieldName === 'name') {
            if ($('#' + pref + 'form_input_first_and_last_name_wrapper').length) {
                if (val.indexOf(' ') > 0) {
                    var fn = val.split(' ')[0];
                    $('#' + pref + 'form_input_first_name').val(fn);
                    $('#' + pref + 'form_input_last_name').val(val.substr(fn.length).trim());
                } else {
                    $('#' + pref + 'form_input_first_name').val(val);
                }
            }
            if ($('#' + pref + 'form_input_full_name_wrapper').length)
                $('#' + pref + 'form_input_full_name').val(val);
            if ($('#' + pref + 'form_input_first_name_wrapper').length)
                $('#' + pref + 'form_input_first_name').val(val);
        } else if (fieldName === 'opt_in') {
            if (val === true || val === '1' || val === 1 || val === 'on' || val === 'yes' || val === 'checked' || val === 'selected')
                document.getElementById(pref + 'form_input_opt_in').checked = true;
            else
                document.getElementById(pref + 'form_input_opt_in').checked = false;
        } else if (settings[pref + fieldName].field_type === 'checkbox' && $('#' + pref + 'form_input_' + fieldName + '_checkbox_wrapper').length) {
            if (val == settings[pref + fieldName].checkbox.uncheckedval)
                document.getElementById(pref + 'form_input_' + fieldName).checked = false;
            else if (val == settings[pref + fieldName].checkbox.checkedval || val === true || val === '1' || val === 1 || val === 'on' || val === 'yes' || val === 'checked' || val === 'selected')
                document.getElementById(pref + 'form_input_' + fieldName).checked = true;
            else
                document.getElementById(pref + 'form_input_' + fieldName).checked = false;
        } else if (settings[pref + fieldName].field_type === 'radio' && $('#' + pref + 'form_input_' + fieldName + '_radio_wrapper').length) {
            if ($('input[name="' + pref + 'form_input_' + fieldName + '"]').length) {
                $('input[name="' + pref + 'form_input_' + fieldName + '"]').each(function() {
                    if ($(this).attr('value') === val) {
                        $(this).prop("checked", true);
                    }
                });
            }
        } else if (settings[pref + fieldName].field_type === 'datedrop' && $('#' + pref + 'form_input_' + fieldName + '_datedrop_mm').length) {
            var parts = val.split('/');
            if (parts.length === 3) {
                $('#' + pref + 'form_input_' + fieldName + '_datedrop_mm').val(parts[0]);
                $('#' + pref + 'form_input_' + fieldName + '_datedrop_dd').val(parts[1]);
                $('#' + pref + 'form_input_' + fieldName + '_datedrop_yyyy').val(parts[2]);
            }
        } else if ($('#' + pref + 'form_input_' + fieldName).length) {
            $('#' + pref + 'form_input_' + fieldName).val(val);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.setFormFieldValue");
    }
};

boxapi.hideFormField = function(fieldName, obj) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        var pref = CURRENT_PAGE;
        if (obj && typeof obj === 'object' && obj.hasOwnProperty('pageName'))
            pref = obj.pageName;

        pref = getUnfriendlyPagePrefix(pref);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        if (fieldName === 'name' || fieldName.indexOf('_name') > 0) {
            if ($('#' + pref + 'form_input_first_and_last_name_wrapper').length)
                $('#' + pref + 'form_input_first_and_last_name_wrapper').hide();
            if ($('#' + pref + 'form_input_full_name_wrapper').length)
                $('#' + pref + 'form_input_full_name_wrapper').hide();
            if ($('#' + pref + 'form_input_first_name_wrapper').length)
                $('#' + pref + 'form_input_first_name_wrapper').hide();
        } else if (settings[pref + fieldName].field_type === 'checkbox' && $('#' + pref + 'form_input_' + fieldName + '_checkbox_wrapper').length) {
            $('#' + pref + 'form_input_' + fieldName + '_checkbox_wrapper').hide();
        } else if (settings[pref + fieldName].field_type === 'radio' && $('#' + pref + 'form_input_' + fieldName + '_radio_wrapper').length) {
            $('#' + pref + 'form_input_' + fieldName + '_radio_wrapper').hide();
        } else if ($('#' + pref + 'form_input_' + fieldName + '_wrapper').length) {
            $('#' + pref + 'form_input_' + fieldName + '_wrapper').hide();
        }

        if ($('#' + pref + 'form_label_' + fieldName).length) {
            $('#' + pref + 'form_label_' + fieldName).hide();
        }

        if (settings[pref + fieldName].require) {
            settings[pref + fieldName].require = false;
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.hideFormField");
    }
};

boxapi.showFormField = function(fieldName, obj) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        var pref = CURRENT_PAGE;
        if (obj && typeof obj === 'object' && obj.hasOwnProperty('pageName'))
            pref = obj.pageName;

        pref = getUnfriendlyPagePrefix(pref);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        //form_input_first_and_last_name_wrapper (form_input_first_name_wrapper, form_input_last_name_wrapper)
        //form_input_full_name_wrapper
        //form_input_first_name_wrapper
        //form_label_name (in all 3 cases)

        if (fieldName === 'name' || fieldName.indexOf('_name') > 0) {
            if ($('#' + pref + 'form_input_first_and_last_name_wrapper').length)
                $('#' + pref + 'form_input_first_and_last_name_wrapper').show();
            if ($('#' + pref + 'form_input_full_name_wrapper').length)
                $('#' + pref + 'form_input_full_name_wrapper').show();
            if ($('#' + pref + 'form_input_first_name_wrapper').length)
                $('#' + pref + 'form_input_first_name_wrapper').show();
        } else if (settings[pref + fieldName].field_type === 'checkbox' && $('#' + pref + 'form_input_' + fieldName + '_checkbox_wrapper').length) {
            $('#' + pref + 'form_input_' + fieldName + '_checkbox_wrapper').show();
        } else if (settings[pref + fieldName].field_type === 'radio' && $('#' + pref + 'form_input_' + fieldName + '_radio_wrapper').length) {
            $('#' + pref + 'form_input_' + fieldName + '_radio_wrapper').show();
        } else if ($('#' + pref + 'form_input_' + fieldName + '_wrapper').length) {
            $('#' + pref + 'form_input_' + fieldName + '_wrapper').show();
        }

        if ($('#' + pref + 'form_label_' + fieldName).length) {
            $('#' + pref + 'form_label_' + fieldName).show();
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.showFormField");
    }
};

boxapi.getId = function() {
    return STANDARD_OBJ.lightbox_short_id;
};

boxapi.getGuid = function() {
    return STANDARD_OBJ.lightbox_guid;
};

boxapi.getName = function() {
    return STANDARD_OBJ.lightbox_name;
};

boxapi.logEvent = function(data, options) {
    try {
        if (!data || typeof data !== 'object')
            data = {};

        data.box_id = boxapi.getId();
        data.box_guid = boxapi.getGuid();
        data.box_name = boxapi.getName();

        data.is_variation = STANDARD_OBJ.is_variation;
        data.variation_id = STANDARD_OBJ.variation_short_id;
        data.variation_guid = STANDARD_OBJ.variation_guid;
        data.variation_name = STANDARD_OBJ.variation_name;

        data.ab_test_id = STANDARD_OBJ.ab_test_short_id;
        data.ab_test_guid = STANDARD_OBJ.ab_test_guid;
        data.ab_test_name = STANDARD_OBJ.ab_test_name;

        parent.DIGIOH_API.logEvent(data, options);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.logEvent");
    }
};

boxapi.trim = function(str) {
    return parent.DIGIOH_API.trim(str);
};

boxapi.contains = function(obj, val) {
    return parent.DIGIOH_API.contains(obj, val);
};

boxapi.remove = function(obj, valToRemove) {
    return parent.DIGIOH_API.remove(obj, valToRemove);
};

boxapi.getBoxFrameWrapper = function() {
    try {
        return parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH('#' + parent.DIGIOH_API.LIGHTBOX.getLightboxDomId(boxapi.getGuid()));
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.getBoxFrameWrapper");
        return null;
    }
};

boxapi.addDropdownOption = function(fieldName, submitVal, displayVal, obj) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        var pref = CURRENT_PAGE;
        if (obj && typeof obj === 'object' && obj.hasOwnProperty('pageName'))
            pref = obj.pageName;

        pref = getUnfriendlyPagePrefix(pref);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        if ($('#' + pref + 'form_input_' + fieldName).length && $('#' + pref + 'form_input_' + fieldName).is("select")) {
            $('#' + pref + 'form_input_' + fieldName).append(new Option(displayVal, submitVal));
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.addDropdownOption");
    }
};

boxapi.removeDropdownOption = function(fieldName, submitVal, obj) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        var pref = CURRENT_PAGE;
        if (obj && typeof obj === 'object' && obj.hasOwnProperty('pageName'))
            pref = obj.pageName;

        pref = getUnfriendlyPagePrefix(pref);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        if ($('#' + pref + 'form_input_' + fieldName).length && $('#' + pref + 'form_input_' + fieldName).is("select")) {
            $('#' + pref + 'form_input_' + fieldName + " option[value='" + submitVal + "']").each(function() {
                $(this).remove();
            });
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.removeDropdownOption");
    }
};

boxapi.removeAllDropdownOptions = function(fieldName, obj) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        var pref = CURRENT_PAGE;
        if (obj && typeof obj === 'object' && obj.hasOwnProperty('pageName'))
            pref = obj.pageName;

        pref = getUnfriendlyPagePrefix(pref);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        if ($('#' + pref + 'form_input_' + fieldName).length && $('#' + pref + 'form_input_' + fieldName).is("select")) {
            $('#' + pref + 'form_input_' + fieldName + " option").each(function() {
                $(this).remove();
            });
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.removeAllDropdownOptions");
    }
};


boxapi.getAccountMetadata = function(key) {
    return parent.DIGIOH_API.getAccountMetadata(key);
};


boxapi.getWidgetMetadata = function(key) {
    return parent.DIGIOH_API.getWidgetMetadata(boxapi.getId().toString(), key);
};


boxapi.getPageMetadata = function(pageName, key) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"

        if (!pageName)
            pageName = CURRENT_PAGE;

        if (pageName === 'main')
            pageName = '';

        if (settings.hasOwnProperty(pageName + 'layout') && settings[pageName + 'layout'].hasOwnProperty('metadata_kvps')) {
            if (typeof key !== 'string' || !key)
                return settings[pageName + 'layout'].metadata_kvps;

            for (var i = 0; i < settings[pageName + 'layout'].metadata_kvps.length; i++) {
                if (settings[pageName + 'layout'].metadata_kvps[i].k === key)
                    return settings[pageName + 'layout'].metadata_kvps[i].v;
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.getPageMetadata");
    }

    return null;
};

boxapi.getFieldMetadata = function(pageName, fieldName, key) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"
        //fieldName ==> "email", "phone", "opt_in", "custom7", "custom_7"

        if (!pageName)
            pageName = CURRENT_PAGE;

        if (pageName === 'main')
            pageName = '';

        if (!fieldName)
            return null;

        pageName = getUnfriendlyPagePrefix(pageName);

        if (fieldName.indexOf('custom') >= 0 && fieldName.indexOf('_') >= 0)
            fieldName = fieldName.split('_').join('');

        if (settings.hasOwnProperty(pageName + fieldName) && settings[pageName + fieldName].hasOwnProperty('metadata_kvps')) {
            if (typeof key !== 'string' || !key)
                return settings[pageName + fieldName].metadata_kvps;

            for (var i = 0; i < settings[pageName + fieldName].metadata_kvps.length; i++) {
                if (settings[pageName + fieldName].metadata_kvps[i].k === key)
                    return settings[pageName + fieldName].metadata_kvps[i].v;
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.getFieldMetadata");
    }

    return null;
};

boxapi.getElementMetadata = function(pageName, elementName, key) {
    try {
        //pageName ==> "main", "thx", "ep1", "ep2", "ep3", or "ep4"
        //elementName ==> "button1", "text7", "html2", etc

        if (!pageName)
            pageName = CURRENT_PAGE;

        if (pageName === 'main')
            pageName = '';

        if (!elementName)
            return null;

        if (settings.hasOwnProperty(pageName + elementName) && settings[pageName + elementName].hasOwnProperty('metadata_kvps')) {
            if (typeof key !== 'string' || !key)
                return settings[pageName + elementName].metadata_kvps;

            for (var i = 0; i < settings[pageName + elementName].metadata_kvps.length; i++) {
                if (settings[pageName + elementName].metadata_kvps[i].k === key)
                    return settings[pageName + elementName].metadata_kvps[i].v;
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "boxapi.getElementMetadata");
    }

    return null;
};




function checkJqLoaded() {
    onJqLoaded();
}

function onScriptsLoaded() {
    IS_SCRIPTS_LOADED = true;
    tryInitScripts();
    tryInitBugsnag();
}

function onJqLoaded() {
    if (typeof LIGHTBOX_GUID === 'undefined') {
        window.setTimeout(onJqLoaded, 100);
    } else {
        onVarsLoaded();
    }
}

function checkDocumentReadyState() {
    try {
        if (document.readyState === "complete" || document.readyState === "loaded" || document.readyState === "interactive") {
            afterDomLoaded();
        } else {
            setTimeout(checkDocumentReadyState, 250);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "checkDocumentReadyState");
    }
}

function afterDomLoaded() {
    try {
        if (!AfterDomLoadedHasRun) {
            AfterDomLoadedHasRun = true;

            $("html").attr("lang", "en");

            body = $('body');

            $('head').append(ie9);
            $('head').append(pgStyle);

            body.append(bodInsert);

            modal_loading = $('#modal_loading');
            error_bubble = $('#error_bubble');
            error_message = $('#error_message');

            $('#error_close').on(IS_MOBILE ? 'click' : 'mousedown', function() {
                error_bubble.hide();
                if (!wasErrorBubbleAlreadyClosed) {
                    wasErrorBubbleAlreadyClosed = true;
                    $(document).trigger('BOX_CLOSE_ERROR', ['', '', '']);
                    $('#error_message').removeAttr('role');
                }
            });


            try {
                parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(top).keyup(function(e) {
                    var code = (e.keyCode ? e.keyCode : e.which);

                    //ESC key pressed while focus is outside box, then close box
                    if (code == 27) {
                        postMessageCloseBox('button_click');
                    }
                });
            } catch (err) {

            }


            //Submit form when pressing the "Enter" key after tabbing/focusing on a button
            //Other actions can happen too, not just form submit.  (ie. close box, redirect, etc.)
            //Does not yet include the Download action.
            $(window).keyup(function(e) {
                var code = (e.keyCode ? e.keyCode : e.which);

                //ESC key pressed while focus is inside box, then close box
                if (code == 27) {
                    postMessageCloseBox('button_click');
                }

                if (code == 13) {
                    var pref = CURRENT_PAGE;
                    if (pref == 'main')
                        pref = '';

                    var foundMatch = false;
                    $('#' + pref + 'layout .button_focus_tab_submit').each(function() {
                        if (!foundMatch) {
                            foundMatch = true;
                            //if (pref == '') {
                            //    processSubmit(pref, false, false, true);
                            //} else if (pref.indexOf('_') === -1) {
                            //    processSubmit(pref + '_', false, false, true);
                            //}

                            var pr = pref;
                            if (pref && pref.length > 1 && pref.indexOf('_') === -1)
                                pr = pref + '_';

                            var btnId = $(this).attr('id'); //ep2button7

                            //fsdbx
                            if (btnId.indexOf('button') >= 0 && settings.hasOwnProperty(btnId))
                                setButtonMetaDataLayer(settings[btnId]);

                            if (btnId.indexOf('button') >= 0 && settings.hasOwnProperty(btnId) && settings[btnId].hasOwnProperty('override_form_submit_action') && settings[btnId].override_form_submit_action)
                                processSubmitObj({
                                    pageName: pr,
                                    overrideFormSubmitAction: settings[btnId].override_form_submit_action
                                });
                            else
                                processSubmit(pr, false, false, true);
                        }
                    });

                    $('#' + pref + 'layout .button_focus_tab_close').each(function() {
                        if (!foundMatch) {
                            foundMatch = true;
                            postMessageCloseBox('button_click');
                        }
                    });

                    $('#' + pref + 'layout .button_focus_tab_redirect').each(function() {
                        if (!foundMatch) {
                            foundMatch = true;

                            var ptn = $(this).attr('id');
                            if (ptn && settings.hasOwnProperty(ptn)) {
                                var prop = settings[ptn];
                                if (prop.url) {
                                    if (prop.url.toLowerCase().trim().indexOf('http') !== 0 && prop.url.toLowerCase().trim().indexOf('mailto') !== 0) {
                                        prop.url = 'http://' + prop.url;
                                    }

                                    if (!prop.hasOwnProperty('redirect_type') || !prop.redirect_type) {
                                        prop.redirect_type = 'current';
                                    }

                                    postMessageRedirectParent(prop, 'button');
                                }
                            }
                        }
                    });

                    $('#' + pref + 'layout .button_focus_tab_lightbox_open').each(function() {
                        if (!foundMatch) {
                            foundMatch = true;

                            var ptn = $(this).attr('id');
                            if (ptn && settings.hasOwnProperty(ptn)) {
                                var prop = settings[ptn];
                                if (prop.lightbox_open && prop.lightbox_open.length > 0) {
                                    postMessageOpenAnotherBox(prop, 'button');
                                }
                            }
                        }
                    });

                    $('#' + pref + 'layout .button_focus_tab_change_pages').each(function() {
                        if (!foundMatch) {
                            foundMatch = true;

                            var ptn = $(this).attr('id');
                            if (ptn && settings.hasOwnProperty(ptn)) {
                                var prop = settings[ptn];
                                if (prop.action == 'main_page') {
                                    changePages('', ptn, prop, 'button');
                                } else if (prop.action == 'thank_you_page') {
                                    changePages('thx_', ptn, prop, 'button');
                                } else if (prop.action.indexOf('extra_page_') == 0) {
                                    var pNum = prop.action.replace('extra_page_', '');
                                    changePages('ep' + pNum + '_', ptn, prop, 'button');
                                }
                            }
                        }
                    });
                }
            });

            tryApplySettings();
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, "afterDomLoaded");
    }
}

function getExtraPageNumberFromEPString(epStr) {
    var pNum = '';
    if (epStr.indexOf('ep') === 0) {
        for (var x = 2; x < epStr.length; x++) {
            if ('1234567890'.indexOf(epStr.substr(x, 1)) >= 0)
                pNum += epStr.substr(x, 1);
            else
                break;
        }
    }

    return pNum;
}

function onVarsLoaded() {
    DIGIOH_CACHE_VERSION = CACHE_VERSION;

    LIGHTBOX_OR_VARIATION_GUID = (IS_VARIATION ? VARIATION_GUID : LIGHTBOX_GUID);

    STANDARD_OBJ.protocol = PROTOCOL;
    STANDARD_OBJ.protocol_user_override = PROTOCOL_USER_OVERRIDE;
    STANDARD_OBJ.widget_type = WIDGET_TYPE;
    STANDARD_OBJ.cache_version = CACHE_VERSION;
    STANDARD_OBJ.parent_url = PARENT_URL;
    STANDARD_OBJ.full_url = FULL_URL || '';
    STANDARD_OBJ.use_bugsnag = DIGIOH_USE_BUGSNAG;
    STANDARD_OBJ.use_console = SHOW_ERRORS;
    STANDARD_OBJ.is_preview = IS_PREVIEW;
    STANDARD_OBJ.is_responsive = DIGIOH_USE_RESPONSIVE;
    STANDARD_OBJ.is_variation = IS_VARIATION;

    STANDARD_OBJ.user_id = VENDOR_GUID;
    STANDARD_OBJ.user_guid = VENDOR_GUID;
    STANDARD_OBJ.user_short_id = VENDOR_SHORT_ID;
    STANDARD_OBJ.vendor_id = VENDOR_GUID;
    STANDARD_OBJ.vendor_guid = VENDOR_GUID;
    STANDARD_OBJ.vendor_short_id = VENDOR_SHORT_ID;

    STANDARD_OBJ.client_id = CLIENT_GUID;
    STANDARD_OBJ.client_guid = CLIENT_GUID;

    STANDARD_OBJ.lightbox_id = LIGHTBOX_GUID;
    STANDARD_OBJ.lightbox_guid = LIGHTBOX_GUID;
    STANDARD_OBJ.lightbox_short_id = LIGHTBOX_SHORT_ID;
    STANDARD_OBJ.lightbox_name = LIGHTBOX_NAME;

    STANDARD_OBJ.variation_id = VARIATION_GUID;
    STANDARD_OBJ.variation_guid = VARIATION_GUID;
    STANDARD_OBJ.variation_short_id = VARIATION_SHORT_ID;
    STANDARD_OBJ.variation_name = VARIATION_NAME;

    STANDARD_OBJ.ab_test_id = AB_TEST_GUID;
    STANDARD_OBJ.ab_test_guid = AB_TEST_GUID;
    STANDARD_OBJ.ab_test_short_id = AB_TEST_SHORT_ID;
    STANDARD_OBJ.ab_test_name = AB_TEST_NAME;

    STANDARD_OBJ.lightbox_or_variation_id = LIGHTBOX_OR_VARIATION_GUID;
    STANDARD_OBJ.lightbox_or_variation_guid = LIGHTBOX_OR_VARIATION_GUID;
    STANDARD_OBJ.lightbox_or_variation_short_id = (IS_VARIATION ? VARIATION_SHORT_ID : LIGHTBOX_SHORT_ID);
    STANDARD_OBJ.lightbox_or_variation_name = (IS_VARIATION ? VARIATION_NAME : LIGHTBOX_NAME);

    STANDARD_OBJ.is_desktop = IS_DESKTOP;
    STANDARD_OBJ.is_phone = IS_PHONE;
    STANDARD_OBJ.is_tablet = IS_TABLET;
    STANDARD_OBJ.is_mobile = IS_MOBILE;

    var cjsRes = BOX_CUSTOM_JS.runCustomJsBeforeDOMReady();
    if (typeof cjsRes === 'boolean' && cjsRes === false) {
        sendMessageToParent({
            sender: "lightbox",
            parent_action: 'terminate_lightbox',
            lightbox_id: LIGHTBOX_OR_VARIATION_GUID
        });
    } else {
        onScriptsLoaded();

        $(document).ready(function() {
            //logger('$(document).ready ran for Box ' + LIGHTBOX_SHORT_ID);
            afterDomLoaded();
        });

        checkDocumentReadyState();
    }
}

function onResponsiveDimensionChange(obj) {
    try {
        if (IS_SETTINGS_LOADED && IS_SCRIPTS_LOADED) {
            var width = obj.width;
            var height = obj.height;
            //var widget_type = obj.widget_type;
            //logger('onResponsiveDimensionChange: ' + width + ' / ' + height);

            CURRENT_WIDTH = width;
            CURRENT_HEIGHT = height;

            var pref = '';
            if (CURRENT_PAGE && CURRENT_PAGE !== 'main') {
                pref = CURRENT_PAGE;
            }

            if (!settings.hasOwnProperty(pref + 'responsive') || !settings[pref + 'responsive'].use) {
                return;
            }

            var origBoxWidth = 700;
            var origBoxHeight = 500;

            if (settings.hasOwnProperty(pref + 'layout') && settings[pref + 'layout'].hasOwnProperty('width') && settings[pref + 'layout'].hasOwnProperty('height')) {
                origBoxWidth = settings[pref + 'layout'].width;
                origBoxHeight = settings[pref + 'layout'].height;
            } else {
                origBoxWidth = settings['layout'].width;
                origBoxHeight = settings['layout'].height;
            }

            var newBoxWidth = obj.width;
            var newBoxHeight = obj.height;

            if (DIGIOH_USE_RESPONSIVE) {
                if (newBoxWidth > settings[pref + 'responsive'].width_max)
                    newBoxWidth = settings[pref + 'responsive'].width_max;
                else if (newBoxWidth < settings[pref + 'responsive'].width_min)
                    newBoxWidth = settings[pref + 'responsive'].width_min;

                if (newBoxHeight > settings[pref + 'responsive'].height_max)
                    newBoxHeight = settings[pref + 'responsive'].height_max;
                else if (newBoxHeight < settings[pref + 'responsive'].height_min)
                    newBoxHeight = settings[pref + 'responsive'].height_min;
            } else {
                newBoxWidth = obj.width;
                newBoxHeight = origBoxHeight;
            }

            if (settings[pref + 'layout'].border.style === 'none' || settings[pref + 'layout'].border.width === '0' || settings[pref + 'layout'].border.width === 0) {
                newBoxWidth = newBoxWidth;
                newBoxHeight = newBoxHeight;
            } else {
                newBoxWidth = newBoxWidth - (2 * settings[pref + 'layout'].border.width);
                newBoxHeight = newBoxHeight - (2 * settings[pref + 'layout'].border.width);
            }

            var diffBoxWidth = newBoxWidth - origBoxWidth;
            var diffBoxHeight = newBoxHeight - origBoxHeight;

            var growthBoxWidth = diffBoxWidth / origBoxWidth;
            var growthBoxHeight = diffBoxHeight / origBoxHeight;

            $('#' + pref + 'layout').width(newBoxWidth);
            $('#' + pref + 'layout').height(newBoxHeight);

            var includeFilter = settings[pref + 'responsive'].include_filter || '';
            var excludeFilter = settings[pref + 'responsive'].exclude_filter || '';

            if (!DIGIOH_USE_RESPONSIVE) {
                includeFilter = '';
                excludeFilter = '';
            }

            //Text, Button, Image, Form


            for (var j = 0; j <= 4; j++) {
                var ele_type = '';
                if (j === 0) ele_type = 'html';
                if (j === 1) ele_type = 'text';
                if (j === 2) ele_type = 'button';
                if (j === 3) ele_type = 'image';
                if (j === 4) ele_type = 'form';

                for (var idx = 1; idx <= 50; idx++) {

                    var i = idx;
                    var pref_responsive = pref + 'responsive';

                    if (ele_type === 'form') {
                        if (idx < 50) {
                            continue;
                        } else {
                            i = '';
                            if (pref !== '') {
                                pref = pref + '_';
                            }
                            //logger(pref + ele_type);
                        }
                    }


                    if (!DIGIOH_USE_RESPONSIVE && settings.hasOwnProperty(pref + ele_type + i) && settings[pref + ele_type + i].display) {
                        var origElementWidth = settings[pref + ele_type + i].width;
                        var origElementHeight = settings[pref + ele_type + i].height;

                        var origElementLeft = settings[pref + ele_type + i].x;
                        var origElementTop = settings[pref + ele_type + i].y;

                        var newElementWidth = origElementWidth;
                        var newElementHeight = origElementHeight;

                        var newElementLeft = getNewElementLeft(pref_responsive, origElementLeft, origElementWidth, newElementWidth, origBoxWidth, newBoxWidth);
                        var newElementTop = getNewElementTop(pref_responsive, origElementTop, origElementHeight, newElementHeight, origBoxHeight, newBoxHeight);

                        var diffElementWidth = newElementWidth - origElementWidth;
                        var diffElementHeight = newElementHeight - origElementHeight;

                        $('#' + pref + ele_type + i + '_wrapper').css({
                            "left": newElementLeft + "px",
                            "top": newElementTop + "px",
                            "width": newElementWidth + "px",
                            "height": newElementHeight + "px"
                        });
                    } else if (DIGIOH_USE_RESPONSIVE && settings.hasOwnProperty(pref + ele_type + i) && settings[pref + ele_type + i].display && excludeFilter.indexOf(ele_type + i) === -1 && (settings[pref_responsive]['use_' + ele_type] || includeFilter.indexOf(ele_type + i) >= 0)) {
                        var elementWidthPct = settings[pref_responsive].content_width;
                        var elementHeightPct = settings[pref_responsive].content_height;
                        var elementFontPct = settings[pref_responsive].content_font;
                        var labelsFontPct = elementFontPct;
                        var inputsFontPct = elementFontPct;
                        var optInFontPct = 0;
                        var helpTextFontPct = 0;

                        var elementWidthMin = 0;
                        var elementHeightMin = 0;
                        var elementFontMin = 0;
                        var labelsFontMin = 0;
                        var inputsFontMin = 0;
                        var optInFontMin = 0;
                        var helpTextFontMin = 0;

                        var elementWidthMax = 10000;
                        var elementHeightMax = 10000;
                        var elementFontMax = 10000;
                        var labelsFontMax = 10000;
                        var inputsFontMax = 10000;
                        var optInFontMax = 10000;
                        var helpTextFontMax = 10000;

                        if (includeFilter.indexOf(ele_type + i) >= 0) {
                            var includeParts = includeFilter.split(/\r?\n/);
                            for (var x = 0; x < includeParts.length; x++) {
                                if (includeParts[x].indexOf('|') > 0 && includeParts[x].indexOf(':') > 0) {
                                    var elementNWHF = includeParts[x].split('|');

                                    var elementNameNum = '';
                                    var elementW = '';
                                    var elementH = '';
                                    var elementF = '';

                                    if (elementNWHF.length > 0)
                                        elementNameNum = elementNWHF[0];
                                    if (elementNWHF.length > 1)
                                        elementW = elementNWHF[1];
                                    if (elementNWHF.length > 2)
                                        elementH = elementNWHF[2];
                                    if (elementNWHF.length > 3)
                                        elementF = elementNWHF[3];

                                    var elementWparts = elementW.split(':');
                                    var elementHparts = elementH.split(':');
                                    var elementFparts = elementF.split(':');

                                    if (elementNameNum.trim() === (ele_type + i)) {
                                        if (elementWparts.length === 3) {
                                            elementWidthPct = parseInt(elementWparts[0].trim());
                                            elementWidthMin = parseInt(elementWparts[1].trim());
                                            elementWidthMax = parseInt(elementWparts[2].trim());
                                        }
                                        if (elementHparts.length === 3) {
                                            elementHeightPct = parseInt(elementHparts[0].trim());
                                            elementHeightMin = parseInt(elementHparts[1].trim());
                                            elementHeightMax = parseInt(elementHparts[2].trim());
                                        }
                                        if (elementFparts.length === 3) {
                                            elementFontPct = parseInt(elementFparts[0].trim());
                                            elementFontMin = parseInt(elementFparts[1].trim());
                                            elementFontMax = parseInt(elementFparts[2].trim());
                                        }
                                    } else if (elementNameNum.trim() === 'labels') {
                                        if (elementFparts.length === 3) {
                                            labelsFontPct = parseInt(elementFparts[0].trim());
                                            labelsFontMin = parseInt(elementFparts[1].trim());
                                            labelsFontMax = parseInt(elementFparts[2].trim());
                                        }
                                    } else if (elementNameNum.trim() === 'inputs') {
                                        if (elementFparts.length === 3) {
                                            inputsFontPct = parseInt(elementFparts[0].trim());
                                            inputsFontMin = parseInt(elementFparts[1].trim());
                                            inputsFontMax = parseInt(elementFparts[2].trim());
                                        }
                                    } else if (elementNameNum.trim() === 'opt_in') {
                                        if (elementFparts.length === 3) {
                                            optInFontPct = parseInt(elementFparts[0].trim());
                                            optInFontMin = parseInt(elementFparts[1].trim());
                                            optInFontMax = parseInt(elementFparts[2].trim());
                                        }
                                    } else if (elementNameNum.trim() === 'help_text') {
                                        if (elementFparts.length === 3) {
                                            helpTextFontPct = parseInt(elementFparts[0].trim());
                                            helpTextFontMin = parseInt(elementFparts[1].trim());
                                            helpTextFontMax = parseInt(elementFparts[2].trim());
                                        }
                                    }
                                }
                            }
                        }

                        var origElementWidth = settings[pref + ele_type + i].width;
                        var origElementHeight = settings[pref + ele_type + i].height;

                        var origElementLeft = settings[pref + ele_type + i].x;
                        var origElementTop = settings[pref + ele_type + i].y;

                        var newElementWidth = Math.round(origElementWidth + (diffBoxWidth * elementWidthPct / 100));
                        var newElementHeight = Math.round(origElementHeight + (diffBoxHeight * elementHeightPct / 100));

                        if (newElementWidth < elementWidthMin)
                            newElementWidth = elementWidthMin;
                        if (newElementWidth > elementWidthMax)
                            newElementWidth = elementWidthMax;

                        if (newElementHeight < elementHeightMin)
                            newElementHeight = elementHeightMin;
                        if (newElementHeight > elementHeightMax)
                            newElementHeight = elementHeightMax;


                        var newElementLeft = getNewElementLeft(pref_responsive, origElementLeft, origElementWidth, newElementWidth, origBoxWidth, newBoxWidth);
                        var newElementTop = getNewElementTop(pref_responsive, origElementTop, origElementHeight, newElementHeight, origBoxHeight, newBoxHeight);

                        var diffElementWidth = newElementWidth - origElementWidth;
                        var diffElementHeight = newElementHeight - origElementHeight;



                        $('#' + pref + ele_type + i + '_wrapper').css({
                            "left": newElementLeft + "px",
                            "top": newElementTop + "px",
                            "width": newElementWidth + "px",
                            "height": newElementHeight + "px"
                        });

                        if (ele_type === 'form') {
                            //All fonts:  inputs, labels, opt-in
                            if (excludeFilter.indexOf('labels') === -1) {
                                var labelsFontMultiplier = ((diffElementWidth / 5) * (labelsFontPct / 100));
                                var origLabelFontSize = parseInt(settings[pref + 'labels'].font.size);
                                var newLabelFontSize = Math.round(origLabelFontSize + labelsFontMultiplier);

                                if (newLabelFontSize < labelsFontMin)
                                    newLabelFontSize = labelsFontMin;
                                if (newLabelFontSize > labelsFontMax)
                                    newLabelFontSize = labelsFontMax;

                                $('.' + pref + 'form_labels').css({
                                    "font-size": newLabelFontSize + "px"
                                });
                            }

                            if (excludeFilter.indexOf('inputs') === -1) {
                                var inputsFontMultiplier = ((diffElementWidth / 5) * (inputsFontPct / 100));
                                var origInputFontSize = parseInt(settings[pref + 'inputs'].font.size);
                                var newInputFontSize = Math.round(origInputFontSize + inputsFontMultiplier);

                                if (newInputFontSize < inputsFontMin)
                                    newInputFontSize = inputsFontMin;
                                if (newInputFontSize > inputsFontMax)
                                    newInputFontSize = inputsFontMax;

                                $('.' + pref + 'form_inputs').css({
                                    "font-size": newInputFontSize + "px"
                                });
                            }

                            if (settings.hasOwnProperty(pref + 'opt_in') && settings[pref + 'opt_in'].display && excludeFilter.indexOf('opt_in') === -1 && optInFontPct > 0) {
                                var optInFontMultiplier = ((diffElementWidth / 5) * (optInFontPct / 100));
                                var origOptInFontSize = parseInt(settings[pref + 'opt_in'].font.size);
                                var newOptInFontSize = Math.round(origOptInFontSize + optInFontMultiplier);

                                if (newOptInFontSize < optInFontMin)
                                    newOptInFontSize = optInFontMin;
                                if (newOptInFontSize > optInFontMax)
                                    newOptInFontSize = optInFontMax;

                                $('#' + pref + 'form_input_opt_in_text').css({
                                    "font-size": newOptInFontSize + "px"
                                });
                            }

                            if (excludeFilter.indexOf('help_text') === -1 && helpTextFontPct > 0) {
                                var helpTextFontMultiplier = ((diffElementWidth / 5) * (helpTextFontPct / 100));
                                var origHelpTextFontSize = 11;
                                var newHelpTextFontSize = Math.round(origHelpTextFontSize + helpTextFontMultiplier);

                                if (newHelpTextFontSize < helpTextFontMin)
                                    newHelpTextFontSize = helpTextFontMin;
                                if (newHelpTextFontSize > helpTextFontMax)
                                    newHelpTextFontSize = helpTextFontMax;

                                $('.' + pref + 'form_inputs_help').css({
                                    "font-size": newHelpTextFontSize + "px"
                                });
                            }

                            //Width of everything adjusts automatically based on overall form width, so no changes needed there.
                            //Height of everything is static, so need to adjust.  Get percent growth of form overall.  then use that as a multiplier on "input height".  (note: height of opt-in is auto, so no changes there)
                            var growthElementHeightPct = diffElementHeight / origElementHeight;
                            var newFormRowHeight = Math.round(parseInt(settings[pref + 'inputs'].height) * (1 + growthElementHeightPct));

                            if (settings[pref + 'labels'].position == 'left') {
                                $('.' + pref + 'form_labels').height(newFormRowHeight);
                                $('.' + pref + 'form_labels').css({
                                    'line-height': newFormRowHeight + 'px'
                                });
                            }

                            $('.' + pref + 'form_inputs').height(newFormRowHeight);
                        } else if (ele_type === 'text' || ele_type === 'button') {
                            var fontMultiplier = ((diffElementWidth / 5) * (elementFontPct / 100));
                            var origElementFontSize = parseInt(settings[pref + ele_type + i].font.size);
                            var newElementFontSize = Math.round(origElementFontSize + fontMultiplier);

                            if (newElementFontSize < elementFontMin)
                                newElementFontSize = elementFontMin;
                            if (newElementFontSize > elementFontMax)
                                newElementFontSize = elementFontMax;

                            $('#' + pref + ele_type + i).css({
                                "font-size": newElementFontSize + "px"
                            });
                        }
                    }
                }
            }
        } else {
            //logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - onResponsiveDimensionChange: settings not yet loaded...');
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'onResponsiveDimensionChange');
    }
}

function getNewElementLeft(pref_responsive, origElementLeft, origElementWidth, newElementWidth, origBoxWidth, newBoxWidth) {
    var contentAlignmentX = settings[pref_responsive].content_alignment_x || 'center';

    var newElementLeft = origElementLeft;

    if (contentAlignmentX === 'left') {
        newElementLeft = origElementLeft;
    } else if (contentAlignmentX === 'center') {
        var diffBoxWidth = newBoxWidth - origBoxWidth;
        var diffElementWidth = newElementWidth - origElementWidth;
        newElementLeft = Math.round(origElementLeft + (0.5 * diffBoxWidth) - (0.5 * diffElementWidth));
    } else if (contentAlignmentX === 'right') {
        newElementLeft = newBoxWidth - (origBoxWidth - origElementWidth - origElementLeft) - newElementWidth;
    }

    return newElementLeft;
}

function getNewElementTop(pref_responsive, origElementTop, origElementHeight, newElementHeight, origBoxHeight, newBoxHeight) {
    var contentAlignmentY = settings[pref_responsive].content_alignment_y || 'top';

    var newElementTop = origElementTop;

    if (contentAlignmentY === 'top') {
        newElementTop = origElementTop;
    } else if (contentAlignmentY === 'center') {
        var diffBoxHeight = newBoxHeight - origBoxHeight;
        var diffElementHeight = newElementHeight - origElementHeight;
        newElementTop = Math.round(origElementTop + (0.5 * diffBoxHeight) - (0.5 * diffElementHeight));
    } else if (contentAlignmentY === 'bottom') {
        newElementTop = newBoxHeight - (origBoxHeight - origElementHeight - origElementTop) - newElementHeight;
    }

    return newElementTop;
}

function sendMessageToParent(obj) {
    parent.DIGIOH_API.LIGHTBOX.receiveMessageFromIframe(obj, LIGHTBOX_OR_VARIATION_GUID);
}

function receiveMessageFromParent(obj) {
    if (obj && obj.hasOwnProperty('message')) {
        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - receiveMessageFromParent: ' + obj.message);
    }

    if (obj && obj.hasOwnProperty('sender') && obj.sender === 'lightbox') {
        if (obj.hasOwnProperty('action')) {
            if (obj.action === 'dimensions_changed') {
                onResponsiveDimensionChange(obj);
            } else if (obj.action === 'pixel_version_changed') {
                var pg = '';
                if (obj.hasOwnProperty('page')) {
                    pg = obj['page'];
                }
                onPixelVersionChange(pg);
            } else if (obj.action === 'before_lightbox_display') {
                runCustomJsBeforeDisplayRetry();
            } else if (obj.action === 'after_lightbox_display') {
                if (obj.auto_focus) {
                    if ($('#form_input_first_name').length) {
                        $('#form_input_first_name').focus();
                    } else if ($('#form_input_full_name').length) {
                        $('#form_input_full_name').focus();
                    } else if ($('#form_input_email').length) {
                        $('#form_input_email').focus();
                    }
                }

                runCustomJsAfterDisplayRetry();
            } else if (obj.action === 'before_lightbox_close') {
                BOX_CUSTOM_JS.runCustomJsBeforeClose();
            } else if (obj.action === 'after_lightbox_close') {
                BOX_CUSTOM_JS.runCustomJsAfterClose();
            }
        }
    }
}

function runCustomJsBeforeDisplayRetry() {
    if (hasAfterDomReadyJsFinished)
        BOX_CUSTOM_JS.runCustomJsBeforeDisplay();
    else
        setTimeout(runCustomJsBeforeDisplayRetry, 50);
}

function runCustomJsAfterDisplayRetry() {
    if (hasAfterDomReadyJsFinished) {
        BOX_CUSTOM_JS.runCustomJsAfterDisplay();
    } else {
        setTimeout(runCustomJsAfterDisplayRetry, 50);
    }
}


function runCustomJsLinkedApps(trigger) {
    if (typeof CJSAPPS_BOXES !== 'undefined' && CJSAPPS_BOXES !== null && typeof CJSAPPS_ARR !== 'undefined' && CJSAPPS_ARR !== null && CJSAPPS_ARR.length > 0) {
        for (var i = 0; i < CJSAPPS_ARR.length; i++) {
            var appId = CJSAPPS_ARR[i];
            if (CJSAPPS_BOXES.hasOwnProperty(appId) && CJSAPPS_BOXES[appId].hasOwnProperty(trigger)) {
                var res = false;
                if (trigger == 'Before DOM Ready')
                    res = CJSAPPS_BOXES[appId][trigger](parent.DIGIOH_API, STANDARD_OBJ);
                else
                    res = CJSAPPS_BOXES[appId][trigger](parent.DIGIOH_API, STANDARD_OBJ, x);

                console.log('CJSAPPS_BOXES: ' + appId + ', ' + trigger);
                console.log(res);

                if (res === false)
                    return false;
            }
        }

        return true;
    }
}



function sendMessageToIframe(obj, lid_target) {
    parent.DIGIOH_API.LIGHTBOX.relayMessageToIframe(obj, LIGHTBOX_OR_VARIATION_GUID, lid_target);
}

function receiveMessageFromIframe(obj, lid_source, lid_target) {
    if (obj && obj.hasOwnProperty('message')) {
        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') -' + obj.message);
    }
}

function tryInitBugsnag() {
    BugsnagInitAttempts++;

    if (typeof DIGIOH_USE_BUGSNAG !== 'undefined' && DIGIOH_USE_BUGSNAG) {
        if (typeof parent.DIGIOH_API.LIGHTBOX.DIGIOH_BUGSNAG !== 'undefined' && parent.DIGIOH_API.LIGHTBOX.DIGIOH_BUGSNAG !== null) {
            //do nothing
        } else if (BugsnagInitAttempts < 10) {
            setTimeout(tryInitBugsnag, 250);
        }
    }
}

function onPixelVersionChange(page) {
    //console.log('onPixelVersionChange(' + page + ')');
    tryInitScripts();
    clearSettings();
    applySettings(false, page, true);
}

function tryInitScripts() {
    if (parent.DIGIOH_API.LIGHTBOX.PixelThresholdSettings && parent.DIGIOH_API.LIGHTBOX.PixelThresholdSettings.hasOwnProperty(LIGHTBOX_OR_VARIATION_GUID) && typeof parent.DIGIOH_API.LIGHTBOX.PixelThresholdSettings[LIGHTBOX_OR_VARIATION_GUID] === 'object') {
        settings = parent.DIGIOH_API.LIGHTBOX.PixelThresholdSettings[LIGHTBOX_OR_VARIATION_GUID];
        IS_SETTINGS_LOADED = true;
        //console.log('tryInitScripts(PixelThresholdSettings)(' + LIGHTBOX_OR_VARIATION_GUID + ')(' + settings.ep1layout.background.color + ')');
    } else if (parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS && parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS.hasOwnProperty(LIGHTBOX_OR_VARIATION_GUID) && parent.DIGIOH_API.LIGHTBOX.LZString) {
        //if (parent.DIGIOH_API.LIGHTBOX.USE_LZ) {
        //    console.log('parent.DIGIOH_API.LIGHTBOX.USE_LZ: (1) ' + parent.DIGIOH_API.LIGHTBOX.USE_LZ);
        //    settings = JSON.parse(parent.DIGIOH_API.LIGHTBOX.LZString.decompressFromBase64(parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID]));
        //} else {
        //    console.log('parent.DIGIOH_API.LIGHTBOX.USE_LZ: (2) ' + parent.DIGIOH_API.LIGHTBOX.USE_LZ);
        //    settings = parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID];
        //}

        if (typeof parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID] === 'object' && parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID] !== null) {
            settings = parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID];
        } else if (typeof parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID] === 'string' && parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID].length > 50 && parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID].indexOf('{') < 0) {
            settings = JSON.parse(parent.DIGIOH_API.LIGHTBOX.LZString.decompressFromBase64(parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID]));
        } else if (typeof parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID] === 'string' && parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID].length > 50 && parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID].indexOf('{') >= 0) {
            settings = JSON.parse(parent.DIGIOH_API.DIGIOH_LIGHTBOX_SETTINGS[LIGHTBOX_OR_VARIATION_GUID]);
        }

        IS_SETTINGS_LOADED = true;
    } else {
        setTimeout(tryInitScripts, 200);
    }
}

function tryApplySettings() {
    if (IS_SETTINGS_LOADED && IS_SCRIPTS_LOADED) {
        applySettings(true, '');
    } else {
        setTimeout(tryApplySettings, 100);
    }
}

function clearSettings() {
    if ($('#layout').length) {
        $('#layout').empty();
    }
    if ($('#thxlayout').length) {
        $('#thxlayout').empty();
    }

    if ($('#ep1layout').length) {
        $('#ep1layout').empty();
    }
    if ($('#ep2layout').length) {
        $('#ep2layout').empty();
    }
    if ($('#ep3layout').length) {
        $('#ep3layout').empty();
    }
    if ($('#ep4layout').length) {
        $('#ep4layout').empty();
    }

    if (settings.hasOwnProperty('extra_pages') && settings.extra_pages) {
        for (var x = 1; x <= settings.extra_pages.length; x++) {
            if (settings.extra_pages[x - 1] && settings.extra_pages[x - 1]['on'] == 1 && $('#ep' + x + 'layout').length) {
                $('#ep' + x + 'layout').empty();
            }
        }
    }
}


function getFormMergeTagsFromString(str) {
    try {
        var tags = [];
        var mergeParts = str.split('[FORM_');
        if (mergeParts.length > 1) {
            for (var j = 1; j < mergeParts.length; j++) {
                if (boxapi.contains(mergeParts[j], ']')) {
                    tags.push('[FORM_' + mergeParts[j].split(']')[0] + ']');
                }
            }
        }
        return tags;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'getFormMergeTagsFromString');
    }

    return [];
}


function getFormMergeTagReplacementValue(mergeTag) {
    try {
        var ls = parent.DIGIOH_API.LIGHTBOX.DIGIOH_LOCAL_STORAGE.getManual('fsdbx');
        var localStorageVal = '';
        var fallback = '';

        mergeTag = mergeTag.replace('[', '').replace(']', '');

        if (mergeTag.indexOf('{BOXID}') > 0) {
            mergeTag = mergeTag.split('{BOXID}').join(LIGHTBOX_SHORT_ID.toString());
        }

        if (mergeTag.indexOf('_{FALLBACK}') > 0) {
            mergeTag = mergeTag.split('_{FALLBACK}').join('');
        }

        var mergeTagParts = mergeTag.split('_');
        if (mergeTagParts.length >= 3) {
            if (mergeTagParts[1] === 'GLOBAL' && typeof ls === 'object' && ls !== null) {
                if (mergeTagParts[2] === 'FIRST' && mergeTagParts.length > 3 && mergeTagParts[3] === 'NAME') {
                    localStorageVal = ls.hasOwnProperty('first_name') ? ls['first_name'] : '';
                } else if (mergeTagParts[2] === 'LAST' && mergeTagParts.length > 3 && mergeTagParts[3] === 'NAME') {
                    localStorageVal = ls.hasOwnProperty('last_name') ? ls['last_name'] : '';
                } else if (mergeTagParts[2] === 'OPT' && mergeTagParts.length > 3 && mergeTagParts[3] === 'IN') {
                    localStorageVal = ls.hasOwnProperty('opt_in') ? ls['opt_in'] : '';
                } else if (mergeTagParts[2] === 'CUSTOM' && mergeTagParts.length > 3) {
                    localStorageVal = ls.hasOwnProperty('custom_' + mergeTagParts[3]) ? ls['custom_' + mergeTagParts[3]] : '';
                } else {
                    localStorageVal = ls.hasOwnProperty(mergeTagParts[2].toLowerCase()) ? ls[mergeTagParts[2].toLowerCase()] : '';
                }
            } else if (ls.hasOwnProperty(mergeTagParts[1]) && typeof ls[mergeTagParts[1]] === 'object' && ls[mergeTagParts[1]] !== null && typeof ls === 'object' && ls !== null) {
                if (mergeTagParts[2] === 'FIRST' && mergeTagParts.length > 3 && mergeTagParts[3] === 'NAME') {
                    localStorageVal = ls[mergeTagParts[1]].hasOwnProperty('first_name') ? ls[mergeTagParts[1]]['first_name'] : '';
                } else if (mergeTagParts[2] === 'LAST' && mergeTagParts.length > 3 && mergeTagParts[3] === 'NAME') {
                    localStorageVal = ls[mergeTagParts[1]].hasOwnProperty('last_name') ? ls[mergeTagParts[1]]['last_name'] : '';
                } else if (mergeTagParts[2] === 'OPT' && mergeTagParts.length > 3 && mergeTagParts[3] === 'IN') {
                    localStorageVal = ls[mergeTagParts[1]].hasOwnProperty('opt_in') ? ls[mergeTagParts[1]]['opt_in'] : '';
                } else if (mergeTagParts[2] === 'CUSTOM' && mergeTagParts.length > 3) {
                    localStorageVal = ls[mergeTagParts[1]].hasOwnProperty('custom_' + mergeTagParts[3]) ? ls[mergeTagParts[1]]['custom_' + mergeTagParts[3]] : '';
                } else {
                    localStorageVal = ls[mergeTagParts[1]].hasOwnProperty(mergeTagParts[2].toLowerCase()) ? ls[mergeTagParts[1]][mergeTagParts[2].toLowerCase()] : '';
                }
            }

            if (mergeTagParts.length > 4 && (mergeTag.indexOf('_FIRST_NAME') > 0 || mergeTag.indexOf('_LAST_NAME') > 0 || mergeTag.indexOf('_OPT_IN') > 0 || mergeTag.indexOf('_CUSTOM_') > 0)) {
                for (var k = 4; k < mergeTagParts.length; k++) {
                    fallback += mergeTagParts[k] + '_';
                }
            } else if (mergeTagParts.length > 3 && (mergeTag.indexOf('_EMAIL') > 0 || mergeTag.indexOf('_PHONE') > 0 || mergeTag.indexOf('_NAME') > 0) && mergeTag.indexOf('_FIRST_NAME') === -1 && mergeTag.indexOf('_LAST_NAME') === -1) {
                for (var k = 3; k < mergeTagParts.length; k++) {
                    fallback += mergeTagParts[k] + '_';
                }
            }

            if (fallback.length > 0) {
                fallback = fallback.substr(0, fallback.length - 1);
            }

            return [localStorageVal, fallback];
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'getFormMergeTagReplacementValue');
    }

    return [];
}


function replaceSettingsObjFormMergeTags(settingsProp, pref) {
    try {
        var keys = Object.keys(settingsProp);
        for (var i = 0; i < keys.length; i++) {
            if (typeof settingsProp[keys[i]] === 'object' && ((pref === '' && keys[i].indexOf('thx') !== 0 && keys[i].indexOf('ep') !== 0) || (pref !== '' && keys[i].indexOf(pref) === 0))) {
                replaceSettingsObjFormMergeTags(settingsProp[keys[i]], pref);
            } else if ((typeof settingsProp[keys[i]] === 'string' && settingsProp[keys[i]].indexOf('[FORM_') >= 0) && ((pref === '' && keys[i].indexOf('thx') !== 0 && keys[i].indexOf('ep') !== 0) || (pref !== '' && keys[i].indexOf(pref) === 0))) {
                var tags = getFormMergeTagsFromString(settingsProp[keys[i]]);
                for (var j = 0; j < tags.length; j++) {
                    var mergeTag = tags[j];
                    //[FORM_GLOBAL_EMAIL]
                    //[FORM_165909_FIRST_NAME]
                    //[FORM_165909_OPT_IN]
                    //[FORM_165909_CUSTOM_17_fallback value here]

                    var replacementValues = getFormMergeTagReplacementValue(mergeTag);
                    if (replacementValues.length === 2) {
                        var localStorageVal = replacementValues[0];
                        var fallback = replacementValues[1];

                        if (localStorageVal !== '') {
                            settingsProp[keys[i]] = settingsProp[keys[i]].split(mergeTag).join(localStorageVal);
                        } else if (fallback !== '') {
                            settingsProp[keys[i]] = settingsProp[keys[i]].split(mergeTag).join(fallback);
                        } else {
                            settingsProp[keys[i]] = settingsProp[keys[i]].split(mergeTag).join('');
                        }
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceSettingsObjFormMergeTags');
    }
}


function replaceSettingsObjFormMergeTagsAfterChangePages(pref) {
    try {
        $('#' + pref + 'layout div:contains("[FORM_"), ' + '#' + pref + 'layout span:contains("[FORM_"), ' + '#' + pref + 'layout p:contains("[FORM_"),' + '#' + pref + 'layout button:contains("[FORM_")').each(function() {
            if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length || ($(this).children().length < 2 && $(this).find('a').length === 0 && $(this).find('button').length === 0 && $(this).find('*').length < 2)) {
                var tags = getFormMergeTagsFromString($(this).html());
                for (var i = 0; i < tags.length; i++) {
                    var replacementValues = getFormMergeTagReplacementValue(tags[i]);
                    if (replacementValues.length === 2) {
                        var localStorageVal = replacementValues[0];
                        var fallback = replacementValues[1];
                        if (localStorageVal !== '') $(this).html($(this).html().split(tags[i]).join(localStorageVal));
                        else if (fallback !== '') $(this).html($(this).html().split(tags[i]).join(fallback));
                        else $(this).html($(this).html().split(tags[i]).join(''));
                    }
                }
            }
        });

        $('#' + pref + 'layout img').each(function() {
            if ($(this).attr('src') && boxapi.contains($(this).attr('src'), '[FORM_')) {
                var tags = getFormMergeTagsFromString($(this).attr('src'));
                for (var i = 0; i < tags.length; i++) {
                    var replacementValues = getFormMergeTagReplacementValue(tags[i]);
                    if (replacementValues.length === 2) {
                        var localStorageVal = replacementValues[0];
                        var fallback = replacementValues[1];
                        if (localStorageVal !== '') $(this).attr('src', $(this).attr('src').split(tags[i]).join(localStorageVal));
                        else if (fallback !== '') $(this).attr('src', $(this).attr('src').split(tags[i]).join(fallback));
                        else $(this).attr('src', $(this).attr('src').split(tags[i]).join(''));
                    }
                }

                //console.log('replaceSettingsObjFormMergeTagsAfterChangePages_2: ' + tags[0]);
            }
        });

        $('#' + pref + 'layout input, ' + '#' + pref + 'layout textarea,' + '#' + pref + 'layout select option').each(function() {
            if ($(this).val() && boxapi.contains($(this).val(), '[FORM_')) {
                var tags = getFormMergeTagsFromString($(this).val());
                for (var i = 0; i < tags.length; i++) {
                    var replacementValues = getFormMergeTagReplacementValue(tags[i]);
                    if (replacementValues.length === 2) {
                        var localStorageVal = replacementValues[0];
                        var fallback = replacementValues[1];
                        if (localStorageVal !== '') $(this).val($(this).val().split(tags[i]).join(localStorageVal));
                        else if (fallback !== '') $(this).val($(this).val().split(tags[i]).join(fallback));
                        else $(this).val($(this).val().split(tags[i]).join(''));
                    }
                }

                //console.log('replaceSettingsObjFormMergeTagsAfterChangePages_3: ' + tags[0]);
            }

            if (typeof $(this).attr('placeholder') === 'string' && boxapi.contains($(this).attr('placeholder'), '[FORM_')) {
                var tags = getFormMergeTagsFromString($(this).attr('placeholder'));
                for (var i = 0; i < tags.length; i++) {
                    var replacementValues = getFormMergeTagReplacementValue(tags[i]);
                    if (replacementValues.length === 2) {
                        var localStorageVal = replacementValues[0];
                        var fallback = replacementValues[1];
                        if (localStorageVal !== '') $(this).attr('placeholder', $(this).attr('placeholder').split(tags[i]).join(localStorageVal));
                        else if (fallback !== '') $(this).attr('placeholder', $(this).attr('placeholder').split(tags[i]).join(fallback));
                        else $(this).attr('placeholder', $(this).attr('placeholder').split(tags[i]).join(''));
                    }
                }
            }

            if (typeof $(this).text() === 'string' && boxapi.contains($(this).text(), '[FORM_')) {
                var tags = getFormMergeTagsFromString($(this).text());
                for (var i = 0; i < tags.length; i++) {
                    var replacementValues = getFormMergeTagReplacementValue(tags[i]);
                    if (replacementValues.length === 2) {
                        var localStorageVal = replacementValues[0];
                        var fallback = replacementValues[1];
                        if (localStorageVal !== '') $(this).text($(this).text().split(tags[i]).join(localStorageVal));
                        else if (fallback !== '') $(this).text($(this).text().split(tags[i]).join(fallback));
                        else $(this).text($(this).text().split(tags[i]).join(''));
                    }
                }
            }
        });

        //console.log('replaceSettingsObjFormMergeTagsAfterChangePages: ' + pref);

        //replae any settings values that are not part of the DOM (ie. data only)
        replaceSettingsObjFormMergeTags(settings, pref);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceSettingsObjFormMergeTagsAfterChangePages');
    }
}


function applySettings(is_first_render, page, is_pixel_version) {
    try {
        //console.log('applySettings: ' + LIGHTBOX_GUID + ', ' + typeof settings);
        //console.log(settings);

        if (typeof settings === 'string' && settings.length > 50 && settings.indexOf('{') < 0) {
            settings = JSON.parse(parent.DIGIOH_API.LIGHTBOX.LZString.decompressFromBase64(settings));
        }

        if (is_first_render) {
            for (var f = 1; f <= 50; f++) {
                form_input_obj['pref_form_input_custom' + f] = false;
                form_input_obj['form_input_custom' + f] = false;
                form_input_obj['thx_form_input_custom' + f] = false;
                form_input_obj['ep1_form_input_custom' + f] = false;
                form_input_obj['ep2_form_input_custom' + f] = false;
                form_input_obj['ep3_form_input_custom' + f] = false;
                form_input_obj['ep4_form_input_custom' + f] = false;

                if (settings.hasOwnProperty("extra_pages") && settings.extra_pages) {
                    for (var j = 5; j <= settings.extra_pages.length; j++) {
                        if (settings.extra_pages[j - 1] && settings.extra_pages[j - 1]['on'] === 1) {
                            form_input_obj['ep' + j + '_form_input_custom' + f] = false;
                        }
                    }
                }
            }
        }


        var x = 1;

        for (var y = 1; y <= 102; y++) {
            var pr = '';
            if (y === 1) pr = '';
            else if (y === 2) pr = 'thx';
            else if (y >= 3 && y <= 6) pr = 'ep' + (y - 2);
            else if (y >= 7) {
                if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (y - 3) || !settings.extra_pages[y - 3] || settings.extra_pages[y - 3]['on'] !== 1) {
                    continue;
                }

                pr = 'ep' + (y - 2);
            }

            if (pr !== '' && !$('#' + pr + 'layout').length) {
                $('#layout').after("<div id='" + pr + "layout' style='display: none;'></div>");

                //Metadata
                if (settings.hasOwnProperty(pr + 'layout') && settings[pr + 'layout'].hasOwnProperty('metadata_kvps')) {
                    for (var k = 0; k < settings[pr + 'layout'].metadata_kvps.length; k++) {
                        if (settings[pr + 'layout'].metadata_kvps[k].k && settings[pr + 'layout'].metadata_kvps[k].v) {
                            trySetAttribute(pr + 'layout', settings[pr + 'layout'].metadata_kvps[k]);
                        }
                    }
                }
            }

            for (x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'text' + x) && settings[pr + 'text' + x].display || x <= 4) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "text" + x + "_wrapper'><div id='" + pr + "text" + x + "'></div></div>");
                } else if (x <= 4) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "text" + x + "_wrapper' style='display:none;'><div id='" + pr + "text" + x + "'></div></div>");
                }
            }

            if (pr === '')
                $('#' + pr + 'layout').append("<div id='form_wrapper'><div id='form'></div></div>");
            else
                $('#' + pr + 'layout').append("<div id='" + pr + "_form_wrapper'><div id='" + pr + "_form'></div></div>");

            for (x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'button' + x) && settings[pr + 'button' + x].display) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "button" + x + "_wrapper'><button id='" + pr + "button" + x + "' class='" + pr + "button" + x + "'></button></div>");
                } else if (x <= 4) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "button" + x + "_wrapper' style='display:none;'><button id='" + pr + "button" + x + "' class='" + pr + "button" + x + "'></button></div>");
                }
            }

            for (x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'image' + x) && settings[pr + 'image' + x].display) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "image" + x + "_wrapper'><img id='" + pr + "image" + x + "' /></div>");
                } else if (x <= 4) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "image" + x + "_wrapper' style='display:none;'><img id='" + pr + "image" + x + "' /></div>");
                }
            }

            for (x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'html' + x) && settings[pr + 'html' + x].display) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "html" + x + "_wrapper'><div id='" + pr + "html" + x + "'></div></div>");
                } else if (x <= 4) {
                    $('#' + pr + 'layout').append("<div id='" + pr + "html" + x + "_wrapper' style='display:none;'><div id='" + pr + "html" + x + "'></div></div>");
                }
            }

            for (x = 1; x <= 50; x++) {
                if (pr === '' && !settings.hasOwnProperty('custom' + x)) {
                    settings['custom' + x] = {
                        display: false
                    };
                } else if (pr !== '' && !settings.hasOwnProperty(pr + '_custom' + x)) {
                    settings[pr + '_custom' + x] = {
                        display: false
                    };
                }
            }
        }

        //Form
        form_wrapper = $('#form_wrapper');
        form = $('#form');
        thx_form_wrapper = $('#thx_form_wrapper');
        thx_form = $('#thx_form');
        ep1_form_wrapper = $('#ep1_form_wrapper');
        ep1_form = $('#ep1_form');
        ep2_form_wrapper = $('#ep2_form_wrapper');
        ep2_form = $('#ep2_form');
        ep3_form_wrapper = $('#ep3_form_wrapper');
        ep3_form = $('#ep3_form');
        ep4_form_wrapper = $('#ep4_form_wrapper');
        ep4_form = $('#ep4_form');

        CURRENT_WIDTH = settings.layout.width;
        CURRENT_HEIGHT = settings.layout.height;

        determineGoogleFonts();
        loadExternalFonts('');



        replaceSettingsObjFormMergeTags(settings, '');



        buildStyles(page, is_pixel_version);
        buildText();
        buildForm();
        buildButtons();

        buildImages();
        loadImages('');

        buildHTML();
        buildDynamicItems();

        buildCouponsDisplay();

        replaceHrefMergeTags();
        replaceBrMergeTags();

        //loadExternalFonts();

        //logger('lightbox.html - applySettings done');
        //sendMessageToIframe({}, '4d8a1a16-dcb7-4e66-a38e-609cee0a2cfd');
        //sendMessageToParent({ loading_status: 'settings_applied', lightbox_id: LIGHTBOX_OR_VARIATION_GUID, widget_type: WIDGET_TYPE });

        if (is_first_render) {
            preloadImages();

            if (typeof html_ele.classList === 'object' && html_ele.classList !== null) {
                html_ele.classList.remove("hidden_until_loaded");
            }

            $('input').focus(function() {
                sendMessageToParent({
                    sender: 'lightbox',
                    event: 'input_focus',
                    lightbox_id: LIGHTBOX_OR_VARIATION_GUID
                });
            });

            //if (settings.hasOwnProperty('responsive') && settings.responsive.use) {
            //    onResponsiveDimensionChange(obj);
            //}


            //Metadata - page
            if (pr === '' && $('#layout').length && settings['layout'].hasOwnProperty('metadata_kvps')) {
                for (var k = 0; k < settings['layout'].metadata_kvps.length; k++) {
                    if (settings['layout'].metadata_kvps[k].k && settings['layout'].metadata_kvps[k].v) {
                        trySetAttribute('layout', settings['layout'].metadata_kvps[k]);
                    }
                }
            }


            //Metadata - widget
            var effects = parent.DIGIOH_API.GET_EFFECTS(LIGHTBOX_OR_VARIATION_GUID);
            if (typeof effects === 'object' && effects !== null) {
                if (effects.hasOwnProperty('widget_type') && typeof effects['widget_type'] === 'string' && effects.hasOwnProperty(effects['widget_type']) && effects[effects['widget_type']].hasOwnProperty('metadata_kvps')) {
                    var kvps = effects[effects['widget_type']].metadata_kvps;
                    for (var k = 0; k < kvps.length; k++) {
                        if (kvps[k].k && kvps[k].v) {
                            trySetAttribute('body', kvps[k]);
                        }
                    }
                }
            }

            sendMessageToParent({
                sender: 'lightbox',
                status: 'child_messaging_ready',
                lightbox_id: LIGHTBOX_OR_VARIATION_GUID
            });
            sendMessageToParent({
                sender: 'lightbox',
                loading_status: 'settings_applied',
                lightbox_id: LIGHTBOX_OR_VARIATION_GUID,
                widget_type: WIDGET_TYPE
            });
        } else if (page) {
            if (page.indexOf('_') < 0) {
                page += '_';
            }
            changePages(page, page + 'form', settings[page + 'form'], 'form');
        }

        BOX_CUSTOM_JS.runCustomJsAfterDOMReady();

        hasAfterDomReadyJsFinished = true;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'applySettings');
    }
}


function preloadImages() {
    try {
        var baseSrc = "https://s3.lightboxcdn.com/vendors/" + VENDOR_GUID + "/uploads/";
        var preload = boxapi.getWidgetMetadata('box_preload_images');
        if (preload && (preload == 'true' || preload == '1' || preload == 'yes')) {
            var pr = '';

            for (var j = 1; j <= 102; j++) {
                if (j == 1) {
                    pr = '';
                } else if (j == 2) {
                    pr = 'thx';
                } else if (j >= 3) {
                    pr = 'ep' + (j - 2);

                    if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (j - 3) || !settings.extra_pages[j - 3] || settings.extra_pages[j - 3]['on'] !== 1) {
                        continue;
                    }
                }

                for (var x = 1; x <= 50; x++) {
                    if (settings.hasOwnProperty(pr + 'button' + x) && settings[pr + 'button' + x].display && settings[pr + 'button' + x].background.use_image && settings[pr + 'button' + x].background.image.length > 20) {
                        var imgSrc = baseSrc + settings[pr + 'button' + x].background.image;
                        $('body').append("<img src='" + imgSrc + "' style='display: none;'>");
                        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - preloadImages: ' + pr + 'button' + x + ', ' + imgSrc);
                    }

                    if (settings.hasOwnProperty(pr + 'image' + x) && settings[pr + 'image' + x].display && settings[pr + 'image' + x].src.length > 20) {
                        var imgSrc = baseSrc + settings[pr + 'image' + x].src;
                        $('body').append("<img src='" + imgSrc + "' style='display: none;'>");
                        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - preloadImages: ' + pr + 'image' + x + ', ' + imgSrc);
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'preloadImages');
    }
}

function buildDynamicItems() {
    try {
        if (parent.DIGIOH_API.DIGIOH_DYNAMIC_BOXES) {
            //logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - DIGIOH_DYNAMIC_BOXES:');
            //logger(parent.DIGIOH_API.DIGIOH_DYNAMIC_BOXES);

            for (var i = 0; i < parent.DIGIOH_API.DIGIOH_DYNAMIC_BOXES.length; i++) {
                if (parent.DIGIOH_API.DIGIOH_DYNAMIC_BOXES[i].BoxID === LIGHTBOX_SHORT_ID) {
                    var item = parent.DIGIOH_API.DIGIOH_DYNAMIC_BOXES[i];
                    if (item.SourceType === 'jquery') {
                        if (parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).length) {

                            var sourceValFound = '[DTMP]';

                            if (item.hasOwnProperty('JqueryMethod') && item.hasOwnProperty('JqueryMethodParam') && item.JqueryMethodParam) {
                                if (item.JqueryMethod === 'attr') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).attr(item.JqueryMethodParam);
                                } else if (item.JqueryMethod === 'prop') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).prop(item.JqueryMethodParam);
                                } else if (item.JqueryMethod === 'is') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).is(item.JqueryMethodParam);
                                } else if (item.JqueryMethod === 'css') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).css(item.JqueryMethodParam);
                                } else if (item.JqueryMethod === 'hasClass') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).hasClass(item.JqueryMethodParam);
                                }
                            }

                            if (item.hasOwnProperty('JqueryMethod')) {
                                if (item.JqueryMethod === 'text') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).text();
                                } else if (item.JqueryMethod === 'val') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).val();
                                } else if (item.JqueryMethod === 'length') {
                                    sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).length.toString();
                                }
                            }

                            if (sourceValFound === '[DTMP]') {
                                sourceValFound = parent.DIGIOH_API.LIGHTBOX.JQUERY_DIGIOH(item.SourceSelector).html();
                            }

                            runDynamicSourceComparison(item, sourceValFound);

                        } else if (item.TargetDefault !== '') {
                            //default target value
                            replaceDynamicTarget(item, item.TargetDefault);
                        }
                    } else if (item.SourceType === 'url') {
                        var sourceValFound = parent.location.href;
                        if (typeof sourceValFound !== 'string') {
                            sourceValFound = '';
                        }

                        runDynamicSourceComparison(item, sourceValFound);

                    } else if (item.SourceType === 'url_param') {
                        var sourceValFound = parent.DIGIOH_API.LIGHTBOX.getUrlParam(item.SourceSelector);
                        if (typeof sourceValFound !== 'string') {
                            sourceValFound = '';
                        }

                        runDynamicSourceComparison(item, sourceValFound);
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildDynamicItems');
    }
}

function runDynamicSourceComparison(item, sourceValFound) {
    try {
        if (item.SourceValue === '[ANYTHING]') {
            replaceDynamicTarget(item, sourceValFound, item.TargetDefault);
        } else if (typeof sourceValFound === 'string') {
            var compareVal1 = sourceValFound;
            var compareVal2 = item.SourceValue;
            if (!item.CaseSensitive) {
                compareVal1 = compareVal1.toLowerCase();
                compareVal2 = compareVal2.toLowerCase();
            }

            var compareValArr = [];
            if (boxapi.contains(compareVal2, ',') || boxapi.contains(compareVal2, '|')) {
                if (compareVal2.split(',').length > compareVal2.split('|').length)
                    compareValArr = compareVal2.split(',');
                else
                    compareValArr = compareVal2.split('|');
            } else {
                compareValArr.push(compareVal2);
            }

            if (item.SourceOperator === 'equals' || item.SourceOperator === 'contains' || item.SourceOperator === 'starts_with' || item.SourceOperator === 'ends_with') {
                var foundMatch = false;
                for (var i = 0; i < compareValArr.length; i++) {
                    if (compareValArr[i].trim() !== '') {
                        if (item.SourceOperator === 'equals' && compareVal1 === compareValArr[i].trim()) {
                            replaceDynamicTarget(item, sourceValFound, item.TargetDefault);
                            foundMatch = true;
                            break;
                        } else if (item.SourceOperator === 'contains' && compareVal1.indexOf(compareValArr[i].trim()) >= 0) {
                            replaceDynamicTarget(item, sourceValFound, item.TargetDefault);
                            foundMatch = true;
                            break;
                        } else if (item.SourceOperator === 'starts_with' && compareVal1.indexOf(compareValArr[i].trim()) === 0) {
                            replaceDynamicTarget(item, sourceValFound, item.TargetDefault);
                            foundMatch = true;
                            break;
                        } else if (item.SourceOperator === 'ends_with' && compareVal1.indexOf(compareValArr[i].trim(), compareVal1.length - compareValArr[i].trim().length) !== -1) {
                            replaceDynamicTarget(item, sourceValFound, item.TargetDefault);
                            foundMatch = true;
                            break;
                        }
                    }
                }

                if (!foundMatch && item.TargetDefault !== '') {
                    //default target value
                    //console.log('runDynamicSourceComparison: ' + item.BoxID + ', ' + item.TargetDefault);
                    replaceDynamicTarget(item, '', item.TargetDefault);
                }
            } else if (item.SourceOperator.indexOf('not_') === 0) {
                var foundMatch = false;
                for (var i = 0; i < compareValArr.length; i++) {
                    if (compareValArr[i].trim() !== '') {
                        if (item.SourceOperator === 'not_equals' && compareVal1 === compareValArr[i].trim()) {
                            foundMatch = true;
                            break;
                        } else if (item.SourceOperator === 'not_contains' && boxapi.contains(compareVal1, compareValArr[i].trim())) {
                            foundMatch = true;
                            break;
                        } else if (item.SourceOperator === 'not_starts_with' && compareVal1.indexOf(compareValArr[i].trim()) === 0) {
                            foundMatch = true;
                            break;
                        } else if (item.SourceOperator === 'not_ends_with' && compareVal1.indexOf(compareValArr[i].trim(), compareVal1.length - compareValArr[i].trim().length) !== -1) {
                            foundMatch = true;
                            break;
                        }
                    }
                }

                if (!foundMatch) {
                    replaceDynamicTarget(item, sourceValFound, item.TargetDefault);
                }

                if (foundMatch && item.TargetDefault !== '') {
                    //default target value
                    replaceDynamicTarget(item, '', item.TargetDefault);
                }
            }

        } else if (item.TargetDefault !== '') {
            //default target value
            replaceDynamicTarget(item, '', item.TargetDefault);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'runDynamicSourceComparison');
    }
}

function replaceDynamicTarget(item, srcval, target_default) {
    try {
        if (item.TargetType === 'merge')
            replaceDynamicTargetMerge(item, srcval, target_default);
        else if (boxapi.contains(item.TargetType, '_custom'))
            replaceDynamicTargetCustomField(item, srcval, target_default);
        else
            replaceDynamicTargetElement(item, srcval, target_default);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceDynamicTarget');
    }
}

function replaceDynamicTargetMerge(item, srcval, target_default) {
    try {
        var val = item.TargetValue || '';
        if (val === '[SOURCE]' && typeof srcval === 'string' && srcval !== '')
            val = srcval;
        else if (val === '[SOURCE]' && (typeof srcval !== 'string' || srcval === ''))
            val = target_default || '';
        else if (!srcval || !val)
            val = target_default || '';

        if (!val)
            return;

        $('div:contains("' + item.TargetMerge + '")').each(function() {
            if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                $(this).html($(this).html().split(item.TargetMerge).join(val));
            } else if ($(this).children().length < 2 && $(this).find('a').length === 0 && $(this).find('button').length === 0 && $(this).find('*').length < 2) {
                $(this).html($(this).html().split(item.TargetMerge).join(val));
            }
        });

        $('span:contains("' + item.TargetMerge + '")').each(function() {
            if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                $(this).html($(this).html().split(item.TargetMerge).join(val));
            }
        });

        $('p:contains("' + item.TargetMerge + '")').each(function() {
            if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                $(this).html($(this).html().split(item.TargetMerge).join(val));
            }
        });

        $('style:contains("' + item.TargetMerge + '")').each(function() {
            if ($(this).children().length < 1) {
                $(this).html($(this).html().split(item.TargetMerge).join(val));
            }
        });

        $('button:contains("' + item.TargetMerge + '")').each(function() {
            if ($(this).children().length < 1) {
                $(this).html($(this).html().split(item.TargetMerge).join(val));
            }
        });

        $('img').each(function() {
            if ($(this).attr('src') && boxapi.contains($(this).attr('src'), item.TargetMerge)) {
                $(this).attr('src', $(this).attr('src').split(item.TargetMerge).join(val));
            }
        });

        $('input,textarea').each(function() {
            if ($(this).val() && boxapi.contains($(this).val(), item.TargetMerge)) {
                $(this).val($(this).val().split(item.TargetMerge).join(val));
            }
            if (typeof $(this).attr('placeholder') === 'string' && boxapi.contains($(this).attr('placeholder'), item.TargetMerge)) {
                $(this).attr('placeholder', $(this).attr('placeholder').split(item.TargetMerge).join(val));
            }
        });

        $('select option').each(function() {
            if ($(this).val() && boxapi.contains($(this).val(), item.TargetMerge)) {
                $(this).val($(this).val().split(item.TargetMerge).join(val));
            }
            if ($(this).text() && boxapi.contains($(this).text(), item.TargetMerge)) {
                $(this).text($(this).text().split(item.TargetMerge).join(val));
            }
        });

        for (var j = 1; j <= 102; j++) {
            var pref = '';

            if (j == 1) {
                pref = '';
            } else if (j == 2) {
                pref = 'thx_';
            } else if (j >= 3 && j <= 6) {
                pref = 'ep' + (j - 2) + '_';
            } else if (j >= 7) {
                pref = 'ep' + (j - 2) + '_';

                if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (j - 3) || !settings.extra_pages[j - 3] || settings.extra_pages[j - 3]['on'] !== 1) {
                    continue;
                }
            }

            if (settings.hasOwnProperty(pref + 'form') && settings[pref + 'form'].redirect_url && boxapi.contains(settings[pref + 'form'].redirect_url, item.TargetMerge)) {
                settings[pref + 'form'].redirect_url = settings[pref + 'form'].redirect_url.split(item.TargetMerge).join(val);
            }

            //Name
            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].hasOwnProperty("error_text") && settings[pref + 'name'].error_text && boxapi.contains(settings[pref + 'name'].error_text, item.TargetMerge)) {
                settings[pref + 'name'].error_text = settings[pref + 'name'].error_text.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].label && boxapi.contains(settings[pref + 'name'].label, item.TargetMerge)) {
                settings[pref + 'name'].label = settings[pref + 'name'].label.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].placeholder_full && boxapi.contains(settings[pref + 'name'].placeholder_full, item.TargetMerge)) {
                settings[pref + 'name'].placeholder_full = settings[pref + 'name'].placeholder_full.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].placeholder_first && boxapi.contains(settings[pref + 'name'].placeholder_first, item.TargetMerge)) {
                settings[pref + 'name'].placeholder_first = settings[pref + 'name'].placeholder_first.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].placeholder_last && boxapi.contains(settings[pref + 'name'].placeholder_last, item.TargetMerge)) {
                settings[pref + 'name'].placeholder_last = settings[pref + 'name'].placeholder_last.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].help_full && boxapi.contains(settings[pref + 'name'].help_full, item.TargetMerge)) {
                settings[pref + 'name'].help_full = settings[pref + 'name'].help_full.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].help_first && boxapi.contains(settings[pref + 'name'].help_first, item.TargetMerge)) {
                settings[pref + 'name'].help_first = settings[pref + 'name'].help_first.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].help_last && boxapi.contains(settings[pref + 'name'].help_last, item.TargetMerge)) {
                settings[pref + 'name'].help_last = settings[pref + 'name'].help_last.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].default_full && boxapi.contains(settings[pref + 'name'].default_full, item.TargetMerge)) {
                settings[pref + 'name'].default_full = settings[pref + 'name'].default_full.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].default_first && boxapi.contains(settings[pref + 'name'].default_first, item.TargetMerge)) {
                settings[pref + 'name'].default_first = settings[pref + 'name'].default_first.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].default_last && boxapi.contains(settings[pref + 'name'].default_last, item.TargetMerge)) {
                settings[pref + 'name'].default_last = settings[pref + 'name'].default_last.split(item.TargetMerge).join(val);
            }

            //Email
            if (settings.hasOwnProperty(pref + 'email') && settings[pref + 'email'].hasOwnProperty("error_text") && settings[pref + 'email'].error_text && boxapi.contains(settings[pref + 'email'].error_text, item.TargetMerge)) {
                settings[pref + 'email'].error_text = settings[pref + 'email'].error_text.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'email') && settings[pref + 'email'].label && boxapi.contains(settings[pref + 'email'].label, item.TargetMerge)) {
                settings[pref + 'email'].label = settings[pref + 'email'].label.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'email') && settings[pref + 'email'].placeholder && boxapi.contains(settings[pref + 'email'].placeholder, item.TargetMerge)) {
                settings[pref + 'email'].placeholder = settings[pref + 'email'].placeholder.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'email') && settings[pref + 'email'].help && boxapi.contains(settings[pref + 'email'].help, item.TargetMerge)) {
                settings[pref + 'email'].help = settings[pref + 'email'].help.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'email') && settings[pref + 'email'].default && boxapi.contains(settings[pref + 'email'].default, item.TargetMerge)) {
                settings[pref + 'email'].default = settings[pref + 'email'].default.split(item.TargetMerge).join(val);
            }

            //Phone
            if (settings.hasOwnProperty(pref + 'phone') && settings[pref + 'phone'].hasOwnProperty("error_text") && settings[pref + 'phone'].error_text && boxapi.contains(settings[pref + 'phone'].error_text, item.TargetMerge)) {
                settings[pref + 'phone'].error_text = settings[pref + 'phone'].error_text.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'phone') && settings[pref + 'phone'].label && boxapi.contains(settings[pref + 'phone'].label, item.TargetMerge)) {
                settings[pref + 'phone'].label = settings[pref + 'phone'].label.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'phone') && settings[pref + 'phone'].placeholder && boxapi.contains(settings[pref + 'phone'].placeholder, item.TargetMerge)) {
                settings[pref + 'phone'].placeholder = settings[pref + 'phone'].placeholder.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'phone') && settings[pref + 'phone'].help && boxapi.contains(settings[pref + 'phone'].help, item.TargetMerge)) {
                settings[pref + 'phone'].help = settings[pref + 'phone'].help.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'phone') && settings[pref + 'phone'].default && boxapi.contains(settings[pref + 'phone'].default, item.TargetMerge)) {
                settings[pref + 'phone'].default = settings[pref + 'phone'].default.split(item.TargetMerge).join(val);
            }

            //Opt-In
            if (settings.hasOwnProperty(pref + 'opt_in') && settings[pref + 'opt_in'].hasOwnProperty("error_text") && settings[pref + 'opt_in'].error_text && boxapi.contains(settings[pref + 'opt_in'].error_text, item.TargetMerge)) {
                settings[pref + 'opt_in'].error_text = settings[pref + 'opt_in'].error_text.split(item.TargetMerge).join(val);
            }

            if (settings.hasOwnProperty(pref + 'opt_in') && settings[pref + 'opt_in'].text && boxapi.contains(settings[pref + 'opt_in'].text, item.TargetMerge)) {
                settings[pref + 'opt_in'].text = settings[pref + 'opt_in'].text.split(item.TargetMerge).join(val);
            }

            for (var i = 1; i <= 50; i++) {
                //if (prop.action == 'url' && prop.url)
                var pr = pref;
                if (pr.indexOf('_') > 0) {
                    pr = pr.split('_')[0];
                }

                if (settings.hasOwnProperty(pr + 'button' + i) && settings[pr + 'button' + i].url && boxapi.contains(settings[pr + 'button' + i].url, item.TargetMerge)) {
                    settings[pr + 'button' + i].url = settings[pr + 'button' + i].url.split(item.TargetMerge).join(val);
                }
            }

            //Custom Fields
            for (var i = 1; i <= 50; i++) {
                var propName = pref + 'custom' + i;
                if (settings.hasOwnProperty(propName)) {
                    if (settings[propName].hasOwnProperty("error_text") && settings[propName].error_text && boxapi.contains(settings[propName].error_text, item.TargetMerge)) {
                        settings[propName].error_text = settings[propName].error_text.split(item.TargetMerge).join(val);
                    }

                    if (settings[propName].label && boxapi.contains(settings[propName].label, item.TargetMerge)) {
                        settings[propName].label = settings[propName].label.split(item.TargetMerge).join(val);
                    }

                    if (settings[propName].placeholder && boxapi.contains(settings[propName].placeholder, item.TargetMerge)) {
                        settings[propName].placeholder = settings[propName].placeholder.split(item.TargetMerge).join(val);
                    }

                    if (settings[propName].help && boxapi.contains(settings[propName].help, item.TargetMerge)) {
                        settings[propName].help = settings[propName].help.split(item.TargetMerge).join(val);
                    }

                    if (settings[propName].default && boxapi.contains(settings[propName].default, item.TargetMerge)) {
                        settings[propName].default = settings[propName].default.split(item.TargetMerge).join(val);
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceDynamicTargetMerge');
    }
}

function replaceDynamicTargetElement(item, srcval, target_default) {
    try {
        var val = item.TargetValue || '';
        if (val === '[SOURCE]' && typeof srcval === 'string' && srcval !== '')
            val = srcval;
        else if (val === '[SOURCE]' && (typeof srcval !== 'string' || srcval === ''))
            val = target_default || '';
        else if (!srcval || !val)
            val = target_default || '';

        if (!val)
            return;

        var ele = item.TargetType;
        if (ele.indexOf('main_') === 0)
            ele = ele.split('_')[1];
        else
            ele = ele.split('_').join('');

        var ptn = $('#' + ele).attr('id');
        if (settings.hasOwnProperty(ptn) && settings[ptn].display) {
            if (ele.indexOf('image') >= 0) {
                //Original way of doing it did not preserve aspect ratio of newly replaced dynamic image
                //$('#' + ele).attr('src', val);

                //New way of doing it recalculates aspect ratio based on new image

                if (typeof val === 'string' && val.indexOf('://') > 0) {
                    image_dims[ptn + '_dynamic'] = {
                        width: 100,
                        height: 100
                    };

                    var img = new Image();
                    img.onload = function() {
                        image_dims[ptn + '_dynamic'].width = this.width;
                        image_dims[ptn + '_dynamic'].height = this.height;
                        resizeImage(image_dims[ptn + '_dynamic'], $('#' + ptn + '_wrapper'), $('#' + ptn), ptn, settings[ptn].width, settings[ptn].height, true);
                        $('#' + ptn + '_wrapper').show();
                    };

                    ImageSrcMap[ptn + '_dynamic'] = {
                        img_obj: img,
                        img_src: val,
                        img_element: $('#' + ptn)
                    };
                    ImageSrcMap[ptn + '_dynamic'].img_element.attr('src', ImageSrcMap[ptn + '_dynamic'].img_src);
                    ImageSrcMap[ptn + '_dynamic'].img_obj.src = ImageSrcMap[ptn + '_dynamic'].img_src;
                }
            } else {
                $('#' + ele).html(val);
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceDynamicTargetElement');
    }
}

function replaceDynamicTargetCustomField(item, srcval, target_default) {
    try {
        var val = item.TargetValue || '';
        if (val === '[SOURCE]' && typeof srcval === 'string' && srcval !== '')
            val = srcval;
        else if (val === '[SOURCE]' && (typeof srcval !== 'string' || srcval === ''))
            val = target_default || '';
        else if (!srcval || !val)
            val = target_default || '';

        if (!val)
            return;

        //main_custom2, ep1_custom2
        //form_input_custom2
        //ep1_form_input_custom2

        var field = item.TargetType;
        if (field.indexOf('main_') === 0)
            field = 'form_input_' + field.split('_')[1];
        else
            field = field.split('_')[0] + '_form_input_' + field.split('_')[1];

        $('#' + field).val(val);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceDynamicTargetCustomField');
    }
}

function buildCouponsDisplay() {
    findCouponsOnPages('display');
}

function buildCouponsSubmit() {
    findCouponsOnPages('submit');
}

function findCouponsOnPages(couponPopulateOn) {
    try {
        var mtags = [];

        $('div:contains("[COUPON_")').each(function() {
            if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                var cgidParts = $(this).html().split('[COUPON_');
                if (cgidParts.length > 1) {
                    for (var i = 1; i < cgidParts.length; i++) {
                        if (boxapi.contains(cgidParts[i], ']')) {
                            var cgid = cgidParts[i].split(']')[0];
                            if (cgid && !boxapi.contains(mtags, cgid)) {
                                mtags.push(cgid);
                            }
                        }
                    }
                }
            }
        });

        $('button:contains("[COUPON_")').each(function() {
            if ($(this).children().length < 1) {
                var cgidParts = $(this).html().split('[COUPON_');
                if (cgidParts.length > 1) {
                    for (var i = 1; i < cgidParts.length; i++) {
                        if (boxapi.contains(cgidParts[i], ']')) {
                            var cgid = cgidParts[i].split(']')[0];
                            if (cgid && !boxapi.contains(mtags, cgid)) {
                                mtags.push(cgid);
                            }
                        }
                    }
                }
            }
        });

        $('input,select,textarea').each(function() {
            if (boxapi.contains($(this).val(), '[COUPON_')) {
                var cgidParts = $(this).val().split('[COUPON_');
                if (cgidParts.length > 1) {
                    for (var i = 1; i < cgidParts.length; i++) {
                        if (boxapi.contains(cgidParts[i], ']')) {
                            var cgid = cgidParts[i].split(']')[0];
                            if (cgid && !boxapi.contains(mtags, cgid)) {
                                mtags.push(cgid);
                            }
                        }
                    }
                }
            }
        });

        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - findCouponsOnPages: ' + couponPopulateOn);
        logger('mtags ==>');
        logger(mtags);

        //Ensure we only make the minimum number of async calls to our coupon endpoint by pre-aggregating all unique coupon codes
        if (mtags.length > 0) {
            for (var i = 0; i < mtags.length; i++) {
                if (couponPopulateOn === 'display') {
                    if (parent.DIGIOH_API.hasOwnProperty('COUPON_GROUP_POPULATE_OBJ') && parent.DIGIOH_API.COUPON_GROUP_POPULATE_OBJ.hasOwnProperty(mtags[i]) && parent.DIGIOH_API.COUPON_GROUP_POPULATE_OBJ[mtags[i]] === 'submit' && !COUPONS_FOR_SUBMIT.hasOwnProperty(mtags[i])) {
                        COUPONS_FOR_SUBMIT[mtags[i]] = false;
                    } else if (!parent.DIGIOH_API.hasOwnProperty('COUPON_GROUP_POPULATE_OBJ') || !parent.DIGIOH_API.COUPON_GROUP_POPULATE_OBJ.hasOwnProperty(mtags[i])) {
                        COUPONS_FOR_SUBMIT[mtags[i]] = false;
                    }
                }

                if (parent.DIGIOH_API.hasOwnProperty('COUPON_GROUP_POPULATE_OBJ')) {
                    if (parent.DIGIOH_API.COUPON_GROUP_POPULATE_OBJ.hasOwnProperty(mtags[i])) {
                        if (parent.DIGIOH_API.COUPON_GROUP_POPULATE_OBJ[mtags[i]] === couponPopulateOn) {
                            insertCouponCodeAsync(mtags[i], couponPopulateOn, '1');
                            logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - findCouponsOnPages: ' + couponPopulateOn + ' (' + mtags[i] + ') section 1');
                        }
                    } else if (couponPopulateOn === 'submit') {
                        insertCouponCodeAsync(mtags[i], couponPopulateOn, '2');
                        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - findCouponsOnPages: ' + couponPopulateOn + ' (' + mtags[i] + ') section 2');
                    }
                } else if (couponPopulateOn === 'submit') {
                    insertCouponCodeAsync(mtags[i], couponPopulateOn, '3');
                    logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - findCouponsOnPages: ' + couponPopulateOn + ' (' + mtags[i] + ') section 3');
                } else {
                    logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - findCouponsOnPages: ' + couponPopulateOn + ' (' + mtags[i] + ') section 4 - no match');
                }
            }
        }

        logger('COUPONS_FOR_SUBMIT ==>');
        logger(COUPONS_FOR_SUBMIT);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'findCouponsOnPages');
    }
}


function insertCouponCodeAsync(coupon_group_id, populate_on, code_section_trigger) {
    try {
        var couponApiUrl = 'https://coupon.lightboxcdn.com/Coupon/GetCoupon?user_id=' + VENDOR_SHORT_ID + '&coupon_group_id=' + coupon_group_id + '&client_id=' + CLIENT_GUID;

        if (COUPONS_FOR_DISPLAY.hasOwnProperty(coupon_group_id) && COUPONS_FOR_DISPLAY[coupon_group_id]) {
            var couponText = COUPONS_FOR_DISPLAY[coupon_group_id];

            $('div:contains("[COUPON_' + coupon_group_id + ']")').each(function() {
                if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                    $(this).html($(this).html().split('[COUPON_' + coupon_group_id + ']').join(couponText));
                }
            });

            $('button:contains("[COUPON_' + coupon_group_id + ']")').each(function() {
                if ($(this).children().length < 1) {
                    $(this).html($(this).html().split('[COUPON_' + coupon_group_id + ']').join(couponText));
                }
            });

            $('input,select,textarea').each(function() {
                if (boxapi.contains($(this).val(), "[COUPON_" + coupon_group_id + "]")) {
                    $(this).val($(this).val().split("[COUPON_" + coupon_group_id + "]").join(couponText));
                }
            });
        } else {
            $.ajax({
                dataType: 'jsonp',
                url: couponApiUrl,
                success: function(data) {
                    if (data && typeof data === 'object' && data !== null && data.hasOwnProperty('success') && data.success) {
                        if (data.hasOwnProperty('payload')) {
                            logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - GetCoupon: SUCCESS ==>');
                            logger(data);

                            var couponText = data.payload;
                            COUPONS_FOR_DISPLAY[coupon_group_id] = couponText;

                            $('div:contains("[COUPON_' + coupon_group_id + ']")').each(function() {
                                if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                                    $(this).html($(this).html().split('[COUPON_' + coupon_group_id + ']').join(couponText));
                                }
                            });

                            $('button:contains("[COUPON_' + coupon_group_id + ']")').each(function() {
                                if ($(this).children().length < 1) {
                                    $(this).html($(this).html().split('[COUPON_' + coupon_group_id + ']').join(couponText));
                                }
                            });

                            $('input,select,textarea').each(function() {
                                if (boxapi.contains($(this).val(), "[COUPON_" + coupon_group_id + "]")) {
                                    $(this).val($(this).val().split("[COUPON_" + coupon_group_id + "]").join(couponText));
                                }
                            });

                            postMessageCouponUsed(coupon_group_id, data, 'success', populate_on, code_section_trigger, '1', CURRENT_PAGE);

                        } else {
                            postMessageCouponUsed(coupon_group_id, data, 'failure', populate_on, code_section_trigger, '2', CURRENT_PAGE);

                            logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - GetCoupon: FAILURE 2 ==>');
                            logger(data);
                        }
                    } else if (data && typeof data === 'object' && data !== null) {
                        postMessageCouponUsed(coupon_group_id, data, 'failure', populate_on, code_section_trigger, '3', CURRENT_PAGE);

                        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - GetCoupon: FAILURE 3 ==>');
                        logger(data);
                    } else {
                        postMessageCouponUsed(coupon_group_id, 'null', 'failure', populate_on, code_section_trigger, '4', CURRENT_PAGE);

                        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - GetCoupon: FAILURE 4 ==>');
                        logger(data);
                    }

                    if (COUPONS_FOR_SUBMIT.hasOwnProperty(coupon_group_id)) {
                        COUPONS_FOR_SUBMIT[coupon_group_id] = true;
                    }

                },
                error: function(htmltext, textStatus, errorThrown) {
                    if (COUPONS_FOR_SUBMIT.hasOwnProperty(coupon_group_id)) {
                        COUPONS_FOR_SUBMIT[coupon_group_id] = true;
                    }

                    postMessageCouponUsed(coupon_group_id, {
                        textStatus: textStatus
                    }, 'error', populate_on, code_section_trigger, '5', CURRENT_PAGE);

                    logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - GetCoupon: FAILURE 5 ==>');
                    logger(textStatus);

                    BOX_CUSTOM_JS.logError(errorThrown, 'insertCouponCodeAsync');
                }
            });
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'insertCouponCodeAsync');
    }
}

function replaceHrefMergeTags() {
    try {
        $('div:contains("[[LINK|"),p:contains("[[LINK|"),span:contains("[[LINK|")').each(function() {
            if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                var divParts = $(this).html().split('[[LINK|');
                if (divParts.length > 1) {
                    for (var i = 1; i < divParts.length; i++) {
                        if (boxapi.contains(divParts[i], ']]')) {
                            var divLink = divParts[i].split(']]')[0].split('|')[0];
                            var divText = '';
                            var divStyle = '';

                            var divReplace = '[[LINK|' + divLink + ']]';

                            if (divParts[i].split(']]')[0].split('|').length > 1) {
                                divText = divParts[i].split(']]')[0].split('|')[1];
                                divReplace = '[[LINK|' + divLink + '|' + divText + ']]';
                            }

                            if (divParts[i].split(']]')[0].split('|').length > 2) {
                                divStyle = divParts[i].split(']]')[0].split('|')[2];
                                divReplace = '[[LINK|' + divLink + '|' + divText + '|' + divStyle + ']]';
                            }

                            if (divText.length < 1) {
                                divText = divLink;
                            }

                            if (!boxapi.contains(divLink, '://')) {
                                divLink = 'https://' + divLink;
                            }

                            $(this).html($(this).html().split(divReplace).join("<a target='_blank' href='" + divLink + "' style='" + divStyle + "'>" + divText + "</a>"));
                        }
                    }
                }
            }
        });
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceHrefMergeTags');
    }
}

function replaceBrMergeTags() {
    try {
        $('div:contains("[[BR]]"),p:contains("[[BR]]"),span:contains("[[BR]]")').each(function() {
            if ($(this).children().length < 1 || ($(this).children('a').length + $(this).children('br').length) === $(this).children().length) {
                var divParts = $(this).html().split('[[BR]]');
                if (divParts.length > 1) {
                    $(this).html(divParts.join('<br>'));
                }
            }
        });
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'replaceBrMergeTags');
    }
}

function showLoading(pref) {
    var modal_width = 0;
    var modal_height = 0;

    pref = getUnfriendlyPagePrefix(pref);

    if (CURRENT_WIDTH && CURRENT_HEIGHT) {
        modal_width = CURRENT_WIDTH;
        modal_height = CURRENT_HEIGHT;
    } else if (pref === 'thx_' && settings.hasOwnProperty('thxlayout')) {
        modal_width = settings.thxlayout.width;
        modal_height = settings.thxlayout.height;
    } else if (pref.indexOf('ep') === 0) {
        var pNum = getExtraPageNumberFromEPString(pref);
        if (settings.hasOwnProperty('ep' + pNum + 'layout')) {
            modal_width = settings['ep' + pNum + 'layout'].width;
            modal_height = settings['ep' + pNum + 'layout'].height;
        } else {
            modal_width = settings.layout.width;
            modal_height = settings.layout.height;
        }
    } else {
        modal_width = settings.layout.width;
        modal_height = settings.layout.height;
    }


    var foundLoadingOverride = false;

    if (settings.hasOwnProperty(pref + 'form') && settings[pref + 'form'].hasOwnProperty('loading_image') && settings[pref + 'form'].loading_image) {
        if (settings[pref + 'form'].loading_image === 'hide') {
            body.removeClass('loading');
            foundLoadingOverride = true;
        } else if (settings[pref + 'form'].loading_image === 'other' && settings[pref + 'form'].hasOwnProperty('loading_image_custom') && settings[pref + 'form'].loading_image_custom) {
            if ($('#modal_loading_custom').length)
                $('#modal_loading_custom').attr('style', "position:fixed;z-index:90000;top:0;left:0;height:100%;width:100%;background:url(https://s3.lightboxcdn.com/vendors/" + VENDOR_GUID + "/uploads/" + settings[pref + 'form'].loading_image_custom + ") 50% 50% no-repeat rgba(255,255,255,.1)");
            else
                $('#modal_loading').append("<div id='modal_loading_custom' style='position:fixed;z-index:90000;top:0;left:0;height:100%;width:100%;background:url(https://s3.lightboxcdn.com/vendors/" + VENDOR_GUID + "/uploads/" + settings[pref + 'form'].loading_image_custom + ") 50% 50% no-repeat rgba(255,255,255,.1)'></div>");

            $('#modal_loading_spinner').hide();
            body.addClass('loading');
            foundLoadingOverride = true;
        }
    }

    if (!foundLoadingOverride) {
        if ($('#modal_loading_custom').length)
            $('#modal_loading_custom').hide();

        $('#modal_loading_spinner').css('left', ((Math.round(modal_width / 2) - 10) + 'px'));
        $('#modal_loading_spinner').css('top', ((Math.round(modal_height / 2) - 10) + 'px'));
        $('#modal_loading_spinner').show();
        body.addClass('loading');
    }
}

function hideLoading() {
    //setTimeout(function () { 
    //    body.removeClass('loading');
    //}, 3000);

    body.removeClass('loading');
}


function determineGoogleFonts() {
    var pref = '';
    for (var j = 1; j <= 102; j++) {
        //if (i === 1) {
        //    pref = '';
        //} else if (i === 2) {
        //    pref = 'thx';
        //} else if (i === 3) {
        //    pref = 'ep1';
        //} else if (i === 4) {
        //    pref = 'ep2';
        //} else if (i === 5) {
        //    pref = 'ep3';
        //} else if (i === 6) {
        //    pref = 'ep4';
        //}

        if (j == 1) {
            pref = '';
        } else if (j == 2) {
            pref = 'thx';
        } else if (j >= 3 && j <= 6) {
            pref = 'ep' + (j - 2);
        } else if (j >= 7) {
            pref = 'ep' + (j - 2);

            if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (j - 3) || !settings.extra_pages[j - 3] || settings.extra_pages[j - 3]['on'] !== 1) {
                continue;
            }
        }

        for (var x = 1; x <= 50; x++) {
            if (settings.hasOwnProperty(pref + 'text' + x) && settings[pref + 'text' + x].display) addGoogleFontToStack(settings[pref + 'text' + x].font.family);
            if (settings.hasOwnProperty(pref + 'button' + x) && settings[pref + 'button' + x].display) addGoogleFontToStack(settings[pref + 'button' + x].font.family);
            if (settings.hasOwnProperty(pref + 'button' + x) && settings[pref + 'button' + x].display) addGoogleFontToStack(settings[pref + 'button' + x].font_hover.family);
            if (settings.hasOwnProperty(pref + 'button' + x) && settings[pref + 'button' + x].display) addGoogleFontToStack(settings[pref + 'button' + x].font_focus.family);
        }
    }

    loadGoogleFontsFromStack();
}

function loadExternalFonts(pref) {
    try {
        if (typeof pref !== 'string' || pref === 'main') {
            pref = '';
        }

        if (boxapi.contains(pref, '_')) {
            pref = pref.split('_')[0];
        }

        if (pref !== '' && !LoadedCustomFonts.hasOwnProperty(pref)) {
            LoadedCustomFonts[pref] = true;
        } else if (LoadedCustomFonts.hasOwnProperty(pref) && LoadedCustomFonts[pref] === true) {
            return;
        }

        logger('loadExternalFonts(' + pref + ')');

        for (var x = 1; x <= 50; x++) {
            if (settings.hasOwnProperty(pref + 'text' + x) && settings[pref + 'text' + x].display) addCustomFontToStack(settings[pref + 'text' + x].font.family);
            if (settings.hasOwnProperty(pref + 'button' + x) && settings[pref + 'button' + x].display) addCustomFontToStack(settings[pref + 'button' + x].font.family);
            if (settings.hasOwnProperty(pref + 'button' + x) && settings[pref + 'button' + x].display) addCustomFontToStack(settings[pref + 'button' + x].font_hover.family);
            if (settings.hasOwnProperty(pref + 'button' + x) && settings[pref + 'button' + x].display) addCustomFontToStack(settings[pref + 'button' + x].font_focus.family);
        }

        var pr = pref;
        if (pr !== '')
            pr = pr + '_';

        if (settings.hasOwnProperty(pr + 'labels'))
            addCustomFontToStack(settings[pr + 'labels'].font.family);

        if (settings.hasOwnProperty(pr + 'inputs'))
            addCustomFontToStack(settings[pr + 'inputs'].font.family);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'loadExternalFonts');
    }
}

function addCustomFontToStack(f) {
    try {
        if (f.indexOf('__custom__') >= 0 && f.indexOf('||||') >= 0) {
            var font_parts = f.split('||||');
            var font_name = font_parts[1];
            var font_guid = font_parts[2];
            var font_url = PROTOCOL_USER_OVERRIDE + 's3.lightboxcdn.com/custom_fonts/' + font_guid + '.css' + '?cb=' + CACHE_VERSION;

            if ($.inArray(font_name, basic_fonts) === -1 && $.inArray(font_name, custom_fonts) === -1) {
                //logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - custom_font_builder: ' + font_name);

                custom_fonts.push(font_name);

                var h = document.head || document.getElementsByTagName('head')[0];
                var l = document.createElement('link');
                l.type = 'text/css';
                l.rel = 'stylesheet';
                l.href = font_url;
                h.appendChild(l);
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'addCustomFontToStack');
    }
}

function addGoogleFontToStack(f) {
    try {
        var font_name = '';

        if (f.indexOf('__google__') >= 0) {
            font_name = f.replace('__google__', '').split("'")[1];
        } else if (f && f.indexOf('__custom__') === -1 && f.length > 10 && $.inArray(f, basic_fonts) === -1) {
            font_name = f.split("'")[1];
        }

        if (font_name && font_name.length > 1 && $.inArray(font_name, google_fonts) === -1) {
            google_fonts.push(font_name);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'addGoogleFontToStack');
    }
}

function loadGoogleFontsFromStack() {
    try {
        if (google_fonts.length > 0) {
            var font_builder = 'https://fonts.googleapis.com/css?family=';
            var font_fam = '';

            for (var i = 0; i < google_fonts.length; i++) {
                font_fam = google_fonts[i];
                if (font_fam.indexOf(' ') > 0) {
                    font_fam = font_fam.split(' ').join('+');
                }
                font_builder += font_fam;

                if (i < (google_fonts.length - 1)) {
                    font_builder += '|';
                }
            }

            //logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - google_font_builder: ' + font_builder);

            var h = document.head || document.getElementsByTagName('head')[0];
            var l = document.createElement('link');
            l.type = 'text/css';
            l.rel = 'stylesheet';
            l.href = font_builder + '&display=fallback';
            h.appendChild(l);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'loadGoogleFontsFromStack');
    }
}



function buildText() {
    try {
        var pr = '';

        for (var j = 1; j <= 102; j++) {
            //var pr = '';
            //if (y === 5) pr = 'thx';
            //else if (y === 6) pr = '';
            //else pr = 'ep' + y;

            if (j == 1) {
                pr = '';
            } else if (j == 2) {
                pr = 'thx';
            } else if (j >= 3 && j <= 6) {
                pr = 'ep' + (j - 2);
            } else if (j >= 7) {
                pr = 'ep' + (j - 2);

                if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (j - 3) || !settings.extra_pages[j - 3] || settings.extra_pages[j - 3]['on'] !== 1) {
                    continue;
                }
            }

            for (var x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'text' + x) && settings[pr + 'text' + x].display) {
                    $('#' + pr + 'text' + x).text(settings[pr + 'text' + x].text);

                    if (settings[pr + 'text' + x].hasOwnProperty('metadata_kvps')) {
                        for (var k = 0; k < settings[pr + 'text' + x].metadata_kvps.length; k++) {
                            if (settings[pr + 'text' + x].metadata_kvps[k].k && settings[pr + 'text' + x].metadata_kvps[k].v) {
                                trySetAttribute(pr + 'text' + x, settings[pr + 'text' + x].metadata_kvps[k]);
                            }
                        }
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildText');
    }
}

function appendScript(scriptHtml) {
    try {
        var j = document.createElement('script');
        j.type = 'text/javascript';
        j.async = true;
        j.text = scriptHtml;

        //var s = document.getElementsByTagName('script')[0];
        //s.parentNode.insertBefore(j, s);

        document.body.appendChild(j);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'appendScript');
    }
}

function buildHTMLItemAndEvalJSFromHtml(htmlEle, htmlId) {
    try {
        if (!settings.hasOwnProperty(htmlId) || !settings[htmlId] || !settings[htmlId].hasOwnProperty('display') || !settings[htmlId].hasOwnProperty('html') || !settings[htmlId].display || !settings[htmlId].html) {
            return;
        } else if (settings[htmlId].html.indexOf("script") === -1) {
            htmlEle.html(settings[htmlId].html);
        } else {
            var htmlElement = document.getElementById(htmlId);
            htmlElement.innerHTML = settings[htmlId].html;

            var scripts = htmlElement.getElementsByTagName("script");
            for (var i = 0; i < scripts.length; ++i) {
                var script = scripts[i];
                if (script.innerHTML && script.innerHTML.length > 0) {
                    eval(script.innerHTML);
                    //logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - buildHTMLItemAndEvalJSFromHtml: inline eval script #' + i + ' ==> (' + script.innerHTML.length + ')');
                } else if (script.hasAttribute("src")) {
                    var elSrc = script.getAttribute("src");
                    if (typeof elSrc === 'string' && elSrc.indexOf('//') >= 0) {
                        var elRef = document.createElement('script');
                        elRef.setAttribute("type", "text/javascript");
                        elRef.setAttribute("src", elSrc);
                        elRef.async = true;
                        document.getElementsByTagName("head")[0].appendChild(elRef);
                        //logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - buildHTMLItemAndEvalJSFromHtml: external load script #' + i + ' ==> (' + elSrc + ')');
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildHTMLItemAndEvalJSFromHtml');
    }
}

function buildHTML() {
    try {
        var pr = '';

        for (var j = 1; j <= 102; j++) {
            //var pr = '';
            //if (y === 5) pr = 'thx';
            //else if (y === 6) pr = '';
            //else pr = 'ep' + y;

            if (j == 1) {
                pr = '';
            } else if (j == 2) {
                pr = 'thx';
            } else if (j >= 3 && j <= 6) {
                pr = 'ep' + (j - 2);
            } else if (j >= 7) {
                pr = 'ep' + (j - 2);

                if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (j - 3) || !settings.extra_pages[j - 3] || settings.extra_pages[j - 3]['on'] !== 1) {
                    continue;
                }
            }

            for (var x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'html' + x) && settings[pr + 'html' + x].display) {
                    buildHTMLItemAndEvalJSFromHtml($('#' + pr + 'html' + x), pr + 'html' + x);

                    if (settings[pr + 'html' + x].hasOwnProperty('metadata_kvps')) {
                        for (var k = 0; k < settings[pr + 'html' + x].metadata_kvps.length; k++) {
                            if (settings[pr + 'html' + x].metadata_kvps[k].k && settings[pr + 'html' + x].metadata_kvps[k].v) {
                                trySetAttribute(pr + 'html' + x, settings[pr + 'html' + x].metadata_kvps[k]);
                            }
                        }
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildHTML');
    }
}

function buildForm() {
    try {
        using_form = settings.hasOwnProperty('form') && settings.form.display;
        using_form_thx = settings.hasOwnProperty('thxlayout') && settings.hasOwnProperty('thx_form') && settings.thx_form.display;
        using_form_ep1 = settings.hasOwnProperty('ep1layout') && settings.hasOwnProperty('ep1_form') && settings.ep1_form.display;
        using_form_ep2 = settings.hasOwnProperty('ep2layout') && settings.hasOwnProperty('ep2_form') && settings.ep2_form.display;
        using_form_ep3 = settings.hasOwnProperty('ep3layout') && settings.hasOwnProperty('ep3_form') && settings.ep3_form.display;
        using_form_ep4 = settings.hasOwnProperty('ep4layout') && settings.hasOwnProperty('ep4_form') && settings.ep4_form.display;

        if (using_form) {
            form.empty();
            buildFormName('', form);
            buildFormEmail('', form);
            buildFormPhone('', form);

            for (var i = 1; i <= 50; i++) {
                buildFormCustomN('', 'custom' + i, form);
            }

            buildFormOptIn('', form);
        }

        if (using_form_thx) {
            thx_form.empty();
            buildFormName('thx', thx_form);
            buildFormEmail('thx', thx_form);
            buildFormPhone('thx', thx_form);

            for (var i = 1; i <= 50; i++) {
                buildFormCustomN('thx', 'thx_custom' + i, thx_form);
            }

            buildFormOptIn('thx', thx_form);
        }

        if (using_form_ep1) {
            ep1_form.empty();
            buildFormName('ep1', ep1_form);
            buildFormEmail('ep1', ep1_form);
            buildFormPhone('ep1', ep1_form);

            for (var i = 1; i <= 50; i++) {
                buildFormCustomN('ep1', 'ep1_custom' + i, ep1_form);
            }

            buildFormOptIn('ep1', ep1_form);
        }

        if (using_form_ep2) {
            ep2_form.empty();
            buildFormName('ep2', ep2_form);
            buildFormEmail('ep2', ep2_form);
            buildFormPhone('ep2', ep2_form);

            for (var i = 1; i <= 50; i++) {
                buildFormCustomN('ep2', 'ep2_custom' + i, ep2_form);
            }

            buildFormOptIn('ep2', ep2_form);
        }

        if (using_form_ep3) {
            ep3_form.empty();
            buildFormName('ep3', ep3_form);
            buildFormEmail('ep3', ep3_form);
            buildFormPhone('ep3', ep3_form);

            for (var i = 1; i <= 50; i++) {
                buildFormCustomN('ep3', 'ep3_custom' + i, ep3_form);
            }

            buildFormOptIn('ep3', ep3_form);
        }

        if (using_form_ep4) {
            ep4_form.empty();
            buildFormName('ep4', ep4_form);
            buildFormEmail('ep4', ep4_form);
            buildFormPhone('ep4', ep4_form);

            for (var i = 1; i <= 50; i++) {
                buildFormCustomN('ep4', 'ep4_custom' + i, ep4_form);
            }

            buildFormOptIn('ep4', ep4_form);
        }

        if (!using_form && $('#form_wrapper').length) {
            form_wrapper.hide();
            form.hide();
        }

        if (!using_form_thx && $('#thx_form_wrapper').length) {
            thx_form_wrapper.hide();
            thx_form.hide();
        }

        if (!using_form_ep1 && $('#ep1_form_wrapper').length) {
            ep1_form_wrapper.hide();
            ep1_form.hide();
        }

        if (!using_form_ep2 && $('#ep2_form_wrapper').length) {
            ep2_form_wrapper.hide();
            ep2_form.hide();
        }

        if (!using_form_ep3 && $('#ep3_form_wrapper').length) {
            ep3_form_wrapper.hide();
            ep3_form.hide();
        }

        if (!using_form_ep4 && $('#ep4_form_wrapper').length) {
            ep4_form_wrapper.hide();
            ep4_form.hide();
        }

        if (settings.hasOwnProperty("extra_pages")) {
            for (var j = 5; j <= 100; j++) {
                var pr = '';

                if (settings.extra_pages.length < j || !settings.extra_pages[j - 1] || settings.extra_pages[j - 1]['on'] !== 1) {
                    continue;
                }

                pr = 'ep' + j;

                if (settings.hasOwnProperty('ep' + j + 'layout') && settings.hasOwnProperty('ep' + j + '_form') && settings['ep' + j + '_form'].display) {
                    if ($('#ep' + j + '_form').length) {
                        $('#ep' + j + '_form').empty();
                    }

                    buildFormName('ep' + j, $('#ep' + j + '_form'));
                    buildFormEmail('ep' + j, $('#ep' + j + '_form'));
                    buildFormPhone('ep' + j, $('#ep' + j + '_form'));

                    for (var i = 1; i <= 50; i++) {
                        buildFormCustomN('ep' + j, 'ep' + j + '_custom' + i, $('#ep' + j + '_form'));
                    }

                    buildFormOptIn('ep' + j, $('#ep' + j + '_form'));
                } else if ($('#ep' + j + '_form_wrapper').length) {
                    $('#ep' + j + '_form_wrapper').hide();
                    $('#ep' + j + '_form').hide();
                }
            }
        }


        initFormInputs();
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildForm');
    }
}


function trySetAttribute(dom_id, kvp) {
    try {
        //attribute name is invalid so it will throw an error
        //var element = document.getElementById("myElement");
        //element.setAttribute("", "value");

        var did = '#' + dom_id;
        if (dom_id == 'body')
            did = 'body';

        if (kvp.k === 'class')
            $(did).addClass(kvp.v);
        else
            $(did).attr(kvp.k, kvp.v);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'trySetAttribute');
    }
}

function buildButtons() {
    try {
        var pr = '';

        for (var j = 1; j <= 102; j++) {
            //var pr = '';
            //if (y === 5) pr = 'thx';
            //else if (y === 6) pr = '';
            //else pr = 'ep' + y;

            if (j == 1) {
                pr = '';
            } else if (j == 2) {
                pr = 'thx';
            } else if (j >= 3 && j <= 6) {
                pr = 'ep' + (j - 2);
            } else if (j >= 7) {
                pr = 'ep' + (j - 2);

                if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (j - 3) || !settings.extra_pages[j - 3] || settings.extra_pages[j - 3]['on'] !== 1) {
                    continue;
                }
            }

            for (var x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'button' + x) && settings[pr + 'button' + x].display) {
                    if (pr === '') {
                        buildButtonN($('#' + pr + 'button' + x), $('#' + pr + 'button' + x + '_wrapper'), pr + 'button' + x, settings[pr + 'button' + x], '');
                    } else {
                        buildButtonN($('#' + pr + 'button' + x), $('#' + pr + 'button' + x + '_wrapper'), pr + 'button' + x, settings[pr + 'button' + x], pr + '_');
                    }

                    if (settings[pr + 'button' + x].hasOwnProperty('metadata_kvps')) {
                        for (var k = 0; k < settings[pr + 'button' + x].metadata_kvps.length; k++) {
                            if (settings[pr + 'button' + x].metadata_kvps[k].k && settings[pr + 'button' + x].metadata_kvps[k].v && settings[pr + 'button' + x].metadata_kvps[k].k.indexOf('[') === -1) {
                                trySetAttribute(pr + 'button' + x, settings[pr + 'button' + x].metadata_kvps[k]);
                            }
                        }
                    }

                    if (typeof $('#' + pr + 'button' + x).attr('aria-label') !== 'string' || $('#' + pr + 'button' + x).attr('aria-label').length < 1) {
                        if (settings[pr + 'button' + x].action == 'submit') {
                            $('#' + pr + 'button' + x).attr('aria-label', 'Submit Modal Form');
                        } else if (settings[pr + 'button' + x].action == 'close') {
                            $('#' + pr + 'button' + x).attr('aria-label', 'Close Modal');
                        } else if (settings[pr + 'button' + x].action == 'url') {
                            $('#' + pr + 'button' + x).attr('aria-label', 'Redirect to URL');
                        } else if (settings[pr + 'button' + x].action == 'download') {
                            $('#' + pr + 'button' + x).attr('aria-label', 'Download File');
                        } else if (settings[pr + 'button' + x].action == 'lightbox_open') {
                            $('#' + pr + 'button' + x).attr('aria-label', 'Open Another Modal');
                        } else if (settings[pr + 'button' + x].action.indexOf('_page') > 0) {
                            $('#' + pr + 'button' + x).attr('aria-label', 'Open Next Modal Page');
                        }
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildButtons');
    }
}

function initFormInputs() {
    try {
        if ($('#form_input_full_name').length) form_input_full_name = $('#form_input_full_name');
        if ($('#form_input_first_name').length) form_input_first_name = $('#form_input_first_name');
        if ($('#form_input_last_name').length) form_input_last_name = $('#form_input_last_name');
        if ($('#form_input_email').length) form_input_email = $('#form_input_email');
        if ($('#form_input_phone').length) form_input_phone = $('#form_input_phone');
        if ($('#form_input_opt_in').length) form_input_opt_in = $('#form_input_opt_in');

        if ($('#thx_form_input_full_name').length) thx_form_input_full_name = $('#thx_form_input_full_name');
        if ($('#thx_form_input_first_name').length) thx_form_input_first_name = $('#thx_form_input_first_name');
        if ($('#thx_form_input_last_name').length) thx_form_input_last_name = $('#thx_form_input_last_name');
        if ($('#thx_form_input_email').length) thx_form_input_email = $('#thx_form_input_email');
        if ($('#thx_form_input_phone').length) thx_form_input_phone = $('#thx_form_input_phone');
        if ($('#thx_form_input_opt_in').length) thx_form_input_opt_in = $('#thx_form_input_opt_in');

        if ($('#ep1_form_input_full_name').length) ep1_form_input_full_name = $('#ep1_form_input_full_name');
        if ($('#ep1_form_input_first_name').length) ep1_form_input_first_name = $('#ep1_form_input_first_name');
        if ($('#ep1_form_input_last_name').length) ep1_form_input_last_name = $('#ep1_form_input_last_name');
        if ($('#ep1_form_input_email').length) ep1_form_input_email = $('#ep1_form_input_email');
        if ($('#ep1_form_input_phone').length) ep1_form_input_phone = $('#ep1_form_input_phone');
        if ($('#ep1_form_input_opt_in').length) ep1_form_input_opt_in = $('#ep1_form_input_opt_in');

        if ($('#ep2_form_input_full_name').length) ep2_form_input_full_name = $('#ep2_form_input_full_name');
        if ($('#ep2_form_input_first_name').length) ep2_form_input_first_name = $('#ep2_form_input_first_name');
        if ($('#ep2_form_input_last_name').length) ep2_form_input_last_name = $('#ep2_form_input_last_name');
        if ($('#ep2_form_input_email').length) ep2_form_input_email = $('#ep2_form_input_email');
        if ($('#ep2_form_input_phone').length) ep2_form_input_phone = $('#ep2_form_input_phone');
        if ($('#ep2_form_input_opt_in').length) ep2_form_input_opt_in = $('#ep2_form_input_opt_in');

        if ($('#ep3_form_input_full_name').length) ep3_form_input_full_name = $('#ep3_form_input_full_name');
        if ($('#ep3_form_input_first_name').length) ep3_form_input_first_name = $('#ep3_form_input_first_name');
        if ($('#ep3_form_input_last_name').length) ep3_form_input_last_name = $('#ep3_form_input_last_name');
        if ($('#ep3_form_input_email').length) ep3_form_input_email = $('#ep3_form_input_email');
        if ($('#ep3_form_input_phone').length) ep3_form_input_phone = $('#ep3_form_input_phone');
        if ($('#ep3_form_input_opt_in').length) ep3_form_input_opt_in = $('#ep3_form_input_opt_in');

        if ($('#ep4_form_input_full_name').length) ep4_form_input_full_name = $('#ep4_form_input_full_name');
        if ($('#ep4_form_input_first_name').length) ep4_form_input_first_name = $('#ep4_form_input_first_name');
        if ($('#ep4_form_input_last_name').length) ep4_form_input_last_name = $('#ep4_form_input_last_name');
        if ($('#ep4_form_input_email').length) ep4_form_input_email = $('#ep4_form_input_email');
        if ($('#ep4_form_input_phone').length) ep4_form_input_phone = $('#ep4_form_input_phone');
        if ($('#ep4_form_input_opt_in').length) ep4_form_input_opt_in = $('#ep4_form_input_opt_in');

        for (var f = 1; f <= 50; f++) {
            if ($('#form_input_custom' + f).length) form_input_obj['form_input_custom' + f] = $('#form_input_custom' + f);
            if ($('#thx_form_input_custom' + f).length) form_input_obj['thx_form_input_custom' + f] = $('#thx_form_input_custom' + f);
            if ($('#ep1_form_input_custom' + f).length) form_input_obj['ep1_form_input_custom' + f] = $('#ep1_form_input_custom' + f);
            if ($('#ep2_form_input_custom' + f).length) form_input_obj['ep2_form_input_custom' + f] = $('#ep2_form_input_custom' + f);
            if ($('#ep3_form_input_custom' + f).length) form_input_obj['ep3_form_input_custom' + f] = $('#ep3_form_input_custom' + f);
            if ($('#ep4_form_input_custom' + f).length) form_input_obj['ep4_form_input_custom' + f] = $('#ep4_form_input_custom' + f);

            if (settings.hasOwnProperty("extra_pages")) {
                for (var j = 5; j <= 100; j++) {
                    if (settings.extra_pages.length >= j && settings.extra_pages[j - 1] && settings.extra_pages[j - 1]['on'] === 1 && $('#ep' + j + '_form_input_custom' + f).length) {
                        form_input_obj['ep' + j + '_form_input_custom' + f] = $('#ep' + j + '_form_input_custom' + f);
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'initFormInputs');
    }
}

function isNullOrWhiteSpace(str) {
    try {
        return (typeof str === 'undefined' || str === null || str.match(/^ *$/) !== null);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'isNullOrWhiteSpace');
        return false;
    }
}

function getFirstLastNames(fullName) {
    try {
        if (isNullOrWhiteSpace(fullName)) return ['', ''];

        fullName = fullName.trim();
        var parts = fullName.split(' ');

        if (parts.length == 0) return ['', ''];
        if (parts.length == 1) return [parts[0], ''];
        if (parts.length == 2) return [parts[0], parts[1]];

        var first = parts[0];

        var last = '';
        for (var x = 1; x < parts.length; x++) {
            if (!isNullOrWhiteSpace(parts[x])) {
                last += parts[x].trim() + ' ';
            }
        }

        if (last.length > 0) last = last.trim();

        return [first, last];
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'getFirstLastNames');
        return ['', ''];
    }
}

function getFullName(first, last) {
    try {
        if (isNullOrWhiteSpace(first)) first = '';
        else first = first.trim();

        if (isNullOrWhiteSpace(last)) last = '';
        else last = last.trim();

        if (first.length > 0 && last.length > 0) return (first + ' ' + last);
        if (first.length > 0) return first;
        if (last.length > 0) return last;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'getFullName');
        return (first + ' ' + last);
    }
}


function isValidEmail(email) {
    return parent.DIGIOH_API.isValidEmail(email);
}


function setPrefFormInputs(pref) {
    try {
        if (pref === 'thx_') {
            pref_form_input_full_name = thx_form_input_full_name;
            pref_form_input_first_name = thx_form_input_first_name;
            pref_form_input_last_name = thx_form_input_last_name;
            pref_form_input_email = thx_form_input_email;
            pref_form_input_phone = thx_form_input_phone;
            pref_form_input_opt_in = thx_form_input_opt_in;

            for (var f = 1; f <= 50; f++) {
                form_input_obj['pref_form_input_custom' + f] = form_input_obj['thx_form_input_custom' + f];
            }
        } else if (pref === 'ep1_') {
            pref_form_input_full_name = ep1_form_input_full_name;
            pref_form_input_first_name = ep1_form_input_first_name;
            pref_form_input_last_name = ep1_form_input_last_name;
            pref_form_input_email = ep1_form_input_email;
            pref_form_input_phone = ep1_form_input_phone;
            pref_form_input_opt_in = ep1_form_input_opt_in;

            for (var f = 1; f <= 50; f++) {
                form_input_obj['pref_form_input_custom' + f] = form_input_obj['ep1_form_input_custom' + f];
            }
        } else if (pref === 'ep2_') {
            pref_form_input_full_name = ep2_form_input_full_name;
            pref_form_input_first_name = ep2_form_input_first_name;
            pref_form_input_last_name = ep2_form_input_last_name;
            pref_form_input_email = ep2_form_input_email;
            pref_form_input_phone = ep2_form_input_phone;
            pref_form_input_opt_in = ep2_form_input_opt_in;

            for (var f = 1; f <= 50; f++) {
                form_input_obj['pref_form_input_custom' + f] = form_input_obj['ep2_form_input_custom' + f];
            }
        } else if (pref === 'ep3_') {
            pref_form_input_full_name = ep3_form_input_full_name;
            pref_form_input_first_name = ep3_form_input_first_name;
            pref_form_input_last_name = ep3_form_input_last_name;
            pref_form_input_email = ep3_form_input_email;
            pref_form_input_phone = ep3_form_input_phone;
            pref_form_input_opt_in = ep3_form_input_opt_in;

            for (var f = 1; f <= 50; f++) {
                form_input_obj['pref_form_input_custom' + f] = form_input_obj['ep3_form_input_custom' + f];
            }
        } else if (pref === 'ep4_') {
            pref_form_input_full_name = ep4_form_input_full_name;
            pref_form_input_first_name = ep4_form_input_first_name;
            pref_form_input_last_name = ep4_form_input_last_name;
            pref_form_input_email = ep4_form_input_email;
            pref_form_input_phone = ep4_form_input_phone;
            pref_form_input_opt_in = ep4_form_input_opt_in;

            for (var f = 1; f <= 50; f++) {
                form_input_obj['pref_form_input_custom' + f] = form_input_obj['ep4_form_input_custom' + f];
            }
        } else if (pref.indexOf('ep') === 0) {
            var pNum = getExtraPageNumberFromEPString(pref);

            if ($('#ep' + pNum + '_form_input_full_name').length) pref_form_input_full_name = $('#ep' + pNum + '_form_input_full_name');
            if ($('#ep' + pNum + '_form_input_first_name').length) pref_form_input_first_name = $('#ep' + pNum + '_form_input_first_name');
            if ($('#ep' + pNum + '_form_input_last_name').length) pref_form_input_last_name = $('#ep' + pNum + '_form_input_last_name');
            if ($('#ep' + pNum + '_form_input_email').length) pref_form_input_email = $('#ep' + pNum + '_form_input_email');
            if ($('#ep' + pNum + '_form_input_phone').length) pref_form_input_phone = $('#ep' + pNum + '_form_input_phone');
            if ($('#ep' + pNum + '_form_input_opt_in').length) pref_form_input_opt_in = $('#ep' + pNum + '_form_input_opt_in');

            for (var f = 1; f <= 50; f++) {
                if (form_input_obj.hasOwnProperty('ep' + pNum + '_form_input_custom' + f)) {
                    form_input_obj['pref_form_input_custom' + f] = form_input_obj['ep' + pNum + '_form_input_custom' + f];
                }
            }
        } else {
            pref_form_input_full_name = form_input_full_name;
            pref_form_input_first_name = form_input_first_name;
            pref_form_input_last_name = form_input_last_name;
            pref_form_input_email = form_input_email;
            pref_form_input_phone = form_input_phone;
            pref_form_input_opt_in = form_input_opt_in;

            for (var f = 1; f <= 50; f++) {
                form_input_obj['pref_form_input_custom' + f] = form_input_obj['form_input_custom' + f];
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'setPrefFormInputs');
    }
}

function validateForm(data, page_pref, get_data_only, override_data) {
    try {
        var pref = '';

        if (page_pref === null || typeof page_pref !== 'string' || page_pref === 'main') {
            pref = '';
        } else {
            pref = page_pref;
        }

        if (typeof data !== 'object' || data === null) {
            data = {};
        }

        if (typeof get_data_only !== 'boolean') {
            get_data_only = false;
        }

        if (typeof override_data !== 'boolean') {
            override_data = false;
        }


        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - validateForm(' + pref + ', ' + get_data_only + ')');


        setPrefFormInputs(pref);


        if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].display) {
            if (settings[pref + 'name'].mode == 'full') {
                if (!data.hasOwnProperty('name') || override_data) data.name = pref_form_input_full_name.val().trim();

                if (!get_data_only) {
                    if (settings[pref + 'name'].require && data.name.length == 0) {
                        if (settings[pref + 'name'].hasOwnProperty('error_text') && settings[pref + 'name'].error_text) {
                            showError(pref, 'name', settings[pref + 'name'].error_text);
                        } else {
                            showError(pref, 'name', settings[pref + 'name'].label + ' is required.');
                        }
                        return false;
                    } else if (data.name.length > 100) {
                        if (settings[pref + 'name'].hasOwnProperty('error_text') && settings[pref + 'name'].error_text) {
                            showError(pref, 'name', settings[pref + 'name'].error_text);
                        } else {
                            showError(pref, 'name', settings[pref + 'name'].label + ' must be less than 100 characters.');
                        }
                        return false;
                    }
                }

                var fl = getFirstLastNames(data.name);
                if (!data.hasOwnProperty('first_name') || override_data) data.first_name = fl[0];
                if (!data.hasOwnProperty('last_name') || override_data) data.last_name = fl[1];

            } else if (settings[pref + 'name'].mode == 'first') {
                if (!data.hasOwnProperty('first_name') || override_data) data.first_name = pref_form_input_first_name.val().trim();

                if (!get_data_only) {
                    if (settings[pref + 'name'].require && data.first_name.length == 0) {
                        if (settings[pref + 'name'].hasOwnProperty('error_text') && settings[pref + 'name'].error_text) {
                            showError(pref, 'name', settings[pref + 'name'].error_text);
                        } else {
                            showError(pref, 'name', settings[pref + 'name'].label + ' is required.');
                        }
                        return false;
                    }
                    if (data.first_name.length > 100) {
                        if (settings[pref + 'name'].hasOwnProperty('error_text') && settings[pref + 'name'].error_text) {
                            showError(pref, 'name', settings[pref + 'name'].error_text);
                        } else {
                            showError(pref, 'name', settings[pref + 'name'].label + ' must be less than 100 characters.');
                        }
                        return false;
                    }
                }

                if (!data.hasOwnProperty('name') || override_data) data.name = data.first_name;
                if (!data.hasOwnProperty('last_name') || override_data) data.last_name = '';

            } else if (settings[pref + 'name'].mode == 'both') {
                if (!data.hasOwnProperty('first_name') || override_data) data.first_name = pref_form_input_first_name.val().trim();
                if (!data.hasOwnProperty('last_name') || override_data) data.last_name = pref_form_input_last_name.val().trim();

                if (!get_data_only) {
                    if (settings[pref + 'name'].require && (data.first_name.length == 0 || data.last_name.length == 0)) {
                        if (settings[pref + 'name'].hasOwnProperty('error_text') && settings[pref + 'name'].error_text) {
                            showError(pref, 'name', settings[pref + 'name'].error_text);
                        } else {
                            showError(pref, 'name', 'First Name and Last Name are both required.');
                        }
                        return false;
                    }
                    if (data.first_name.length > 100) {
                        if (settings[pref + 'name'].hasOwnProperty('error_text') && settings[pref + 'name'].error_text) {
                            showError(pref, 'name', settings[pref + 'name'].error_text);
                        } else {
                            showError(pref, 'name', 'First Name must be less than 100 characters.');
                        }
                        return false;
                    }
                    if (data.last_name.length > 100) {
                        if (settings[pref + 'name'].hasOwnProperty('error_text') && settings[pref + 'name'].error_text) {
                            showError(pref, 'name', settings[pref + 'name'].error_text);
                        } else {
                            showError(pref, 'name', 'Last Name must be less than 100 characters.');
                        }
                        return false;
                    }
                }

                if (!data.hasOwnProperty('name') || override_data) data.name = getFullName(data.first_name, data.last_name);

            }
        }

        if (settings.hasOwnProperty(pref + 'email') && settings[pref + 'email'].display) {
            if (!data.hasOwnProperty('email') || override_data) data.email = pref_form_input_email.val().trim();

            if (!get_data_only) {
                if (settings[pref + 'email'].require && data.email.length == 0) {
                    if (settings[pref + 'email'].hasOwnProperty('error_text') && settings[pref + 'email'].error_text) {
                        showError(pref, 'email', settings[pref + 'email'].error_text);
                    } else {
                        showError(pref, 'email', settings[pref + 'email'].label + ' is required.');
                    }
                    return false;
                }
                if (data.email.length > 200) {
                    if (settings[pref + 'email'].hasOwnProperty('error_text') && settings[pref + 'email'].error_text) {
                        showError(pref, 'email', settings[pref + 'email'].error_text);
                    } else {
                        showError(pref, 'email', settings[pref + 'email'].label + ' must be less than 100 characters.');
                    }
                    return false;
                }

                //simple matching, anything in the format:  abc@abc.abc
                //var valid_email_regex = /\S+@\S+\.\S+/;
                //if (!valid_email_regex.test(data.email)) {

                data.email = data.email.replace(/\s+/g, '');

                if (!isValidEmail(data.email)) {
                    //don't validate email format if it is blank and not-required
                    if (data.email.length > 0 || (data.email.length == 0 && settings[pref + 'email'].require)) {
                        if (settings[pref + 'email'].hasOwnProperty('error_text') && settings[pref + 'email'].error_text) {
                            showError(pref, 'email', settings[pref + 'email'].error_text);
                        } else {
                            showError(pref, 'email', settings[pref + 'email'].label + ' is in an invalid format.');
                        }
                        return false;
                    }
                }
            }
        }

        if (settings.hasOwnProperty(pref + 'phone') && settings[pref + 'phone'].display) {
            if (!data.hasOwnProperty('phone') || override_data) data.phone = pref_form_input_phone.val().trim();

            if (!get_data_only) {
                if (settings[pref + 'phone'].require && data.phone.length == 0) {
                    if (settings[pref + 'phone'].hasOwnProperty('error_text') && settings[pref + 'phone'].error_text) {
                        showError(pref, 'phone', settings[pref + 'phone'].error_text);
                    } else {
                        showError(pref, 'phone', settings[pref + 'phone'].label + ' is required.');
                    }
                    return false;
                }
                if (data.phone.length > 20) {
                    if (settings[pref + 'phone'].hasOwnProperty('error_text') && settings[pref + 'phone'].error_text) {
                        showError(pref, 'phone', settings[pref + 'phone'].error_text);
                    } else {
                        showError(pref, 'phone', settings[pref + 'phone'].label + ' must be less than 20 characters.');
                    }
                    return false;
                }

                if (settings[pref + 'phone'].hasOwnProperty('validation') && settings[pref + 'phone'].validation && data.phone.length > 0) {
                    data.phone = data.phone.replace(/\D/g, '');
                    if (settings[pref + 'phone'].validation === 'phone_10' && data.phone.length !== 10) {
                        if (settings[pref + 'phone'].hasOwnProperty('error_text') && settings[pref + 'phone'].error_text) {
                            showError(pref, 'phone', settings[pref + 'phone'].error_text);
                        } else {
                            showError(pref, 'phone', settings[pref + 'phone'].label + ' must be 10 digits.');
                        }
                        return false;
                    } else if (settings[pref + 'phone'].validation === 'phone_usa') {
                        if (data.phone.length === 10 && data.phone.indexOf('1') !== 0) {
                            data.phone = '1' + data.phone;
                        }
                        if (data.phone.length !== 11 || data.phone.indexOf('1') !== 0) {
                            if (settings[pref + 'phone'].hasOwnProperty('error_text') && settings[pref + 'phone'].error_text) {
                                showError(pref, 'phone', settings[pref + 'phone'].error_text);
                            } else {
                                showError(pref, 'phone', settings[pref + 'phone'].label + ' must be 11 digits and start with 1.');
                            }
                            return false;
                        }
                    } else if (settings[pref + 'phone'].validation === 'phone_any' && data.phone.length !== 11) {
                        if (settings[pref + 'phone'].hasOwnProperty('error_text') && settings[pref + 'phone'].error_text) {
                            showError(pref, 'phone', settings[pref + 'phone'].error_text);
                        } else {
                            showError(pref, 'phone', settings[pref + 'phone'].label + ' must be 11 digits.');
                        }
                        return false;
                    }
                }
            }
        }


        for (var n = 1; n <= 50; n++) {
            pref_form_input_customN = form_input_obj['pref_form_input_custom' + n];

            if (settings.hasOwnProperty(pref + 'custom' + n) && settings[pref + 'custom' + n].display) {
                if ((!data.hasOwnProperty('custom_' + n) || override_data) && (settings[pref + 'custom' + n].hasOwnProperty('field_type') && settings[pref + 'custom' + n].field_type !== 'datedrop' && settings[pref + 'custom' + n].field_type !== 'radio') && pref_form_input_customN && pref_form_input_customN.length) {
                    if (pref_form_input_customN.val() && typeof pref_form_input_customN.val() === 'object') {
                        data['custom_' + n] = pref_form_input_customN.val().join(',');
                        if (data['custom_' + n].indexOf(',') === 0) data['custom_' + n] = data['custom_' + n].substr(1);
                    } else {
                        data['custom_' + n] = pref_form_input_customN.val();
                    }
                } else if ((!data.hasOwnProperty('custom_' + n) || override_data) && (settings[pref + 'custom' + n].hasOwnProperty('field_type') && settings[pref + 'custom' + n].field_type == 'radio')) {
                    if ($("input[name=" + pref + "form_input_custom" + n + "]:checked").length) {
                        data['custom_' + n] = $("input[name=" + pref + "form_input_custom" + n + "]:checked").val();
                    }

                    //logger('validateForm_RADIO: ' + data['custom_' + n]);

                    if (settings[pref + 'custom' + n].require && !data['custom_' + n]) {
                        if (settings[pref + 'custom' + n].hasOwnProperty('error_text') && settings[pref + 'custom' + n].error_text) {
                            showError(pref, 'custom' + n, settings[pref + 'custom' + n].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[pref + 'custom' + n].label + ' is required.');
                        }
                        return false;
                    }
                }

                var evalCustomNCheckboxResult = evaluateCustomNCheckbox(data, pref, '' + n, get_data_only, parent.DIGIOH_API.LIGHTBOX.INTEGRATION_MAP, LIGHTBOX_OR_VARIATION_GUID);
                if (!evalCustomNCheckboxResult) {
                    return false;
                }

                var evalCustomNDatedropResult = evalCustomNDatedrop(data, pref, '' + n, get_data_only);
                if (!evalCustomNDatedropResult) {
                    return false;
                }

                if (!get_data_only) {
                    if (settings[pref + 'custom' + n].hasOwnProperty('field_type') && settings[pref + 'custom' + n].field_type !== 'hidden' && settings[pref + 'custom' + n].field_type !== 'checkbox' && settings[pref + 'custom' + n].field_type !== 'radio' && settings[pref + 'custom' + n].field_type !== 'datedrop' && settings[pref + 'custom' + n].require && data['custom_' + n].length == 0) {
                        if (settings[pref + 'custom' + n].hasOwnProperty('error_text') && settings[pref + 'custom' + n].error_text) {
                            showError(pref, 'custom' + n, settings[pref + 'custom' + n].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[pref + 'custom' + n].label + ' is required.');
                        }
                        return false;
                    }
                    if (data['custom_' + n] && data['custom_' + n].length > 5000) {
                        if (settings[pref + 'custom' + n].hasOwnProperty('error_text') && settings[pref + 'custom' + n].error_text) {
                            showError(pref, 'custom' + n, settings[pref + 'custom' + n].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[pref + 'custom' + n].label + ' must be less than 500 characters.');
                        }
                        return false;
                    }



                    if (settings[pref + 'custom' + n].hasOwnProperty('validation') && settings[pref + 'custom' + n].validation && data['custom_' + n].length > 0 && (settings[pref + 'custom' + n].field_type === 'hidden' || settings[pref + 'custom' + n].field_type === 'textbox' || settings[pref + 'custom' + n].field_type === 'textarea')) {
                        if (settings[pref + 'custom' + n].validation === 'email_basic') {
                            data['custom_' + n] = data['custom_' + n].replace(/\s+/g, '');
                            if (!isValidEmail(data['custom_' + n])) {
                                if (settings[pref + 'custom' + n].hasOwnProperty('error_text') && settings[pref + 'custom' + n].error_text) {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].error_text);
                                } else {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].label + ' is not a valid Email.');
                                }
                                return false;
                            }
                        } else if (settings[pref + 'custom' + n].validation === 'phone_10') {
                            data['custom_' + n] = data['custom_' + n].replace(/\D/g, '');
                            if (data['custom_' + n].length !== 10) {
                                if (settings[pref + 'custom' + n].hasOwnProperty('error_text') && settings[pref + 'custom' + n].error_text) {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].error_text);
                                } else {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].label + ' must be 10 digits.');
                                }
                                return false;
                            }
                        } else if (settings[pref + 'custom' + n].validation === 'phone_usa') {
                            data['custom_' + n] = data['custom_' + n].replace(/\D/g, '');
                            if (data['custom_' + n].length === 10 && data['custom_' + n].indexOf('1') !== 0) {
                                data['custom_' + n] = '1' + data['custom_' + n];
                            }
                            if (data['custom_' + n].length !== 11 || data['custom_' + n].indexOf('1') !== 0) {
                                if (settings[pref + 'custom' + n].hasOwnProperty('error_text') && settings[pref + 'custom' + n].error_text) {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].error_text);
                                } else {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].label + ' must be 11 digits and start with 1.');
                                }
                                return false;
                            }
                        } else if (settings[pref + 'custom' + n].validation === 'phone_any') {
                            data['custom_' + n] = data['custom_' + n].replace(/\D/g, '');
                            if (data['custom_' + n].length !== 11) {
                                if (settings[pref + 'custom' + n].hasOwnProperty('error_text') && settings[pref + 'custom' + n].error_text) {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].error_text);
                                } else {
                                    showError(pref, 'custom' + n, settings[pref + 'custom' + n].label + ' must be 11 digits.');
                                }
                                return false;
                            }
                        }
                    }


                }
            } else if (settings.hasOwnProperty(pref + 'custom' + n) && !data.hasOwnProperty('custom_' + n) && pref_form_input_customN && pref_form_input_customN.length) {
                if (pref_form_input_customN.val() && typeof pref_form_input_customN.val() === 'object') {
                    data['custom_' + n] = pref_form_input_customN.val().join(',');
                    if (data['custom_' + n].indexOf(',') === 0) data['custom_' + n] = data['custom_' + n].substr(1);
                } else {
                    data['custom_' + n] = pref_form_input_customN.val();
                }
            } else if (settings.hasOwnProperty(pref + 'custom' + n) && !data.hasOwnProperty('custom_' + n) && settings[pref + 'custom' + n].hasOwnProperty('field_type') && settings[pref + 'custom' + n].field_type === 'datedrop' && $('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_yyyy').length) {
                evalCustomNDatedrop(data, pref, '' + n, true);
            }
        }



        if (settings.hasOwnProperty(pref + 'opt_in') && settings[pref + 'opt_in'].display) {
            if (!data.hasOwnProperty('opt_in') || override_data) data.opt_in = (pref_form_input_opt_in[0].checked ? 'true' : 'false');

            if (!get_data_only) {
                if (settings[pref + 'opt_in'].require && data.opt_in == 'false') {
                    if (settings[pref + 'opt_in'].hasOwnProperty('error_text') && settings[pref + 'opt_in'].error_text) {
                        showError(pref, 'opt_in', settings[pref + 'opt_in'].error_text);
                    } else {
                        showError(pref, 'opt_in', 'Checkbox is required.');
                    }
                    return false;
                }
            }
        }

        //fsdbx (dataLayer)
        data = setFormDataLayer(pref, data);

        return data;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'validateForm');
        return data;
    }
}



function setFormDataLayer(pref, data) {
    try {
        var pref_fsdbx = pref;
        if (pref === '' || !pref)
            pref_fsdbx = 'main_';


        //Whatever the current page is, grab the actual/live global form data and then also set it on the page level for the particular page we are currently on (custom_1 ==> main_custom_1).
        //This is a live data/form operation only, and does not involve the DataLayer at all.
        if (pref_fsdbx.indexOf('_') < 0)
            pref_fsdbx = pref_fsdbx + '_';

        if (data.hasOwnProperty('name'))
            data[pref_fsdbx + 'name'] = data['name'];

        if (data.hasOwnProperty('first_name'))
            data[pref_fsdbx + 'first_name'] = data['first_name'];

        if (data.hasOwnProperty('last_name'))
            data[pref_fsdbx + 'last_name'] = data['last_name'];

        if (data.hasOwnProperty('email'))
            data[pref_fsdbx + 'email'] = data['email'];

        if (data.hasOwnProperty('phone'))
            data[pref_fsdbx + 'phone'] = data['phone'];

        if (data.hasOwnProperty('opt_in'))
            data[pref_fsdbx + 'opt_in'] = data['opt_in'];

        for (var n = 1; n <= 50; n++) {
            if (data.hasOwnProperty('custom_' + n) && data['custom_' + n] !== '' && data['custom_' + n] !== null && data['custom_' + n] !== undefined)
                data[pref_fsdbx + 'custom_' + n] = data['custom_' + n];
        }


        var data_fsdbx = parent.DIGIOH_API.LIGHTBOX.DIGIOH_LOCAL_STORAGE.getManual('fsdbx');
        if (typeof data_fsdbx !== 'object' || !data_fsdbx)
            return data;

        var pr = '';
        for (var x = 1; x <= 102; x++) {
            if (x <= 100) pr = 'ep' + x + '_';
            else if (x === 101) pr = 'thx_';
            else if (x === 102) pr = 'main_';

            if (pr !== pref_fsdbx) {
                //For any other page (besides the current page) see if LocalStorage/DataLayer contains a value, and if so then set it on the form.
                //This currently won't populate the form with any regular fields (that don't contain a pr prefix).  So "custom_1" or "email" don't currently work here.
                if (data_fsdbx.hasOwnProperty(pr + 'name'))
                    data[pr + 'name'] = data_fsdbx[pr + 'name'];

                if (data_fsdbx.hasOwnProperty(pr + 'first_name'))
                    data[pr + 'first_name'] = data_fsdbx[pr + 'first_name'];

                if (data_fsdbx.hasOwnProperty(pr + 'last_name'))
                    data[pr + 'last_name'] = data_fsdbx[pr + 'last_name'];

                if (data_fsdbx.hasOwnProperty(pr + 'email'))
                    data[pr + 'email'] = data_fsdbx[pr + 'email'];

                if (data_fsdbx.hasOwnProperty(pr + 'phone'))
                    data[pr + 'phone'] = data_fsdbx[pr + 'phone'];

                if (data_fsdbx.hasOwnProperty(pr + 'opt_in'))
                    data[pr + 'opt_in'] = data_fsdbx[pr + 'opt_in'];

                for (var n = 1; n <= 50; n++) {
                    if (data_fsdbx.hasOwnProperty(pr + 'custom_' + n))
                        data[pr + 'custom_' + n] = data_fsdbx[pr + 'custom_' + n];
                }
            } else {
                //If the prefix matches the current page, then only overwrite the live form data with LocalStorage/DataLayer data if the live form data does not exist for that field, or if it is empty.
                if (data_fsdbx.hasOwnProperty(pr + 'name') && data_fsdbx[pr + 'name'] && (!data.hasOwnProperty(pr + 'name') || !data[pr + 'name']))
                    data[pr + 'name'] = data_fsdbx[pr + 'name'];

                if (data_fsdbx.hasOwnProperty(pr + 'first_name') && data_fsdbx[pr + 'first_name'] && (!data.hasOwnProperty(pr + 'first_name') || !data[pr + 'first_name']))
                    data[pr + 'first_name'] = data_fsdbx[pr + 'first_name'];

                if (data_fsdbx.hasOwnProperty(pr + 'last_name') && data_fsdbx[pr + 'last_name'] && (!data.hasOwnProperty(pr + 'last_name') || !data[pr + 'last_name']))
                    data[pr + 'last_name'] = data_fsdbx[pr + 'last_name'];

                if (data_fsdbx.hasOwnProperty(pr + 'email') && data_fsdbx[pr + 'email'] && (!data.hasOwnProperty(pr + 'email') || !data[pr + 'email']))
                    data[pr + 'email'] = data_fsdbx[pr + 'email'];

                if (data_fsdbx.hasOwnProperty(pr + 'phone') && data_fsdbx[pr + 'phone'] && (!data.hasOwnProperty(pr + 'phone') || !data[pr + 'phone']))
                    data[pr + 'phone'] = data_fsdbx[pr + 'phone'];

                if (data_fsdbx.hasOwnProperty(pr + 'opt_in') && data_fsdbx[pr + 'opt_in'] !== '' && (!data.hasOwnProperty(pr + 'opt_in') || data[pr + 'opt_in'] == ''))
                    data[pr + 'opt_in'] = data_fsdbx[pr + 'opt_in'];

                for (var n = 1; n <= 50; n++) {
                    if (data_fsdbx.hasOwnProperty(pr + 'custom_' + n) && data_fsdbx[pr + 'custom_' + n] !== '' && (!data.hasOwnProperty(pr + 'custom_' + n) || data[pr + 'custom_' + n] == ''))
                        data[pr + 'custom_' + n] = data_fsdbx[pr + 'custom_' + n];
                }
            }
        }


        //Finally, see if there is any non-page-prefixed (ie. global) data from LocalStorage/DataLayer that can be stuffed into the global live submission data.
        //Again, we only attempt this if the live form data does not exist for that field, of if it is empty.
        if (data_fsdbx.hasOwnProperty('name') && data_fsdbx['name'] && (!data.hasOwnProperty('name') || !data['name']))
            data['name'] = data_fsdbx['name'];

        if (data_fsdbx.hasOwnProperty('first_name') && data_fsdbx['first_name'] && (!data.hasOwnProperty('first_name') || !data['first_name']))
            data['first_name'] = data_fsdbx['first_name'];

        if (data_fsdbx.hasOwnProperty('last_name') && data_fsdbx['last_name'] && (!data.hasOwnProperty('last_name') || !data['last_name']))
            data['last_name'] = data_fsdbx['last_name'];

        if (data_fsdbx.hasOwnProperty('email') && data_fsdbx['email'] && (!data.hasOwnProperty('email') || !data['email']))
            data['email'] = data_fsdbx['email'];

        if (data_fsdbx.hasOwnProperty('phone') && data_fsdbx['phone'] && (!data.hasOwnProperty('phone') || !data['phone']))
            data['phone'] = data_fsdbx['phone'];

        if (data_fsdbx.hasOwnProperty('opt_in') && data_fsdbx['opt_in'] !== '' && (!data.hasOwnProperty('opt_in') || data['opt_in'] == ''))
            data['opt_in'] = data_fsdbx['opt_in'];

        for (var n = 1; n <= 50; n++) {
            if (data_fsdbx.hasOwnProperty('custom_' + n) && data_fsdbx['custom_' + n] !== '' && (!data.hasOwnProperty('custom_' + n) || data['custom_' + n] == ''))
                data['custom_' + n] = data_fsdbx['custom_' + n];
        }

        return data;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'setFormDataLayer');
        return data;
    }
}



function evalCustomNDatedrop(data, pref, n, get_data_only) {
    try {
        var propName = pref + 'custom' + n;
        if (settings[propName].hasOwnProperty('field_type') && settings[propName].field_type === 'datedrop') {
            var dropdown_yyyy = $('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_yyyy').val();
            var dropdown_mm = $('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_mm').val();
            var dropdown_dd = $('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_dd').val();

            var output_format = "";
            if (settings[propName].datedrop.custom_format && !isNullOrWhitespace(settings[propName].datedrop.custom_format)) {
                output_format = settings[propName].datedrop.custom_format;
            } else if (settings[propName].datedrop.output_format) {
                output_format = settings[propName].datedrop.output_format;
            } else {
                output_format = "MM-dd-yyyy";
            }

            var sep = '';
            if (output_format.indexOf("-") > 0 && output_format.indexOf("-") <= 7) {
                sep = '-';
            } else if (output_format.indexOf("/") > 0 && output_format.indexOf("/") <= 7) {
                sep = '/';
            } else if (output_format.indexOf(".") > 0 && output_format.indexOf(".") <= 7) {
                sep = '.';
            }

            var mm_format = "MM";
            var dd_format = "dd";
            var yyyy_format = "yyyy";
            var output_parts = output_format.split(sep);
            for (var i = 0; i < output_parts.length; i++) {
                if (boxapi.contains(output_parts[i], "M")) mm_format = output_parts[i];
                else if (boxapi.contains(output_parts[i], "d")) dd_format = output_parts[i];
                else if (boxapi.contains(output_parts[i], "y")) yyyy_format = output_parts[i];
            }

            if (boxapi.contains(output_format, "MM") && dropdown_mm.length == 1) {
                dropdown_mm = "0" + dropdown_mm;
            } else if (!boxapi.contains(output_format, "MM") && boxapi.contains(output_format, "M") && dropdown_mm.length == 2 && dropdown_mm.indexOf("0") === 0) {
                dropdown_mm = dropdown_mm.substring(1);
            } else if (dropdown_mm.length == 0) {
                dropdown_mm = "MM";
            }

            if (boxapi.contains(output_format, "dd") && dropdown_dd.length == 1) {
                dropdown_dd = "0" + dropdown_dd;
            } else if (!boxapi.contains(output_format, "dd") && boxapi.contains(output_format, "d") && dropdown_dd.length == 2 && dropdown_dd.indexOf("0") === 0) {
                dropdown_dd = dropdown_dd.substring(1);
            } else if (dropdown_dd.length == 0) {
                dropdown_dd = "dd";
            }

            if (!boxapi.contains(output_format, "yyyy") && boxapi.contains(output_format, "yy")) {
                if (dropdown_yyyy.length == 4) dropdown_yyyy = dropdown_yyyy.substring(2);
                if (dropdown_yyyy.length == 0) dropdown_yyyy = "yy";
            }

            var isValidDateSelected = false;
            if (dropdown_mm !== '' && dropdown_mm.toLowerCase() !== "mm" && !dropdown_mm.toLowerCase() !== "m" &&
                dropdown_dd !== '' && dropdown_dd.toLowerCase() !== "dd" && !dropdown_dd.toLowerCase() !== "d" &&
                dropdown_yyyy !== '' && dropdown_yyyy.toLowerCase() !== "yyyy" && dropdown_yyyy.toLowerCase() !== "yy" && dropdown_yyyy.toLowerCase() !== "y") {
                isValidDateSelected = true;
            }

            var caseN = '';
            if (!isValidDateSelected && !settings[propName].require) {
                data['custom_' + n] = '';
                caseN = '0';
            } else if (output_format == (mm_format + sep + dd_format + sep + yyyy_format)) {
                data['custom_' + n] = dropdown_mm + sep + dropdown_dd + sep + dropdown_yyyy;
                caseN = '1';
            } else if (output_format == (dd_format + sep + mm_format + sep + yyyy_format)) {
                data['custom_' + n] = dropdown_dd + sep + dropdown_mm + sep + dropdown_yyyy;
                caseN = '2';
            } else if (output_format == (yyyy_format + sep + mm_format + sep + dd_format)) {
                data['custom_' + n] = dropdown_yyyy + sep + dropdown_mm + sep + dropdown_dd;
                caseN = '3';
            } else {
                data['custom_' + n] = $('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_mm').val() + '-' + $('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_dd').val() + '-' + $('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_yyyy').val();
                caseN = '4';
            }

            logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - evalCustomNDatedrop: ' + data['custom_' + n] + ' (case ' + caseN + ')');
            logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - output_format=' + output_format + ', mm_format=' + mm_format + ', dd_format=' + dd_format + ', yyyy_format=' + yyyy_format + ', sep=' + sep);

            if (!get_data_only) {
                if (settings[propName].require && (!dropdown_mm || dropdown_mm.toLowerCase() == "mm" || dropdown_mm.toLowerCase() == "m")) {
                    if (settings[propName].require) {
                        if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                            showError(pref, 'custom' + n, settings[propName].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[propName].label + ' is required.');
                        }
                    } else {
                        if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                            showError(pref, 'custom' + n, settings[propName].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[propName].label + ' invalid date.');
                        }
                    }
                    return false;
                }

                if (settings[propName].require && (!dropdown_dd || dropdown_dd.toLowerCase() == "dd" || dropdown_dd.toLowerCase() == "d")) {
                    if (settings[propName].require) {
                        if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                            showError(pref, 'custom' + n, settings[propName].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[propName].label + ' is required.');
                        }
                    } else {
                        if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                            showError(pref, 'custom' + n, settings[propName].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[propName].label + ' invalid date.');
                        }
                    }
                    return false;
                }

                if (settings[propName].require && (!dropdown_yyyy || dropdown_yyyy.toLowerCase() == "yyyy" || dropdown_yyyy.toLowerCase() == "yy" || dropdown_yyyy.toLowerCase() == "y")) {
                    if (settings[propName].require) {
                        if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                            showError(pref, 'custom' + n, settings[propName].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[propName].label + ' is required.');
                        }
                    } else {
                        if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                            showError(pref, 'custom' + n, settings[propName].error_text);
                        } else {
                            showError(pref, 'custom' + n, settings[propName].label + ' invalid date.');
                        }
                    }
                    return false;
                }

                if (isValidDateSelected) {
                    if (settings[propName].datedrop.min_age) {
                        var curr_date = new Date();
                        var curr_yyyy = curr_date.getFullYear();
                        var sel_yyyy = parseInt($('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_yyyy').val());
                        var min_age = parseInt(settings[propName].datedrop.min_age);
                        if (curr_yyyy - sel_yyyy < min_age) {
                            if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                                showError(pref, 'custom' + n, settings[propName].error_text);
                            } else {
                                showError(pref, 'custom' + n, 'You must be ' + min_age + ' years old.');
                            }
                            return false;
                        }
                    }

                    if (settings[propName].datedrop.max_age) {
                        var curr_date = new Date();
                        var curr_yyyy = curr_date.getFullYear();
                        var sel_yyyy = parseInt($('#' + pref + 'form_input_' + 'custom' + n + '_datedrop_yyyy').val());
                        var max_age = parseInt(settings[propName].datedrop.max_age);
                        if (curr_yyyy - sel_yyyy > max_age) {
                            if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                                showError(pref, 'custom' + n, settings[propName].error_text);
                            } else {
                                showError(pref, 'custom' + n, 'You are over ' + max_age + ' years old.');
                            }
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'evalCustomNDatedrop');
        return false;
    }
}



function evaluateCustomNCheckbox(data, pref, n, get_data_only, integration_map, lbguid) {
    try {
        var propName = pref + 'custom' + n;
        if (settings[propName].hasOwnProperty('field_type') && settings[propName].field_type === 'checkbox') {
            var cb = document.getElementById(pref + 'form_input_custom' + n);
            if (cb && cb.checked) {
                if (typeof settings[propName].checkbox.checkedval === 'string') {
                    if (settings[propName].checkbox.checkedval === '[BLANK]') {
                        data['custom_' + n] = '';
                    } else if (settings[propName].checkbox.checkedval === '') {
                        data['custom_' + n] = 'true';
                    } else {
                        data['custom_' + n] = settings[propName].checkbox.checkedval;
                    }
                } else {
                    data['custom_' + n] = 'true';
                }

                if (settings[propName].checkbox.integration_id) {
                    var integration_id = settings[propName].checkbox.integration_id;
                    if (typeof integration_id !== 'string') integration_id = integration_id.toString();
                    if (integration_id.indexOf(' ') !== -1) integration_id = integration_id.split(' ').join('');

                    if (!integration_map.hasOwnProperty(lbguid)) {
                        integration_map[lbguid] = integration_id;
                        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - Added integration_id ' + integration_id + ' to INTEGRATION_MAP for box ' + lbguid);
                        logger(integration_map);
                    } else if (integration_map[lbguid].indexOf(integration_id) === -1) {
                        if (integration_map[lbguid].length > 1) {
                            integration_map[lbguid] += ',';
                        }
                        integration_map[lbguid] += integration_id;
                        logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - Added integration_id ' + integration_id + ' to INTEGRATION_MAP for box ' + lbguid);
                        logger(integration_map);
                    }
                }
            } else {
                if (typeof settings[propName].checkbox.uncheckedval === 'string') {
                    if (settings[propName].checkbox.uncheckedval === '[BLANK]') {
                        data['custom_' + n] = '';
                    } else if (settings[propName].checkbox.uncheckedval === '') {
                        data['custom_' + n] = 'false';
                    } else {
                        data['custom_' + n] = settings[propName].checkbox.uncheckedval;
                    }
                } else {
                    data['custom_' + n] = 'false';
                }

                var integration_id = settings[propName].checkbox.integration_id;
                if (typeof integration_id !== 'string') integration_id = integration_id.toString();
                if (integration_id.indexOf(' ') !== -1) integration_id = integration_id.split(' ').join('');

                if (integration_id && integration_map.hasOwnProperty(lbguid) && integration_map[lbguid].indexOf(integration_id) >= 0) {
                    integration_map[lbguid] = integration_map[lbguid].replace(',' + integration_id, '').replace(integration_id + ',', '').replace(integration_id, '');
                    logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - Removed integration_id ' + integration_id + ' from INTEGRATION_MAP for box ' + lbguid);
                    logger(integration_map);
                }
            }

            logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - evaluateCustomNCheckbox(custom_' + n + ') ==> ' + data['custom_' + n]);

            if (!get_data_only) {
                if (settings[propName].require && !cb.checked) {
                    if (settings[propName].hasOwnProperty('error_text') && settings[propName].error_text) {
                        showError(pref, 'custom' + n, settings[propName].error_text);
                    } else {
                        showError(pref, 'custom' + n, settings[propName].label + ' is required.');
                    }
                    return false;
                }
            }
        }

        return true;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'evaluateCustomNCheckbox');
        return false;
    }
}




function showError(pref, propName, msg) {
    //In this case, pref is the only param, which means that we should treat that as the "error message".
    if (typeof pref === 'string' && typeof propName === 'undefined' && typeof msg === 'undefined') {
        var error_width = settings.layout.width;
        if (CURRENT_WIDTH) {
            error_width = CURRENT_WIDTH;
        }

        error_bubble.width(CURRENT_WIDTH - 90);
        error_message.html(pref);
        error_bubble.show();

        $(document).trigger('BOX_SHOW_ERROR', [pref, propName, msg]);
        $('#error_message').attr('role', 'status');
        wasErrorBubbleAlreadyClosed = false;

        window.setTimeout(function() {
            error_bubble.hide();
            if (!wasErrorBubbleAlreadyClosed) {
                wasErrorBubbleAlreadyClosed = true;
                $(document).trigger('BOX_CLOSE_ERROR', [pref, propName, msg]);
                $('#error_message').removeAttr('role');
            }
        }, 4000);

        return;
    }


    pref = getUnfriendlyPagePrefix(pref);


    //We look at the "settings > inputs > error_position" property that is set in the Editor, to determine if it should be an "inline" or "top bubble" error display.
    if (!propName || propName === '' || !settings.hasOwnProperty(pref + propName) || !settings[pref + 'inputs'].hasOwnProperty('error_position') || settings[pref + 'inputs']['error_position'].indexOf('top') >= 0) {
        var error_width = settings.layout.width;
        if (CURRENT_WIDTH) {
            error_width = CURRENT_WIDTH;
        }

        error_bubble.width(CURRENT_WIDTH - 90);
        error_message.html(msg);
        error_bubble.show();

        $(document).trigger('BOX_SHOW_ERROR', [pref, propName, msg]);
        $('#error_message').attr('role', 'status');
        wasErrorBubbleAlreadyClosed = false;

        //var offset = $('#email').offset();
        //var borderColor = $('#email').css('borderColor');
        //error_bubble.css('top', offset.top - 41 + 'px');
        //error_bubble.css('left', offset.left + 'px');
        //$('#email').css('borderColor', '#d58a8a');
        window.setTimeout(function() {
            error_bubble.hide();
            //$('#email').css('borderColor', borderColor);
            if (!wasErrorBubbleAlreadyClosed) {
                wasErrorBubbleAlreadyClosed = true;
                $(document).trigger('BOX_CLOSE_ERROR', [pref, propName, msg]);
                $('#error_message').removeAttr('role');
            }
        }, 4000);

        return;
    }


    //We look at the "settings > inputs > error_position" property that is set in the Editor, to determine if it should be an "inline" or "top bubble" error display.
    if (propName !== '' && settings[pref + 'inputs'].hasOwnProperty('error_position') && settings[pref + 'inputs']['error_position'].indexOf('inline') >= 0) {
        showInlineError(pref, propName, msg);
        $(document).trigger('BOX_SHOW_ERROR', [pref, propName, msg]);
        $('#error_message').attr('role', 'status');
        wasErrorBubbleAlreadyClosed = false;
    }
}


function showInlineError(pref, propName, msg) {
    pref = getUnfriendlyPagePrefix(pref);

    if (propName === 'name' || propName.indexOf('_name') > 0) {
        if ($('#' + pref + 'form_input_full_name_help').length) $('#' + pref + 'form_input_full_name_help').hide();
        if ($('#' + pref + 'form_input_first_name_help').length) $('#' + pref + 'form_input_first_name_help').hide();
        if ($('#' + pref + 'form_input_last_name_help').length) $('#' + pref + 'form_input_last_name_help').hide();
        $('#' + pref + 'form_input_name_error_text').html(msg).show();
        $('#' + pref + 'form_input_full_name,' + '#' + pref + 'form_input_first_name,' + '#' + pref + 'form_input_last_name').addClass(pref + 'form_inputs_error');
        $('#' + pref + 'form_input_full_name,' + '#' + pref + 'form_input_first_name,' + '#' + pref + 'form_input_last_name').focus(function() {
            $('#' + pref + 'form_input_name_error_text').hide();
            $('#' + pref + 'form_input_full_name,' + '#' + pref + 'form_input_first_name,' + '#' + pref + 'form_input_last_name').removeClass(pref + 'form_inputs_error');
            if (settings[pref + 'name'].display_help) {
                if ($('#' + pref + 'form_input_full_name_help').length) $('#' + pref + 'form_input_full_name_help').show();
                if ($('#' + pref + 'form_input_first_name_help').length) $('#' + pref + 'form_input_first_name_help').show();
                if ($('#' + pref + 'form_input_last_name_help').length) $('#' + pref + 'form_input_last_name_help').show();
            }
        });
    } else if (propName === 'email') {
        if ($('#' + pref + 'form_input_email_help').length) $('#' + pref + 'form_input_email_help').hide();
        $('#' + pref + 'form_input_email_error_text').html(msg).show();
        $('#' + pref + 'form_input_email').addClass(pref + 'form_inputs_error');
        $('#' + pref + 'form_input_email').focus(function() {
            $('#' + pref + 'form_input_email_error_text').hide();
            $('#' + pref + 'form_input_email').removeClass(pref + 'form_inputs_error');
            if (settings[pref + 'email'].display_help && $('#' + pref + 'form_input_email_help').length) {
                $('#' + pref + 'form_input_email_help').show();
            }
        });
    } else if (propName === 'phone') {
        if ($('#' + pref + 'form_input_phone_help').length) $('#' + pref + 'form_input_phone_help').hide();
        $('#' + pref + 'form_input_phone_error_text').html(msg).show();
        $('#' + pref + 'form_input_phone').addClass(pref + 'form_inputs_error');
        $('#' + pref + 'form_input_phone').focus(function() {
            $('#' + pref + 'form_input_phone_error_text').hide();
            $('#' + pref + 'form_input_phone').removeClass(pref + 'form_inputs_error');
            if (settings[pref + 'phone'].display_help && $('#' + pref + 'form_input_phone_help').length) {
                $('#' + pref + 'form_input_phone_help').show();
            }
        });
    } else if (propName === 'opt_in') {
        $('#' + pref + 'form_input_opt_in_error_text').html(msg).show();
        $('#' + pref + 'form_input_opt_in').change(function() {
            $('#' + pref + 'form_input_opt_in_error_text').hide();
        });
        //setTimeout(function () {
        //    $('#' + pref + 'form_input_opt_in_error_text').hide();
        //}, 5000);
    } else if (propName.indexOf('custom') === 0) {
        if ($('#' + pref + 'form_input_' + propName + '_help').length) $('#' + pref + 'form_input_' + propName + '_help').hide();
        $('#' + pref + 'form_input_' + propName + '_error_text').html(msg).show();

        if (settings[pref + propName]['field_type'] === 'checkbox') {
            $('#' + pref + 'form_input_' + propName).change(function() {
                $('#' + pref + 'form_input_' + propName + '_error_text').hide();
            });
            //setTimeout(function () {
            //    $('#' + pref + 'form_input_' + propName + '_error_text').hide();
            //}, 5000);
        } else if (settings[pref + propName]['field_type'] === 'datedrop') {
            $('#' + pref + 'form_input_' + propName + '_wrapper .' + pref + 'form_inputs').addClass(pref + 'form_inputs_error');
            $('#' + pref + 'form_input_' + propName + '_wrapper .' + pref + 'form_inputs').focus(function() {
                $('#' + pref + 'form_input_' + propName + '_error_text').hide();
                $('#' + pref + 'form_input_' + propName + '_wrapper .' + pref + 'form_inputs').removeClass(pref + 'form_inputs_error');
                if (settings[pref + propName].display_help) {
                    $('#' + pref + 'form_input_' + propName + '_wrapper .' + pref + 'form_inputs_help').show();
                }
            });
        } else {
            $('#' + pref + 'form_input_' + propName).addClass(pref + 'form_inputs_error');
            $('#' + pref + 'form_input_' + propName).focus(function() {
                $('#' + pref + 'form_input_' + propName + '_error_text').hide();
                $('#' + pref + 'form_input_' + propName).removeClass(pref + 'form_inputs_error');
                if (settings[pref + propName].display_help && $('#' + pref + 'form_input_' + propName + '_help').length) {
                    $('#' + pref + 'form_input_' + propName + '_help').show();
                }
            });
        }
    }
}


function getFriendlyPagePrefix(pref) {
    var pp = 'main';
    if (typeof pref !== 'string' || pref.length < 3 || pref.length > 7) pp = 'main';
    else if (pref === 'thx_' || pref === 'thx') pp = 'thx';
    else if (pref === 'ep1_' || pref === 'ep1') pp = 'ep1';
    else if (pref === 'ep2_' || pref === 'ep2') pp = 'ep2';
    else if (pref === 'ep3_' || pref === 'ep3') pp = 'ep3';
    else if (pref === 'ep4_' || pref === 'ep4') pp = 'ep4';
    else if (pref.indexOf('ep') === 0) {
        var pNum = getExtraPageNumberFromEPString(pref);
        pp = 'ep' + pNum;
    }

    return pp;
}

function getUnfriendlyPagePrefix(pref) {
    var pp = '';
    if (typeof pref !== 'string' || pref.length < 3 || pref.length > 7) pp = '';
    else if (pref === 'thx_' || pref === 'thx') pp = 'thx_';
    else if (pref === 'ep1_' || pref === 'ep1') pp = 'ep1_';
    else if (pref === 'ep2_' || pref === 'ep2') pp = 'ep2_';
    else if (pref === 'ep3_' || pref === 'ep3') pp = 'ep3_';
    else if (pref === 'ep4_' || pref === 'ep4') pp = 'ep4_';
    else if (pref.indexOf('ep') === 0) {
        var pNum = getExtraPageNumberFromEPString(pref);
        pp = 'ep' + pNum + '_';
    }

    return pp;
}

function checkPendingCouponsOnSubmit(pref, hideLoadingSpinner, useSubmitLock) {
    try {
        var foundCouponPending = false;
        for (var prop in COUPONS_FOR_SUBMIT) {
            if (COUPONS_FOR_SUBMIT.hasOwnProperty(prop) && COUPONS_FOR_SUBMIT[prop] === false) {
                foundCouponPending = true;
                break;
            }
        }

        //logger('checkPendingCouponsOnSubmit');

        if (foundCouponPending) {
            setTimeout(function() {
                checkPendingCouponsOnSubmit(pref, hideLoadingSpinner, useSubmitLock);
            }, 100);
        } else {
            processSubmitLock = false;
            processSubmit(pref, hideLoadingSpinner, true, useSubmitLock);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'checkPendingCouponsOnSubmit');
    }
}


function checkPendingCouponsOnSubmitObj(sobj) {
    try {
        var foundCouponPending = false;
        for (var prop in COUPONS_FOR_SUBMIT) {
            if (COUPONS_FOR_SUBMIT.hasOwnProperty(prop) && COUPONS_FOR_SUBMIT[prop] === false) {
                foundCouponPending = true;
                break;
            }
        }

        if (foundCouponPending) {
            setTimeout(function() {
                checkPendingCouponsOnSubmitObj(sobj);
            }, 100);
        } else {
            processSubmitLock = false;

            if (typeof sobj !== 'object' || sobj === null)
                sobj = {};

            sobj.bypassCoupons = true;

            processSubmitObj(sobj);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'checkPendingCouponsOnSubmitObj');
    }
}


function processSubmit(pref, hideLoadingSpinner, bypassCoupons, useSubmitLock) {
    try {
        if (typeof pref !== 'string')
            pref = CURRENT_PAGE;

        if (typeof hideLoadingSpinner !== 'boolean')
            hideLoadingSpinner = false;

        if (typeof bypassCoupons !== 'boolean')
            bypassCoupons = false;

        if (typeof useSubmitLock !== 'boolean')
            useSubmitLock = true;
    } catch (e) {
        pref = CURRENT_PAGE;
        hideLoadingSpinner = false;
        bypassCoupons = false;
        useSubmitLock = true;
    }

    processSubmitObj({
        'pageName': pref,
        'hideLoadingSpinner': hideLoadingSpinner,
        'bypassCoupons': bypassCoupons,
        'useSubmitLock': useSubmitLock
    });
}


function processSubmitObj(sobj) {
    if (typeof sobj !== 'object' || sobj === null)
        sobj = {};

    var pref = CURRENT_PAGE;
    if (sobj && sobj.hasOwnProperty('pageName') && typeof sobj.pageName === 'string')
        pref = sobj.pageName;

    var hideLoadingSpinner = false;
    if (sobj && sobj.hasOwnProperty('hideLoadingSpinner') && typeof sobj.hideLoadingSpinner === 'boolean')
        hideLoadingSpinner = sobj.hideLoadingSpinner;

    var bypassCoupons = false;
    if (sobj && sobj.hasOwnProperty('bypassCoupons') && typeof sobj.bypassCoupons === 'boolean')
        bypassCoupons = sobj.bypassCoupons;

    var useSubmitLock = true;
    if (sobj && sobj.hasOwnProperty('useSubmitLock') && typeof sobj.useSubmitLock === 'boolean')
        useSubmitLock = sobj.useSubmitLock;

    var overrideFormSubmitAction = '';
    if (sobj && sobj.hasOwnProperty('overrideFormSubmitAction') && typeof sobj.overrideFormSubmitAction === 'string')
        overrideFormSubmitAction = sobj.overrideFormSubmitAction;


    if (typeof useSubmitLock !== 'undefined' && useSubmitLock) {
        if (processSubmitLock) {
            logger('processSubmitLock');
            return false;
        }

        processSubmitLock = true;

        setTimeout(function() {
            processSubmitLock = false;
        }, 1000);
    } else {
        useSubmitLock = false;
    }


    try {
        pref = getUnfriendlyPagePrefix(pref);

        if (typeof COUPONS_FOR_SUBMIT === 'object' && Object.keys(COUPONS_FOR_SUBMIT).length > 0) {
            if (typeof bypassCoupons !== 'boolean' || !bypassCoupons) {
                buildCouponsSubmit();
                checkPendingCouponsOnSubmitObj(sobj);
                return;
            }
        }
    } catch (e) {
        pref = '';
        BOX_CUSTOM_JS.logError(e, 'processSubmitObj');
    }


    if ((using_form && pref === '') || (using_form_thx && pref === 'thx_') || (using_form_ep1 && pref === 'ep1_') || (using_form_ep2 && pref === 'ep2_') || (using_form_ep3 && pref === 'ep3_') || (using_form_ep4 && pref === 'ep4_') || pref.indexOf('ep') === 0) {

        if (pref.indexOf('ep') === 0) {
            var pNum = getExtraPageNumberFromEPString(pref);
            if (!settings.hasOwnProperty('ep' + pNum + 'layout') || !settings.hasOwnProperty('ep' + pNum + '_form') || !settings['ep' + pNum + '_form'].display) {
                return;
            }
        }



        //Override Integration at the Page/Form Level
        if (settings.hasOwnProperty(pref + 'form') && settings[pref + 'form'].hasOwnProperty('override_integration') && settings[pref + 'form']['override_integration'] === 'other' && settings[pref + 'form'].hasOwnProperty('override_integration_choices') && settings[pref + 'form']['override_integration_choices']) {
            parent.DIGIOH_API.LIGHTBOX.INTEGRATION_MAP[LIGHTBOX_OR_VARIATION_GUID] = settings[pref + 'form']['override_integration_choices'] + ',override';
            logger('processSubmitObj: pref=' + pref + ', override_integration=' + settings[pref + 'form']['override_integration']);
        } else if (settings.hasOwnProperty(pref + 'form') && settings[pref + 'form'].hasOwnProperty('override_integration') && settings[pref + 'form']['override_integration'] === 'skip') {
            parent.DIGIOH_API.LIGHTBOX.INTEGRATION_MAP[LIGHTBOX_OR_VARIATION_GUID] = '0';
            logger('processSubmitObj: pref=' + pref + ', override_integration=' + settings[pref + 'form']['override_integration']);
        } else if (parent.DIGIOH_API.LIGHTBOX.INTEGRATION_MAP.hasOwnProperty(LIGHTBOX_OR_VARIATION_GUID)) {
            if (parent.DIGIOH_API.LIGHTBOX.INTEGRATION_MAP[LIGHTBOX_OR_VARIATION_GUID].toString().indexOf('override') >= 0 || parent.DIGIOH_API.LIGHTBOX.INTEGRATION_MAP[LIGHTBOX_OR_VARIATION_GUID] === '0') {
                delete parent.DIGIOH_API.LIGHTBOX.INTEGRATION_MAP[LIGHTBOX_OR_VARIATION_GUID];
            }
            logger('processSubmitObj: pref=' + pref + ', override_integration=run_all');
        }



        var data_with_validation = '';

        //validateForm(data, page_pref, get_data_only, override_data)
        var data_only = validateForm({}, pref, true, true);

        //BOX_CUSTOM_JS ==> BeforeFormValidation
        //var customJsResBeforeFormValidation = BOX_CUSTOM_JS.runCustomJsBeforeFormValidation(getFriendlyPagePrefix(pref), data_only);
        var customJsResBeforeFormValidation = BOX_CUSTOM_JS.runCustomJsBeforeFormValidation(data_only);
        if (typeof customJsResBeforeFormValidation === 'boolean' && customJsResBeforeFormValidation === false) {
            return false;
        } else if (typeof customJsResBeforeFormValidation === 'string' && customJsResBeforeFormValidation.trim().length > 0) {
            showError('', '', customJsResBeforeFormValidation);
            return false;
        } else if (typeof customJsResBeforeFormValidation === 'object' && customJsResBeforeFormValidation !== null) {
            //skip validation, and populate data from form
            data_with_validation = customJsResBeforeFormValidation;
        } else {
            data_with_validation = validateForm({}, pref, false, true);
        }


        logger('data_with_validation ==>');
        logger(data_with_validation);

        if (typeof data_with_validation === 'object' && data_with_validation !== null) {

            //BOX_CUSTOM_JS ==> AfterFormValidation
            //var customJsResAfterFormValidation = BOX_CUSTOM_JS.runCustomJsAfterFormValidation(getFriendlyPagePrefix(pref), data_with_validation);
            var customJsResAfterFormValidation = BOX_CUSTOM_JS.runCustomJsAfterFormValidation(data_with_validation);


            logger('customJsResAfterFormValidation ==>');
            logger(customJsResAfterFormValidation);

            if (typeof customJsResAfterFormValidation === 'boolean' && customJsResAfterFormValidation === false) {
                return false;
            } else if (typeof customJsResAfterFormValidation === 'string' && customJsResAfterFormValidation.trim().length > 0) {
                showError('', '', customJsResAfterFormValidation);
                return false;
            } else if (typeof customJsResAfterFormValidation === 'object' && customJsResAfterFormValidation !== null) {
                data_with_validation = customJsResAfterFormValidation;
            }

            var data = data_with_validation;

            if (typeof hideLoadingSpinner !== 'boolean' || hideLoadingSpinner === false) {
                showLoading(pref);
            }

            var query = '';
            try {
                for (var key in data) {
                    if (data.hasOwnProperty(key)) {
                        if (key.indexOf('custom_') === 0) {
                            if (data[key]) {
                                var propName = pref + 'custom' + key.split('_')[1];
                                var keyName = '_c' + key.split('_')[1];
                                if (settings.hasOwnProperty(propName) && settings[propName].hasOwnProperty('label') && settings[propName].label !== '') {
                                    query += keyName.split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '=';
                                    query += settings[propName].label.split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '|';
                                    if (typeof data[key] === 'string') {
                                        query += data[key].split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '&';
                                    } else if (typeof data[key] === 'object' && typeof data[key].join === 'function') {
                                        query += data[key].join(',').split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '&';
                                    } else {
                                        query += '&';
                                    }
                                } else {
                                    query += keyName.split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '=';
                                    query += 'Custom Field ' + key.split('_')[1] + '|';
                                    if (data[key]) {
                                        query += data[key].split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '&';
                                    } else {
                                        query += '&';
                                    }
                                }
                            }
                        } else if (key.indexOf('_custom_') > 0 && (key.indexOf('main_') === 0 || key.indexOf('thx_') === 0 || key.indexOf('ep') === 0)) {
                            if (data[key]) {
                                var pr = '';
                                var fr = '';
                                if (key.indexOf('main_') === 0) {
                                    pr = '';
                                    fr = 'Main Page';
                                } else if (key.indexOf('thx_') === 0) {
                                    pr = 'thx_';
                                    fr = 'Thank You Page';
                                } else if (key.indexOf('ep') === 0) {
                                    pr = 'ep' + getExtraPageNumberFromEPString(key) + '_';
                                    fr = 'Extra Page ' + getExtraPageNumberFromEPString(key);
                                }

                                var propName = pr + 'custom' + key.split('_')[2];
                                var keyName = '_' + key.split('_')[0] + '_' + key.split('_')[2];
                                if (settings.hasOwnProperty(propName) && settings[propName].hasOwnProperty('label') && settings[propName].label !== '') {
                                    query += keyName.split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '=';
                                    query += settings[propName].label.split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '|';
                                    if (typeof data[key] === 'string') {
                                        query += data[key].split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '&';
                                    } else if (typeof data[key] === 'object' && typeof data[key].join === 'function') {
                                        query += data[key].join(',').split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '&';
                                    } else {
                                        query += '&';
                                    }
                                } else {
                                    query += keyName.split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '=';
                                    query += fr + ' ' + 'Custom Field ' + key.split('_')[2] + '|';
                                    if (data[key]) {
                                        query += data[key].split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '&';
                                    } else {
                                        query += '&';
                                    }
                                }
                            }
                        } else {
                            var keyName = key;
                            if (key == 'email') keyName = '_e';
                            else if (key == 'name') keyName = '_n';
                            else if (key == 'first_name') keyName = '_fn';
                            else if (key == 'last_name') keyName = '_ln';
                            else if (key == 'phone') keyName = '_p';
                            else if (key == 'opt_in') keyName = '_oi';
                            else if (key.indexOf('main_') === 0) keyName = '_' + key;
                            else if (key.indexOf('thx_') === 0) keyName = '_' + key;
                            else if (key.indexOf('ep') === 0 && key.indexOf('_') > 0) keyName = '_' + key;

                            query += keyName.split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '=';
                            if (data[key]) {
                                query += data[key].split('=').join('[*#*!]').split('&').join('[*#*$]').split('|').join('[*#*%]') + '&';
                            } else {
                                query += '&';
                            }
                        }
                    }
                }

            } catch (e) {
                BOX_CUSTOM_JS.logError(e, 'processSubmitObj_query');
            }

            //BOX_CUSTOM_JS ==> BeforeSubmit
            //var customJsResBeforeSubmit = BOX_CUSTOM_JS.runCustomJsBeforeSubmit(getFriendlyPagePrefix(pref), data, post_to_keen_query);
            var customJsResBeforeSubmit = BOX_CUSTOM_JS.runCustomJsBeforeSubmit(data);
            if (typeof customJsResBeforeSubmit === 'boolean' && customJsResBeforeSubmit === false) {
                return false;
            } else if (typeof customJsResBeforeSubmit === 'string' && customJsResBeforeSubmit.trim().length > 0) {
                showError('', '', customJsResBeforeSubmit);
                return false;
            } else if (typeof customJsResBeforeSubmit === 'object' && customJsResBeforeSubmit !== null) {
                data = customJsResBeforeSubmit;
            }

            if (pref === '') {
                query += '_pg=main';
                postMessageSubmit(data, query, using_form, pref);
            } else if (pref.indexOf('_') > 0) {
                query += '_pg=' + pref.split('_')[0];
                if (pref === 'thx_') postMessageSubmit(data, query, using_form_thx, pref);
                else if (pref === 'ep1_') postMessageSubmit(data, query, using_form_ep1, pref);
                else if (pref === 'ep2_') postMessageSubmit(data, query, using_form_ep2, pref);
                else if (pref === 'ep3_') postMessageSubmit(data, query, using_form_ep3, pref);
                else if (pref === 'ep4_') postMessageSubmit(data, query, using_form_ep4, pref);
                else if (pref.indexOf('ep') === 0) {
                    var pNum = getExtraPageNumberFromEPString(pref);
                    var using_epN_form = settings.hasOwnProperty('ep' + pNum + 'layout') && settings.hasOwnProperty('ep' + pNum + '_form') && settings['ep' + pNum + '_form'].display;
                    postMessageSubmit(data, query, using_epN_form, pref);
                }
            } else {
                query += '_pg=' + pref;
                postMessageSubmit(data, query, using_form, pref);
            }

            //var customJsAfterSubmit = BOX_CUSTOM_JS.runCustomJsAfterSubmit(getFriendlyPagePrefix(pref));
            var customJsAfterSubmit = BOX_CUSTOM_JS.runCustomJsAfterSubmit(data);
            if (typeof customJsAfterSubmit === 'boolean' && customJsAfterSubmit === false) {
                return false;
            }

            if (settings[pref + 'form'].after_submit == 'lightbox_open' && settings[pref + 'form'].lightbox_open && settings[pref + 'form'].lightbox_open.length > 0) {
                window.setTimeout(function() {
                    hideLoading();

                    var prop = {};
                    prop.lightbox_open = settings[pref + 'form'].lightbox_open;
                    postMessageOpenAnotherBox(prop, 'form');
                }, 50);
            } else {
                //window.setTimeout(function () {

                //    hideLoading();
                //    afterSubmit(pref);
                //}, 2500);
                afterSubmit(pref, overrideFormSubmitAction);
            }
        }
    }
}

function afterSubmit(pref, overrideFormSubmitAction) {
    try {
        if (typeof overrideFormSubmitAction !== 'string')
            overrideFormSubmitAction = '';

        var submitAction = settings[pref + 'form'].after_submit;
        if (overrideFormSubmitAction.length > 4)
            submitAction = overrideFormSubmitAction;

        if (submitAction === 'main_page') {
            window.setTimeout(function() {
                hideLoading();
                changePages('', 'form', settings['form'], 'form');
            }, 400);
        } else if (submitAction === 'thank_you_page') {
            window.setTimeout(function() {
                hideLoading();
                changePages('thx_', pref + 'form', settings[pref + 'form'], 'form');
            }, 400);
        } else if (submitAction === 'extra_page_1') {
            window.setTimeout(function() {
                hideLoading();
                changePages('ep1_', pref + 'form', settings[pref + 'form'], 'form');
            }, 300);
        } else if (submitAction === 'extra_page_2') {
            window.setTimeout(function() {
                hideLoading();
                changePages('ep2_', pref + 'form', settings[pref + 'form'], 'form');
            }, 300);
        } else if (submitAction === 'extra_page_3') {
            window.setTimeout(function() {
                hideLoading();
                changePages('ep3_', pref + 'form', settings[pref + 'form'], 'form');
            }, 300);
        } else if (submitAction === 'extra_page_4') {
            window.setTimeout(function() {
                hideLoading();
                changePages('ep4_', pref + 'form', settings[pref + 'form'], 'form');
            }, 300);
        } else if (submitAction.indexOf('extra_page_') === 0) {
            var pNum = submitAction.replace('extra_page_', '');

            window.setTimeout(function() {
                hideLoading();
                changePages('ep' + pNum + '_', pref + 'form', settings[pref + 'form'], 'form');
            }, 300);
        } else if (submitAction == 'redirect' && settings[pref + 'form'].redirect_url) {
            var timeout = parent.DIGIOH_API.GET_ANALYTICS().VARS.country != 'US' ? 2000 : 800;

            window.setTimeout(function() {
                hideLoading();
                var prop = {};
                if (settings[pref + 'form'].redirect_url.toLowerCase().trim().indexOf('http') === 0 || settings[pref + 'form'].redirect_url.toLowerCase().trim().indexOf('mailto') === 0) {
                    prop.url = settings[pref + 'form'].redirect_url;
                } else {
                    prop.url = 'http://' + settings[pref + 'form'].redirect_url;
                }

                if (settings[pref + 'form'].hasOwnProperty('redirect_type') && settings[pref + 'form'].redirect_type) {
                    prop.redirect_type = settings[pref + 'form'].redirect_type;
                } else {
                    prop.redirect_type = 'current';
                }

                postMessageRedirectParent(prop, 'form');
            }, timeout);
        } else if (submitAction == 'close') {
            window.setTimeout(function() {
                hideLoading();
                postMessageCloseBox('form_submit');
            }, 400);
        } else if (submitAction == 'nothing') {
            window.setTimeout(function() {
                hideLoading();
            }, 400);
        } else {
            window.setTimeout(function() {
                hideLoading();
                postMessageCloseBox('form_submit');
            }, 400);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'afterSubmit');
    }
}

function changePages(pref, el_name, prop, ui_source) {
    try {
        var previous_page = CURRENT_PAGE;

        var customJsBeforeChangePages = BOX_CUSTOM_JS.runCustomJsBeforeChangePages(getFriendlyPagePrefix(previous_page), getFriendlyPagePrefix(pref), el_name, prop, ui_source);
        if (typeof customJsBeforeChangePages === 'boolean' && customJsBeforeChangePages === false) {
            return false;
        }

        var modal_width = 0;
        var modal_height = 0;

        if (CURRENT_WIDTH === 0) {
            CURRENT_WIDTH = settings.layout.width;
        }

        if (CURRENT_HEIGHT === 0) {
            CURRENT_HEIGHT = settings.layout.height;
        }

        pref = getUnfriendlyPagePrefix(pref);

        if (pref === 'thx_' && settings.hasOwnProperty('thxlayout')) {
            modal_width = settings.thxlayout.width;
            modal_height = settings.thxlayout.height;
            CURRENT_PAGE = 'thx';
            buildStyles('thx');
            loadImages('thx');
            loadExternalFonts('thx');
            replaceSettingsObjFormMergeTagsAfterChangePages('thx');
        } else if (pref === 'ep1_' && settings.hasOwnProperty('ep1layout')) {
            modal_width = settings.ep1layout.width;
            modal_height = settings.ep1layout.height;
            CURRENT_PAGE = 'ep1';
            buildStyles('ep1');
            loadImages('ep1');
            loadExternalFonts('ep1');
            replaceSettingsObjFormMergeTagsAfterChangePages('ep1');
        } else if (pref === 'ep2_' && settings.hasOwnProperty('ep2layout')) {
            modal_width = settings.ep2layout.width;
            modal_height = settings.ep2layout.height;
            CURRENT_PAGE = 'ep2';
            buildStyles('ep2');
            loadImages('ep2');
            loadExternalFonts('ep2');
            replaceSettingsObjFormMergeTagsAfterChangePages('ep2');
        } else if (pref === 'ep3_' && settings.hasOwnProperty('ep3layout')) {
            modal_width = settings.ep3layout.width;
            modal_height = settings.ep3layout.height;
            CURRENT_PAGE = 'ep3';
            buildStyles('ep3');
            loadImages('ep3');
            loadExternalFonts('ep3');
            replaceSettingsObjFormMergeTagsAfterChangePages('ep3');
        } else if (pref === 'ep4_' && settings.hasOwnProperty('ep4layout')) {
            modal_width = settings.ep4layout.width;
            modal_height = settings.ep4layout.height;
            CURRENT_PAGE = 'ep4';
            buildStyles('ep4');
            loadImages('ep4');
            loadExternalFonts('ep4');
            replaceSettingsObjFormMergeTagsAfterChangePages('ep4');
        } else if (pref.indexOf('ep') === 0) {
            var pNum = getExtraPageNumberFromEPString(pref);
            if (settings.hasOwnProperty('ep' + pNum + 'layout')) {
                modal_width = settings['ep' + pNum + 'layout'].width;
                modal_height = settings['ep' + pNum + 'layout'].height;
                CURRENT_PAGE = 'ep' + pNum;
                buildStyles('ep' + pNum);
                loadImages('ep' + pNum);
                loadExternalFonts('ep' + pNum);
                replaceSettingsObjFormMergeTagsAfterChangePages('ep' + pNum);
            }
        } else {
            modal_width = settings.layout.width;
            modal_height = settings.layout.height;
            CURRENT_PAGE = 'main';
        }

        postMessageChangePages(pref, modal_width, modal_height, CURRENT_WIDTH, CURRENT_HEIGHT, getFriendlyPagePrefix(previous_page), getFriendlyPagePrefix(pref), el_name, prop, ui_source);

        var pref_resp = 'responsive';
        if (CURRENT_PAGE !== 'main') {
            pref_resp = CURRENT_PAGE + pref_resp;
        }

        if (!settings.hasOwnProperty(pref_resp) || !settings[pref_resp].use) {
            CURRENT_WIDTH = modal_width;
            CURRENT_HEIGHT = modal_height;
        }

        //showLoading('');

        setTimeout(function() {
            //hideLoading();

            if (pref === 'thx_' && settings.hasOwnProperty('thxlayout')) {
                $('#layout').hide();
                if (settings.hasOwnProperty('thxlayout') && $('#thxlayout').length) $('#thxlayout').show();

                if (settings.hasOwnProperty("extra_pages")) {
                    for (var j = 1; j <= 100; j++) {
                        if (settings.extra_pages.length >= j && settings.extra_pages[j - 1] && settings.extra_pages[j - 1]['on'] === 1) {
                            if (settings.hasOwnProperty('ep' + j + 'layout') && $('#ep' + j + 'layout').length) $('#ep' + j + 'layout').hide();
                        }
                    }
                }

                if (settings.hasOwnProperty('ep1layout') && $('#ep1layout').length) $('#ep1layout').hide();
                if (settings.hasOwnProperty('ep2layout') && $('#ep2layout').length) $('#ep2layout').hide();
                if (settings.hasOwnProperty('ep3layout') && $('#ep3layout').length) $('#ep3layout').hide();
                if (settings.hasOwnProperty('ep4layout') && $('#ep4layout').length) $('#ep4layout').hide();
            }
            //else if (pref === 'ep1_' && settings.hasOwnProperty('ep1layout'))
            //{
            //    $('#layout').hide();
            //    if (settings.hasOwnProperty('ep1layout')) $('#ep1layout').show();
            //    if (settings.hasOwnProperty('ep2layout')) $('#ep2layout').hide();
            //    if (settings.hasOwnProperty('ep3layout')) $('#ep3layout').hide();
            //    if (settings.hasOwnProperty('ep4layout')) $('#ep4layout').hide();
            //    if (settings.hasOwnProperty('thxlayout')) $('#thxlayout').hide();
            //} else if (pref === 'ep2_' && settings.hasOwnProperty('ep2layout')) {
            //    $('#layout').hide();
            //    if (settings.hasOwnProperty('ep1layout')) $('#ep1layout').hide();
            //    if (settings.hasOwnProperty('ep2layout')) $('#ep2layout').show();
            //    if (settings.hasOwnProperty('ep3layout')) $('#ep3layout').hide();
            //    if (settings.hasOwnProperty('ep4layout')) $('#ep4layout').hide();
            //    if (settings.hasOwnProperty('thxlayout')) $('#thxlayout').hide();
            //} else if (pref === 'ep3_' && settings.hasOwnProperty('ep3layout')) {
            //    $('#layout').hide();
            //    if (settings.hasOwnProperty('ep1layout')) $('#ep1layout').hide();
            //    if (settings.hasOwnProperty('ep2layout')) $('#ep2layout').hide();
            //    if (settings.hasOwnProperty('ep3layout')) $('#ep3layout').show();
            //    if (settings.hasOwnProperty('ep4layout')) $('#ep4layout').hide();
            //    if (settings.hasOwnProperty('thxlayout')) $('#thxlayout').hide();
            //} else if (pref === 'ep4_' && settings.hasOwnProperty('ep4layout')) {
            //    $('#layout').hide();
            //    if (settings.hasOwnProperty('ep1layout')) $('#ep1layout').hide();
            //    if (settings.hasOwnProperty('ep2layout')) $('#ep2layout').hide();
            //    if (settings.hasOwnProperty('ep3layout')) $('#ep3layout').hide();
            //    if (settings.hasOwnProperty('ep4layout')) $('#ep4layout').show();
            //    if (settings.hasOwnProperty('thxlayout')) $('#thxlayout').hide();
            //}
            else if (pref.indexOf('ep') === 0) {
                var pNum = getExtraPageNumberFromEPString(pref);
                if (settings.hasOwnProperty('ep' + pNum + 'layout')) {
                    $('#layout').hide();
                    if (settings.hasOwnProperty('thxlayout') && $('#thxlayout').length) $('#thxlayout').hide();

                    if (settings.hasOwnProperty("extra_pages")) {
                        for (var j = 1; j <= 100; j++) {
                            if (settings.extra_pages.length >= j && settings.extra_pages[j - 1] && settings.extra_pages[j - 1]['on'] === 1 && j.toString() != pNum) {
                                if (settings.hasOwnProperty('ep' + j + 'layout') && $('#ep' + j + 'layout').length) $('#ep' + j + 'layout').hide();
                            }
                        }
                    }

                    if (settings.hasOwnProperty('ep1layout') && $('#ep1layout').length) $('#ep1layout').hide();
                    if (settings.hasOwnProperty('ep2layout') && $('#ep2layout').length) $('#ep2layout').hide();
                    if (settings.hasOwnProperty('ep3layout') && $('#ep3layout').length) $('#ep3layout').hide();
                    if (settings.hasOwnProperty('ep4layout') && $('#ep4layout').length) $('#ep4layout').hide();

                    $('#ep' + pNum + 'layout').show();
                }
            } else {
                $('#layout').show();
                if (settings.hasOwnProperty('thxlayout') && $('#thxlayout').length) $('#thxlayout').hide();

                if (settings.hasOwnProperty("extra_pages")) {
                    for (var j = 1; j <= 100; j++) {
                        if (settings.extra_pages.length >= j && settings.extra_pages[j - 1] && settings.extra_pages[j - 1]['on'] === 1) {
                            if (settings.hasOwnProperty('ep' + j + 'layout') && $('#ep' + j + 'layout').length) $('#ep' + j + 'layout').hide();
                        }
                    }
                }

                if (settings.hasOwnProperty('ep1layout') && $('#ep1layout').length) $('#ep1layout').hide();
                if (settings.hasOwnProperty('ep2layout') && $('#ep2layout').length) $('#ep2layout').hide();
                if (settings.hasOwnProperty('ep3layout') && $('#ep3layout').length) $('#ep3layout').hide();
                if (settings.hasOwnProperty('ep4layout') && $('#ep4layout').length) $('#ep4layout').hide();
            }
        }, 100);

        var customJsAfterChangePages = BOX_CUSTOM_JS.runCustomJsAfterChangePages(getFriendlyPagePrefix(previous_page), getFriendlyPagePrefix(pref), el_name, prop, ui_source);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'changePages');
    }
}

function postMessageChangePages(pref, new_width, new_height, old_width, old_height, previous_page, new_page, el_name, prop, ui_source) {
    sendMessageToParent({
        sender: 'lightbox',
        child_action: 'change_pages',
        lightbox_id: LIGHTBOX_OR_VARIATION_GUID,
        width: new_width,
        height: new_height,
        width_prev: old_width,
        height_prev: old_height,
        page_prefix: pref,
        previous_page: previous_page,
        new_page: new_page,
        el_name: el_name,
        ui_source: ui_source
    });
}

function postMessageCloseBox(trig) {
    sendMessageToParent({
        sender: 'lightbox',
        child_action: 'close_lightbox',
        lightbox_id: LIGHTBOX_OR_VARIATION_GUID,
        trigger: trig
    });
}

function postMessageRedirectParent(prop, ui_source) {
    var customJsBeforeRedirect = BOX_CUSTOM_JS.runCustomJsBeforeRedirect(prop, ui_source);
    if (typeof customJsBeforeRedirect === 'boolean' && customJsBeforeRedirect === false) {
        return false;
    }

    sendMessageToParent({
        sender: 'lightbox',
        child_action: 'redirect_parent',
        lightbox_id: LIGHTBOX_OR_VARIATION_GUID,
        url: prop.url,
        ui_trigger: ui_source,
        redirect_type: prop.redirect_type
    });

    var customJsAfterRedirect = BOX_CUSTOM_JS.runCustomJsAfterRedirect(prop, ui_source);
}

function postMessageOpenAnotherBox(prop, ui_source) {
    var customJsBeforeOpenAnotherBox = BOX_CUSTOM_JS.runCustomJsBeforeOpenAnotherBox(prop.lightbox_open, ui_source);
    if (typeof customJsBeforeOpenAnotherBox === 'boolean' && customJsBeforeOpenAnotherBox === false) {
        return false;
    }

    sendMessageToParent({
        sender: 'lightbox',
        child_action: 'lightbox_open',
        lightbox_id: LIGHTBOX_OR_VARIATION_GUID,
        lightbox_open: prop.lightbox_open,
        ui_trigger: ui_source
    });

    var customJsAfterOpenAnotherBox = BOX_CUSTOM_JS.runCustomJsAfterOpenAnotherBox(prop.lightbox_open, ui_source);
}

function postMessageSubmit(data, post_to_keen_query, pref_using_form, pref) {
    var submit_data = parent.DIGIOH_API.LIGHTBOX.LZString.compressToBase64(JSON.stringify(data));
    var query_data = parent.DIGIOH_API.LIGHTBOX.LZString.compressToBase64(post_to_keen_query);

    sendMessageToParent({
        sender: 'lightbox',
        child_action: 'register_analytics_submit',
        lightbox_id: LIGHTBOX_OR_VARIATION_GUID,
        submission: submit_data,
        post_to_keen: query_data,
        form_display: pref_using_form,
        page_prefix: pref
    });
}

function postMessageCouponUsed(coupon_group_id, coupon_value, success_or_error, populate_on, code_section_trigger, code_section_response, pref) {
    sendMessageToParent({
        sender: 'lightbox',
        child_action: 'coupon_used',
        lightbox_id: LIGHTBOX_OR_VARIATION_GUID,
        coupon_meta_data: {
            coupon_group_id: coupon_group_id,
            coupon_value: coupon_value,
            success_or_error: success_or_error,
            populate_on: populate_on,
            code_section_trigger: code_section_trigger,
            code_section_response: code_section_response,
            pref: pref
        }
    });
}

function processDownload(prop) {
    //var src = PROTOCOL_USER_OVERRIDE + 's3.lightboxcdn.com/vendors/' + VENDOR_GUID + '/uploads/' + prop.file;
    //sendMessageToParent({ child_action: 'download_file', lightbox_id: LIGHTBOX_OR_VARIATION_GUID, url: src });

    sendMessageToParent({
        sender: 'lightbox',
        child_action: 'download_file',
        lightbox_id: LIGHTBOX_OR_VARIATION_GUID
    });

    //window.open(src);
}

function setButtonMetaDataLayer(prop) {
    try {
        if (prop.hasOwnProperty('metadata_kvps')) {
            for (var k = 0; k < prop.metadata_kvps.length; k++) {
                if (prop.metadata_kvps[k].k && prop.metadata_kvps[k].v) {
                    if (prop.metadata_kvps[k].k.indexOf('[') == 0 && prop.metadata_kvps[k].k.indexOf(']') > 0) {
                        //if (prop.metadata_kvps[k].k.toLowerCase().indexOf('custom_') > 0 || prop.metadata_kvps[k].k.toLowerCase().indexOf('email') > 0 || prop.metadata_kvps[k].k.toLowerCase().indexOf('name') > 0 || prop.metadata_kvps[k].k.toLowerCase().indexOf('phone') > 0 || prop.metadata_kvps[k].k.toLowerCase().indexOf('opt_in') > 0)
                        parent.DIGIOH_API.setDataLayerValue(prop.metadata_kvps[k].k.split(' ').join('').replace('[', '').replace(']', '').toLowerCase(), prop.metadata_kvps[k].v);
                        parent.DIGIOH_API.setDataLayerValue(prop.metadata_kvps[k].k.split(' ').join('').replace('[', '').replace(']', '').toLowerCase(), prop.metadata_kvps[k].v, boxapi.getId());
                    }
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'setButtonMetaDataLayer');
    }
}

var SELECTED_BUTTON_FORM_VALUES = {};

function buildButtonN(el, elWrapper, elName, prop, pref) {
    try {
        if (prop.display) {
            el.text(prop.text);

            //Hover State
            if (!IS_MOBILE) {
                el.hover(function() {
                    $(this).addClass(elName + '_hover');
                    $(document).trigger('BOX_BUTTON_HOVER_IN', [getFriendlyPagePrefix(pref), elName, prop]);
                }, function() {
                    $(this).removeClass(elName + '_hover');
                    $(document).trigger('BOX_BUTTON_HOVER_OUT', [getFriendlyPagePrefix(pref), elName, prop]);
                });
            }

            if (prop.action == 'download' && prop.file && prop.file.length > 7) {
                var src = PROTOCOL_USER_OVERRIDE + 's3.lightboxcdn.com/vendors/' + VENDOR_GUID + '/uploads/' + prop.file;
                el.wrap('<a style="border: none;" target="_blank" href="' + src + '"></a>');

                el.parent().on(IS_MOBILE ? 'click' : 'mousedown', function(e) {
                    $(document).trigger('BOX_BUTTON_CLICK', [getFriendlyPagePrefix(pref), elName, prop]);

                    e.stopPropagation();

                    //fsdbx
                    setButtonMetaDataLayer(prop);

                    var customJsResBeforeDownload = BOX_CUSTOM_JS.runCustomJsBeforeDownload(getFriendlyPagePrefix(pref), elName, prop);
                    if (typeof customJsResBeforeDownload === 'boolean' && customJsResBeforeDownload === false) {
                        e.preventDefault();
                        return false;
                    }

                    processDownload(prop);
                    //logger('file download from button click!!!!!');

                    var customJsResAfterDownload = BOX_CUSTOM_JS.runCustomJsAfterDownload(getFriendlyPagePrefix(pref), elName, prop);

                    return true;
                });

                //el.mousedown(function () {
                //    $(this).addClass(elName + '_focus');
                //}).mouseup(function () {
                //    $(this).removeClass(elName + '_focus');
                //});

                el.on(IS_MOBILE ? 'touchstart' : 'mousedown', function() {
                    $(this).addClass(elName + '_focus');
                }).on(IS_MOBILE ? 'touchend' : 'mouseup', function() {
                    $(this).removeClass(elName + '_focus');
                    $(document).trigger('BOX_BUTTON_RELEASE', [getFriendlyPagePrefix(pref), elName, prop]);
                });

            } else {

                //elName = ep1button1, button3
                el.on('focus', function(e) {
                    if (prop.action == 'submit') {
                        $(this).addClass('button_focus_tab_submit');
                    } else if (prop.action == 'close') {
                        $(this).addClass('button_focus_tab_close');
                    } else if (prop.action == 'url' && prop.url) {
                        $(this).addClass('button_focus_tab_redirect');
                    } else if (prop.action == 'lightbox_open' && prop.lightbox_open && prop.lightbox_open.length > 0) {
                        $(this).addClass('button_focus_tab_lightbox_open');
                    } else if (prop.action.indexOf('_page') > 0) {
                        $(this).addClass('button_focus_tab_change_pages');
                    }
                }).on('blur', function(e) {
                    if ($(this).hasClass('button_focus_tab_submit')) {
                        $(this).removeClass('button_focus_tab_submit');
                    }
                    if ($(this).hasClass('button_focus_tab_close')) {
                        $(this).removeClass('button_focus_tab_close');
                    }
                    if ($(this).hasClass('button_focus_tab_redirect')) {
                        $(this).removeClass('button_focus_tab_redirect');
                    }
                    if ($(this).hasClass('button_focus_tab_lightbox_open')) {
                        $(this).removeClass('button_focus_tab_lightbox_open');
                    }
                    if ($(this).hasClass('button_focus_tab_change_pages')) {
                        $(this).removeClass('button_focus_tab_change_pages');
                    }
                });

                if (prop.action && prop.action !== 'nothing') {
                    el.on(IS_MOBILE ? 'click' : 'mousedown', function(e) {
                        $(document).trigger('BOX_BUTTON_CLICK', [getFriendlyPagePrefix(pref), elName, prop]);

                        e.stopPropagation();

                        //fsdbx
                        setButtonMetaDataLayer(prop);

                        //console.log('click_' + elName);

                        $(this).addClass(elName + '_focus');

                        if (prop.action === 'submit') {
                            if (prop.hasOwnProperty('override_form_submit_action') && prop.override_form_submit_action) {
                                processSubmitObj({
                                    pageName: pref,
                                    overrideFormSubmitAction: prop.override_form_submit_action
                                });
                            } else {
                                processSubmit(pref, false, false, true);
                            }
                        } else if (prop.action === 'select') {
                            if (!$(this).hasClass(elName + '_selected')) {
                                //elName = ep1button7
                                $(this).addClass(elName + '_selected');

                                if (prop.hasOwnProperty('selected_field') && prop.selected_field && prop.hasOwnProperty('selected_value') && prop.selected_value.length > 0) {
                                    var base_selected_field = 'custom_' + prop.selected_field;
                                    var pref_selected_field = boxapi.getPageName() + '_custom_' + prop.selected_field;

                                    if (!SELECTED_BUTTON_FORM_VALUES.hasOwnProperty(pref_selected_field))
                                        SELECTED_BUTTON_FORM_VALUES[pref_selected_field] = [prop.selected_value];
                                    else if ($.inArray(prop.selected_value, SELECTED_BUTTON_FORM_VALUES[pref_selected_field]) < 0)
                                        SELECTED_BUTTON_FORM_VALUES[pref_selected_field].push(prop.selected_value);

                                    parent.DIGIOH_API.setDataLayerValue(base_selected_field, SELECTED_BUTTON_FORM_VALUES[pref_selected_field].join(','));
                                    parent.DIGIOH_API.setDataLayerValue(pref_selected_field, SELECTED_BUTTON_FORM_VALUES[pref_selected_field].join(','));

                                    //console.log('SELECTED_BUTTON_FORM_VALUES');
                                    //console.log(SELECTED_BUTTON_FORM_VALUES);
                                }

                            } else if ($(this).hasClass(elName + '_selected')) {
                                //elName = ep1button7
                                $(this).removeClass(elName + '_selected');

                                if (prop.hasOwnProperty('selected_field') && prop.selected_field && prop.hasOwnProperty('selected_value') && prop.selected_value.length > 0) {
                                    var base_selected_field = 'custom_' + prop.selected_field;
                                    var pref_selected_field = boxapi.getPageName() + '_custom_' + prop.selected_field;

                                    if (SELECTED_BUTTON_FORM_VALUES.hasOwnProperty(pref_selected_field) && $.inArray(prop.selected_value, SELECTED_BUTTON_FORM_VALUES[pref_selected_field]) >= 0) {
                                        SELECTED_BUTTON_FORM_VALUES[pref_selected_field] = boxapi.remove(SELECTED_BUTTON_FORM_VALUES[pref_selected_field], prop.selected_value);

                                        parent.DIGIOH_API.setDataLayerValue(base_selected_field, SELECTED_BUTTON_FORM_VALUES[pref_selected_field].join(','));
                                        parent.DIGIOH_API.setDataLayerValue(pref_selected_field, SELECTED_BUTTON_FORM_VALUES[pref_selected_field].join(','));
                                    }

                                    //console.log('SELECTED_BUTTON_FORM_VALUES');
                                    //console.log(SELECTED_BUTTON_FORM_VALUES);
                                }
                            }
                        } else if (prop.action === 'close') {
                            if (IS_MOBILE) {
                                setTimeout(function() {
                                    postMessageCloseBox('button_click');
                                }, 150);
                            } else {
                                setTimeout(function() {
                                    postMessageCloseBox('button_click');
                                }, 10);
                            }
                        } else if (prop.action === 'url' && prop.url) {
                            if (prop.url.toLowerCase().trim().indexOf('http') !== 0 && prop.url.toLowerCase().trim().indexOf('mailto') !== 0) {
                                prop.url = 'http://' + prop.url;
                            }

                            if (!prop.hasOwnProperty('redirect_type') || !prop.redirect_type) {
                                prop.redirect_type = 'current';
                            }

                            postMessageRedirectParent(prop, 'button');

                        } else if (prop.action === 'lightbox_open' && prop.lightbox_open && prop.lightbox_open.length > 0) {

                            if (IS_MOBILE) {
                                setTimeout(function() {
                                    postMessageOpenAnotherBox(prop, 'button');
                                }, 150);
                            } else {
                                setTimeout(function() {
                                    postMessageOpenAnotherBox(prop, 'button');
                                }, 10);
                            }

                        } else if (prop.action === 'main_page' || prop.action === 'thank_you_page' || prop.action.indexOf('extra_page_') === 0) {
                            var changePagePref = '';
                            if (prop.action === 'thank_you_page') {
                                changePagePref = 'thx_';
                            } else if (prop.action.indexOf('extra_page_') >= 0) {
                                changePagePref = 'ep' + prop.action.split('_')[2] + '_';
                            }

                            if (IS_MOBILE) {
                                setTimeout(function() {
                                    changePages(changePagePref, elName, prop, 'button');
                                }, 150);
                            } else {
                                changePages(changePagePref, elName, prop, 'button');
                            }
                        } else if (prop.action === 'nothing') {
                            //fsdbx
                            setButtonMetaDataLayer(prop);
                        }

                        //else if (prop.action == 'download' && prop.file && prop.file.length > 7) {
                        //    processDownload(prop);
                        //}

                        //}).mouseup(function () {
                    });
                    //.on(IS_MOBILE ? 'touchend' : 'mouseup', function () {
                    //    $(this).removeClass(elName + '_focus');
                    //});
                } else {
                    //Action = Do Nothing
                    el.on(IS_MOBILE ? 'click' : 'mousedown', function(e) {
                        $(document).trigger('BOX_BUTTON_CLICK', [getFriendlyPagePrefix(pref), elName, prop]);
                        e.stopPropagation();
                    });
                }

                el.on(IS_MOBILE ? 'touchstart' : 'mousedown', function() {
                    $(this).addClass(elName + '_focus');
                }).on(IS_MOBILE ? 'touchend' : 'mouseup', function() {
                    $(this).removeClass(elName + '_focus');
                    $(document).trigger('BOX_BUTTON_RELEASE', [getFriendlyPagePrefix(pref), elName, prop]);
                });
            }
        } else {
            el.hide();
            elWrapper.hide();
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildButtonN');
    }
}

function loadImages(pref) {
    try {
        if (typeof pref !== 'string' || pref === 'main') {
            pref = '';
        }

        if (boxapi.contains(pref, '_')) {
            pref = pref.split('_')[0];
        }

        if (pref !== '' && !LoadedPageImages.hasOwnProperty(pref)) {
            LoadedPageImages[pref] = true;
        } else if (LoadedPageImages.hasOwnProperty(pref) && LoadedPageImages[pref] === true) {
            return;
        }

        //logger('loadImages(' + pref + ')');

        for (var x = 1; x <= 50; x++) {
            if (settings.hasOwnProperty(pref + 'image' + x))
                loadImageN(pref + 'image' + x);
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'loadImages');
    }
}

function loadImageN(prop_name) {
    try {
        //ImageSrcMap[prop_name] = { img_obj: img, img_src: src,  img_element: el };
        var attr = $('#' + prop_name).attr('src');
        if (ImageSrcMap.hasOwnProperty(prop_name) && (typeof attr === 'undefined' || attr === false || !attr)) {
            ImageSrcMap[prop_name].img_element.attr('src', ImageSrcMap[prop_name].img_src);
            ImageSrcMap[prop_name].img_obj.src = ImageSrcMap[prop_name].img_src;
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'loadImageN');
    }
}

function buildImages() {
    try {
        var pr = '';

        for (var j = 1; j <= 102; j++) {

            //if (y === 5) pr = 'thx';
            //else if (y === 6) pr = '';
            //else pr = 'ep' + y;

            if (j == 1) {
                pr = '';
            } else if (j == 2) {
                pr = 'thx';
            } else if (j >= 3 && j <= 6) {
                pr = 'ep' + (j - 2);
            } else if (j >= 7) {
                pr = 'ep' + (j - 2);

                if (!settings.hasOwnProperty("extra_pages") || settings.extra_pages.length <= (j - 3) || !settings.extra_pages[j - 3] || settings.extra_pages[j - 3]['on'] !== 1) {
                    continue;
                }
            }

            for (var x = 1; x <= 50; x++) {
                if (settings.hasOwnProperty(pr + 'image' + x) && settings[pr + 'image' + x].display) {
                    if (!image_dims.hasOwnProperty(pr + 'image' + x)) {
                        image_dims[pr + 'image' + x] = {
                            width: 100,
                            height: 100
                        };
                    }

                    if (settings[pr + 'image' + x].hasOwnProperty('metadata_kvps')) {
                        for (var k = 0; k < settings[pr + 'image' + x].metadata_kvps.length; k++) {
                            if (settings[pr + 'image' + x].metadata_kvps[k].k && settings[pr + 'image' + x].metadata_kvps[k].v) {
                                trySetAttribute(pr + 'image' + x, settings[pr + 'image' + x].metadata_kvps[k]);
                            }
                        }
                    }

                    buildImageN(image_dims[pr + 'image' + x], $('#' + pr + 'image' + x + '_wrapper'), $('#' + pr + 'image' + x), pr + 'image' + x, settings[pr + 'image' + x]);
                }
            }
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildImages');
    }
}

function buildImageN(el_dims, el_wrapper, el, prop_name, prop) {
    try {
        if (prop.display && prop.src && prop.src !== 'none' && prop.src.length > 5) {
            var src = PROTOCOL_USER_OVERRIDE + 's3.lightboxcdn.com/vendors/' + VENDOR_GUID + '/uploads/' + prop.src;
            //el.attr('src', src);

            var img = new Image();
            img.onload = function() {
                el_dims.width = this.width;
                el_dims.height = this.height;
                resizeImage(el_dims, el_wrapper, el, prop_name, prop.width, prop.height, false);
                el_wrapper.show();
            };

            //img.src = src;
            ImageSrcMap[prop_name] = {
                img_obj: img,
                img_src: src,
                img_element: el
            };

        } else {
            el_wrapper.hide();
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildImageN');
    }
}

function resizeImage(el_dims, el_wrapper, el, prop_name, wrapperWidth, wrapperHeight, isDynamic) {
    try {
        var prop = settings[prop_name];

        if (prop.constrain) {
            var width = wrapperWidth - (2 * prop.border.width) - (2 * prop.padding);
            if (prop.border.style === 'none' || prop.border.width === '0' || prop.border.width === 0) {
                width = wrapperWidth - (2 * prop.padding);
            }

            var heightCalc = el_dims.height * width / el_dims.width;
            //logger('resizeImage: heightCalc=' + heightCalc + ', wrapperHeight=' + wrapperHeight);

            if (isDynamic && heightCalc < wrapperHeight - (2 * prop.padding) - 10) {
                var margin = (wrapperHeight - (2 * prop.padding) - heightCalc) / 2;
                el.css({
                    'height': 'auto',
                    'margin-top': Math.round(margin) + 'px'
                });
            } else {
                el.css({
                    'height': 'auto'
                });
            }

            el.width(Math.floor(width));
        } else {
            var width = wrapperWidth - (2 * prop.border.width) - (2 * prop.padding);
            var height = wrapperHeight - (2 * prop.border.width) - (2 * prop.padding);
            if (prop.border.style === 'none' || prop.border.width === '0' || prop.border.width === 0) {
                width = wrapperWidth - (2 * prop.padding);
            }
            if (prop.border.style === 'none' || prop.border.width === '0' || prop.border.width === 0) {
                height = wrapperHeight - (2 * prop.padding);
            }
            el.width(Math.floor(width));
            el.height(Math.floor(height));
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'resizeImage');
    }
}

function getBorderStyle(propBorder) {
    var str = '';
    if (typeof propBorder.style === 'undefined' || propBorder.style === null || propBorder.style === 'none' || propBorder.width === '0' || propBorder.width === 0) {
        str += 'border-style: none;';
        str += 'border-width: 0px;';
    } else {
        str += 'border-color: ' + propBorder.color + ';';
        str += 'border-style: ' + propBorder.style + ';';
        str += 'border-width: ' + propBorder.width + 'px' + ';';
        str += 'border-radius: ' + propBorder.radius + 'px' + ';';
    }
    return str;
}

function getBackgroundStyle(propBackground) {
    var str = '';

    //http://stackoverflow.com/questions/2504071/is-it-possible-to-combine-a-background-image-and-css3-gradients

    if (propBackground.use_image && propBackground.image.length > 3 && propBackground.image != 'none') {
        str += 'background-image: ' + 'url(' + PROTOCOL_USER_OVERRIDE + 's3.lightboxcdn.com/vendors/' + VENDOR_GUID + '/uploads/' + propBackground.image + ')' + ';';
        str += 'background-position: ' + propBackground.position + ';';
        str += 'background-color: ' + propBackground.color + ';';
        if (propBackground.repeat === 'stretch') {
            str += '-webkit-background-size: cover;';
            str += '-moz-background-size: cover;';
            str += '-o-background-size: cover;';
            str += 'background-size: cover;';
        } else {
            str += 'background-repeat: ' + propBackground.repeat + ';';
        }
    } else if (!IS_IE_9_OR_LESS && propBackground.use_gradient && propBackground.gradient.length > 3) {
        str += 'background: ' + '-webkit-gradient(linear, left top, left bottom, from(' + propBackground.color + '),to(' + propBackground.gradient + '))' + ';';
        str += 'background: ' + '-webkit-linear-gradient(top, ' + propBackground.color + ',' + propBackground.gradient + ')' + ';';
        str += 'background: ' + '-o-linear-gradient(top, ' + propBackground.color + ',' + propBackground.gradient + ')' + ';';
        str += 'background: ' + '-moz-linear-gradient(top, ' + propBackground.color + ',' + propBackground.gradient + ')' + ';';
        str += 'background: ' + '-ms-linear-gradient(top, ' + propBackground.color + ',' + propBackground.gradient + ')' + ';';
        str += 'background: ' + 'linear-gradient(to bottom,' + propBackground.color + ',' + propBackground.gradient + ')' + ';';
    } else {
        str += 'background: ' + propBackground.color + ';';
    }
    return str;
}

function getFontStyle(propFont) {
    var str = '';
    var gweight = '';
    if (propFont.family.indexOf('__google__') >= 0) {
        var gfam = propFont.family.replace('__google__', '');
        if (gfam.indexOf(':') > 0) {
            gweight = gfam.split(':')[1].split("'")[0];
            gfam = gfam.split(':')[0];
            str += 'font-family: ' + gfam + "';";
        } else {
            str += 'font-family: ' + gfam + ';';
        }
    } else if (propFont.family.indexOf('__custom__') >= 0) {
        str += 'font-family: ' + propFont.family.split('||||')[1] + ';';

    } else {
        str += 'font-family: ' + propFont.family + ';';
    }

    if (gweight) {
        if (gweight == 'Black') {
            str += 'font-weight: 900;';
        }
        if (gweight == 'ExtraBold') {
            str += 'font-weight: 800;';
        }
        if (gweight == 'Bold') {
            str += 'font-weight: 700;';
        }
        if (gweight == 'Light') {
            str += 'font-weight: 300;';
        }
        if (gweight == 'ExtraLight') {
            str += 'font-weight: 200;';
        }
        if (gweight == 'Thin') {
            str += 'font-weight: 100;';
        }
    } else {
        str += 'font-weight: ' + (propFont.bold ? 'bold' : 'normal') + ';';
    }

    str += 'font-style:  ' + (propFont.italic ? 'italic' : 'normal') + ';';
    str += 'text-decoration: ' + (propFont.underline ? 'underline' : 'none') + ';';
    str += 'text-align: ' + propFont.align + ';';
    str += 'font-size: ' + propFont.size + 'px' + ';';
    str += 'color: ' + propFont.color + ';';

    if (propFont.hasOwnProperty('vspace') && propFont.vspace !== null && propFont.vspace !== '' && propFont.vspace !== '0' && propFont.vspace !== 0) {
        str += 'line-height: ' + propFont.vspace + 'px' + ';';
    }

    return str;
}

function getWidthStyle(width) {
    var str = '';
    str += 'width: ' + width + 'px' + ';';
    return str;
}

function getWidthPercentStyle(width) {
    var str = '';
    str += 'width: ' + width + '%' + ';';
    return str;
}

function getHeightStyle(height) {
    var str = '';
    str += 'height: ' + height + 'px' + ';';
    return str;
}

function getHeightPercentStyle(height) {
    var str = '';
    str += 'height: ' + height + '%' + ';';
    return str;
}

function getLineHeightStyle(lineHeight) {
    var str = '';
    str += 'line-height: ' + lineHeight + 'px' + ';';
    return str;
}

function getTextAlignStyle(align) {
    var str = '';
    str += 'text-align: ' + align + ';';
    return str;
}

function getDisplayStyle(display) {
    var str = '';
    str += 'display: ' + (display ? 'block' : 'none') + ';';
    return str;
}

function getOverflowHiddenStyle() {
    var str = '';
    str += 'overflow: ' + 'hidden' + ';';
    return str;
}

function getOverflowVisibleStyle() {
    var str = '';
    str += 'overflow: ' + 'visible' + ';';
    return str;
}

function getFloatLeftStyle() {
    var str = '';
    str += 'float: ' + 'left' + ';';
    return str;
}

function getFloatRightStyle() {
    var str = '';
    str += 'float: ' + 'right' + ';';
    return str;
}

function getPositionAbsoluteStyle() {
    var str = '';
    str += 'position: ' + 'absolute' + ';';
    return str;
}

function getGeneralStyle(propName, propVal) {
    var str = '';
    str += propName + ': ' + propVal + ';';
    return str;
}

function getLeftStyle(left) {
    var str = '';
    str += 'left: ' + left + 'px' + ';';
    return str;
}

function getTopStyle(top) {
    var str = '';
    str += 'top: ' + top + 'px' + ';';
    return str;
}

function getLeftTopWidthHeightStyle(prop) {
    var str = '';
    str += 'left: ' + prop.x + 'px' + ';';
    str += 'top: ' + prop.y + 'px' + ';';
    str += 'width: ' + prop.width + 'px' + ';';
    str += 'height: ' + prop.height + 'px' + ';';
    return str;
}

function getTextElementLeftTopWidthHeightStyle(prop) {
    var str = '';
    str += 'left: ' + prop.x + 'px' + ';';
    str += 'top: ' + prop.y + 'px' + ';';
    str += 'width: ' + (prop.width + 5) + 'px' + ';';
    str += 'height: ' + prop.height + 'px' + ';';
    return str;
}

function getZindexStyle(zindex) {
    var str = '';
    str += 'z-index: ' + zindex + ';';
    return str;
}

function getCursorStyle(curse) {
    var str = '';
    str += 'cursor: ' + curse + ';';
    return str;
}

function buildStyles(pref, force_run) {
    try {
        var str = '';

        if (typeof pref !== 'string' || pref === 'main') {
            pref = '';
        }

        if (boxapi.contains(pref, '_')) {
            pref = pref.split('_')[0];
        }

        if (pref !== '' && !BuiltExtraPageStyles.hasOwnProperty(pref)) {
            BuiltExtraPageStyles[pref] = true;
        } else if (BuiltExtraPageStyles.hasOwnProperty(pref) && BuiltExtraPageStyles[pref] === true) {
            if (!force_run) {
                return;
            }
        }

        if (pref === '') {
            $('#element_styles').remove();
        } else {
            $('#element_styles_' + pref).remove();
        }

        logger('buildStyles(' + pref + ')');


        //**************
        //General Styles
        //**************

        if (pref === '') {
            //Float Left
            str += '.float_left {';
            str += getFloatLeftStyle();
            str += '} ';

            //Float Right
            str += '.float_right {';
            str += getFloatRightStyle();
            str += '} ';
        }




        //**************
        //Element Styles
        //**************

        //Layout
        str += '#' + pref + 'layout {';
        str += getBorderStyle(settings[pref + 'layout'].border);
        str += getBackgroundStyle(settings[pref + 'layout'].background);
        if (settings[pref + 'layout'].hasOwnProperty('width') && settings[pref + 'layout'].hasOwnProperty('height')) {
            if (settings[pref + 'layout'].border.style === 'none' || settings[pref + 'layout'].border.width === '0' || settings[pref + 'layout'].border.width === 0) {
                str += getWidthStyle(settings[pref + 'layout'].width);
                str += getHeightStyle(settings[pref + 'layout'].height);
            } else {
                str += getWidthStyle(settings[pref + 'layout'].width - (2 * settings[pref + 'layout'].border.width));
                str += getHeightStyle(settings[pref + 'layout'].height - (2 * settings[pref + 'layout'].border.width));
            }

        } else {
            if (settings['layout'].border.style === 'none' || settings['layout'].border.width === '0' || settings['layout'].border.width === 0) {
                str += getWidthStyle(settings['layout'].width);
                str += getHeightStyle(settings['layout'].height);
            } else {
                str += getWidthStyle(settings['layout'].width - (2 * settings['layout'].border.width));
                str += getHeightStyle(settings['layout'].height - (2 * settings['layout'].border.width));
            }

        }
        str += getOverflowHiddenStyle();
        str += getGeneralStyle('margin', '0');
        str += getGeneralStyle('padding', '0');
        str += '} ';

        for (var j = 1; j <= 50; j++) {

            if (settings.hasOwnProperty(pref + 'text' + j) && settings[pref + 'text' + j].display) {
                //Text Wrapper
                str += '#' + pref + 'text' + j + '_wrapper {';
                str += getDisplayStyle(settings[pref + 'text' + j].display);
                str += getPositionAbsoluteStyle();
                str += getTextElementLeftTopWidthHeightStyle(settings[pref + 'text' + j]);
                str += '} ';

                //Text
                str += '#' + pref + 'text' + j + ' {';
                str += getFontStyle(settings[pref + 'text' + j].font);

                if (settings[pref + 'text' + j].hasOwnProperty('css_kvps')) {
                    for (var k = 0; k < settings[pref + 'text' + j].css_kvps.length; k++) {
                        if (settings[pref + 'text' + j].css_kvps[k].k && settings[pref + 'text' + j].css_kvps[k].v) {
                            str += getGeneralStyle(settings[pref + 'text' + j].css_kvps[k].k, settings[pref + 'text' + j].css_kvps[k].v);
                        }
                    }
                }

                str += '} ';
            }

            if (settings.hasOwnProperty(pref + 'button' + j) && settings[pref + 'button' + j].display) {
                //Button - Wrapper
                str += '#' + pref + 'button' + j + '_wrapper {';
                str += getDisplayStyle(settings[pref + 'button' + j].display);
                str += getPositionAbsoluteStyle();
                str += getLeftTopWidthHeightStyle(settings[pref + 'button' + j]);
                str += getZindexStyle(9000);
                str += '} ';

                //Button
                str += '.' + pref + 'button' + j + ' {';
                str += getFontStyle(settings[pref + 'button' + j].font);
                str += getBorderStyle(settings[pref + 'button' + j].border);
                str += getBackgroundStyle(settings[pref + 'button' + j].background);
                str += getWidthPercentStyle(100);
                str += getHeightPercentStyle(100);
                str += getCursorStyle('pointer');

                if (settings[pref + 'button' + j].hasOwnProperty('css_kvps')) {
                    for (var k = 0; k < settings[pref + 'button' + j].css_kvps.length; k++) {
                        if (settings[pref + 'button' + j].css_kvps[k].k && settings[pref + 'button' + j].css_kvps[k].v) {
                            str += getGeneralStyle(settings[pref + 'button' + j].css_kvps[k].k, settings[pref + 'button' + j].css_kvps[k].v);
                        }
                    }
                }

                str += '} ';

                //Button - Hover
                str += '.' + pref + 'button' + j + '_hover {';
                str += getFontStyle(settings[pref + 'button' + j].font_hover);
                str += getBorderStyle(settings[pref + 'button' + j].border_hover);
                str += getBackgroundStyle(settings[pref + 'button' + j].background_hover);
                str += getCursorStyle('pointer');

                if (settings[pref + 'button' + j].hasOwnProperty('css_kvps_hover')) {
                    for (var k = 0; k < settings[pref + 'button' + j].css_kvps_hover.length; k++) {
                        if (settings[pref + 'button' + j].css_kvps_hover[k].k && settings[pref + 'button' + j].css_kvps_hover[k].v) {
                            str += getGeneralStyle(settings[pref + 'button' + j].css_kvps_hover[k].k, settings[pref + 'button' + j].css_kvps_hover[k].v);
                        }
                    }
                }

                str += '} ';



                if (settings.hasOwnProperty(pref + 'button' + j) && settings[pref + 'button' + j].action === 'select') {
                    //Button - Selected
                    str += '.' + pref + 'button' + j + '_selected {';
                    str += getFontStyle(settings[pref + 'button' + j].font_focus);
                    str += getBorderStyle(settings[pref + 'button' + j].border_focus);
                    str += getBackgroundStyle(settings[pref + 'button' + j].background_focus);
                    str += getCursorStyle('pointer');

                    if (settings[pref + 'button' + j].hasOwnProperty('css_kvps_focus')) {
                        for (var k = 0; k < settings[pref + 'button' + j].css_kvps_focus.length; k++) {
                            if (settings[pref + 'button' + j].css_kvps_focus[k].k && settings[pref + 'button' + j].css_kvps_focus[k].v) {
                                str += getGeneralStyle(settings[pref + 'button' + j].css_kvps_focus[k].k, settings[pref + 'button' + j].css_kvps_focus[k].v);
                            }
                        }
                    }

                    str += '} ';


                    //Button - Selected + Hover
                    str += '.' + pref + 'button' + j + '_hover.' + pref + 'button' + j + '_selected {';

                    if (settings[pref + 'button' + j].hasOwnProperty('font_focus_hover'))
                        str += getFontStyle(settings[pref + 'button' + j].font_focus_hover);

                    if (settings[pref + 'button' + j].hasOwnProperty('border_focus_hover'))
                        str += getBorderStyle(settings[pref + 'button' + j].border_focus_hover);

                    if (settings[pref + 'button' + j].hasOwnProperty('background_focus_hover'))
                        str += getBackgroundStyle(settings[pref + 'button' + j].background_focus_hover);

                    str += getCursorStyle('pointer');

                    if (settings[pref + 'button' + j].hasOwnProperty('css_kvps_focus_hover')) {
                        for (var k = 0; k < settings[pref + 'button' + j].css_kvps_focus_hover.length; k++) {
                            if (settings[pref + 'button' + j].css_kvps_focus_hover[k].k && settings[pref + 'button' + j].css_kvps_focus_hover[k].v) {
                                str += getGeneralStyle(settings[pref + 'button' + j].css_kvps_focus_hover[k].k, settings[pref + 'button' + j].css_kvps_focus_hover[k].v);
                            }
                        }
                    }

                    str += '} ';
                } else {
                    //Button - Focus
                    str += '.' + pref + 'button' + j + '_focus {';
                    str += getFontStyle(settings[pref + 'button' + j].font_focus);
                    str += getBorderStyle(settings[pref + 'button' + j].border_focus);
                    str += getBackgroundStyle(settings[pref + 'button' + j].background_focus);
                    str += getCursorStyle('pointer');

                    if (settings[pref + 'button' + j].hasOwnProperty('css_kvps_focus')) {
                        for (var k = 0; k < settings[pref + 'button' + j].css_kvps_focus.length; k++) {
                            if (settings[pref + 'button' + j].css_kvps_focus[k].k && settings[pref + 'button' + j].css_kvps_focus[k].v) {
                                str += getGeneralStyle(settings[pref + 'button' + j].css_kvps_focus[k].k, settings[pref + 'button' + j].css_kvps_focus[k].v);
                            }
                        }
                    }

                    str += '} ';
                }
            }

            if (settings.hasOwnProperty(pref + 'image' + j) && settings[pref + 'image' + j].display) {
                //Image Wrapper
                str += '#' + pref + 'image' + j + '_wrapper {';
                str += getDisplayStyle(settings[pref + 'image' + j].display);
                str += getPositionAbsoluteStyle();
                str += getLeftTopWidthHeightStyle(settings[pref + 'image' + j]);
                str += getTextAlignStyle('center');
                str += '} ';

                //Image 
                str += '#' + pref + 'image' + j + ' {';
                str += getBorderStyle(settings[pref + 'image' + j].border);
                str += getGeneralStyle('padding', settings[pref + 'image' + j].padding + 'px');
                if (settings[pref + 'image' + j].width >= settings[pref + 'image' + j].height) {
                    str += getGeneralStyle('max-width', settings[pref + 'image' + j].width + 'px');
                    str += getGeneralStyle('max-height', settings[pref + 'image' + j].width + 'px');
                } else {
                    str += getGeneralStyle('max-width', settings[pref + 'image' + j].height + 'px');
                    str += getGeneralStyle('max-height', settings[pref + 'image' + j].height + 'px');
                }

                if (settings[pref + 'image' + j].hasOwnProperty('css_kvps')) {
                    for (var k = 0; k < settings[pref + 'image' + j].css_kvps.length; k++) {
                        if (settings[pref + 'image' + j].css_kvps[k].k && settings[pref + 'image' + j].css_kvps[k].v) {
                            str += getGeneralStyle(settings[pref + 'image' + j].css_kvps[k].k, settings[pref + 'image' + j].css_kvps[k].v);
                        }
                    }
                }

                str += '} ';
            }

            if (settings.hasOwnProperty(pref + 'html' + j) && settings[pref + 'html' + j].display) {
                //HTML Wraper
                str += '#' + pref + 'html' + j + '_wrapper {';
                str += getDisplayStyle(settings[pref + 'html' + j].display);
                str += getPositionAbsoluteStyle();
                str += getLeftTopWidthHeightStyle(settings[pref + 'html' + j]);
                str += '} ';

                //HTML 
                str += '#' + pref + 'html' + j + ' {';

                if (settings[pref + 'html' + j].hasOwnProperty('css_kvps')) {
                    for (var k = 0; k < settings[pref + 'html' + j].css_kvps.length; k++) {
                        if (settings[pref + 'html' + j].css_kvps[k].k && settings[pref + 'html' + j].css_kvps[k].v) {
                            str += getGeneralStyle(settings[pref + 'html' + j].css_kvps[k].k, settings[pref + 'html' + j].css_kvps[k].v);
                        }
                    }
                }

                str += '} ';
            }
        }


        if (pref !== '') {
            pref += '_';
        }

        //Form Wrapper
        if (settings.hasOwnProperty(pref + 'form')) {
            str += '#' + pref + 'form_wrapper {';
            str += getDisplayStyle(settings[pref + 'form'].display);
            str += getPositionAbsoluteStyle();
            str += getLeftTopWidthHeightStyle(settings[pref + 'form']);
            str += '} ';

            //Form Spacing
            str += '.' + pref + 'form_spacing {';
            str += getGeneralStyle('margin-top', settings[pref + 'inputs'].spacing + 'px');
            str += '} ';

            //Labels
            str += '.' + pref + 'form_labels {';
            str += getFontStyle(settings[pref + 'labels'].font);
            str += getOverflowHiddenStyle();
            str += '} ';

            //Labels - Left Position
            str += '.' + pref + 'form_labels_left {';
            str += getFloatLeftStyle();
            str += getWidthPercentStyle(settings[pref + 'labels'].width);
            str += getHeightStyle(settings[pref + 'inputs'].height);
            str += getLineHeightStyle(settings[pref + 'inputs'].height);
            str += '} ';

            //Labels - Above Position
            str += '.' + pref + 'form_labels_above {';
            str += getFloatRightStyle();
            //str += getWidthPercentStyle(98);
            str += getWidthPercentStyle(100);
            str += getGeneralStyle('margin-bottom', '5px');
            str += '} ';

            //Labels - Hide
            str += '.' + pref + 'form_labels_hide {';
            str += getDisplayStyle(false);
            str += '} ';

            //Labels - Required Text
            str += '.' + pref + 'form_labels_required {';
            str += getGeneralStyle('color', settings[pref + 'labels'].required.color);
            str += getGeneralStyle('margin-left', '3px');
            str += getGeneralStyle('font-size', ((settings[pref + 'labels'].required.text == '*') ? (parseInt(settings[pref + 'labels'].font.size) + 4) : (parseInt(settings[pref + 'labels'].font.size) - 2)) + 'px');
            str += '} ';

            //Inputs
            str += '.' + pref + 'form_inputs {';
            str += getBorderStyle(settings[pref + 'inputs'].border);
            str += getBackgroundStyle(settings[pref + 'inputs'].background);
            str += getFontStyle(settings[pref + 'inputs'].font);
            str += getWidthPercentStyle(100);
            str += getHeightStyle(settings[pref + 'inputs'].height);
            str += getOverflowHiddenStyle();
            str += getGeneralStyle('-webkit-box-sizing', 'border-box');
            str += getGeneralStyle('-moz-box-sizing', 'border-box');
            str += getGeneralStyle('box-sizing', 'border-box');
            str += getGeneralStyle('padding-left', '5px');
            str += getGeneralStyle('padding-right', '5px');
            str += '} ';

            if (settings[pref + 'inputs'].hasOwnProperty('placeholder_color')) {
                str += '::placeholder {opacity: 1; color:' + settings[pref + 'inputs'].placeholder_color + '} ';
                str += ':-ms-input-placeholder {color:' + settings[pref + 'inputs'].placeholder_color + '} ';
                str += '::-ms-input-placeholder {color:' + settings[pref + 'inputs'].placeholder_color + '} ';
            }

            //Inputs - Hover
            str += '.' + pref + 'form_inputs_hover {';
            str += getBorderStyle(settings[pref + 'inputs'].border_hover);
            str += getBackgroundStyle(settings[pref + 'inputs'].background_hover);
            str += '} ';

            //Inputs - Focus
            str += '.' + pref + 'form_inputs_focus {';
            str += getBorderStyle(settings[pref + 'inputs'].border_focus);
            str += getBackgroundStyle(settings[pref + 'inputs'].background_focus);
            str += '} ';

            //Inputs - Error
            str += '.' + pref + 'form_inputs_error {';
            str += getBorderStyle(settings[pref + 'inputs'].border_error);
            str += getBackgroundStyle(settings[pref + 'inputs'].background_error);
            str += '} ';

            //Inputs - Error Text
            str += '.' + pref + 'form_inputs_error_text {';
            str += getDisplayStyle(false);
            str += getGeneralStyle('text-align', 'left');
            str += getGeneralStyle('color', settings[pref + 'inputs'].border_error.color);
            str += getGeneralStyle('font-family', settings[pref + 'labels'].font.family);
            str += getGeneralStyle('font-size', '11px');
            str += getGeneralStyle('margin-top', '2px');
            str += getGeneralStyle('margin-left', '2px');
            //str += getHeightStyle('0');
            //str += getOverflowVisibleStyle();
            str += getOverflowHiddenStyle();
            str += getWidthPercentStyle(100);
            str += '} ';

            //Inputs - Help Text
            str += '.' + pref + 'form_inputs_help {';
            str += getGeneralStyle('text-align', 'left');
            str += getGeneralStyle('color', settings[pref + 'labels'].font.color);
            str += getGeneralStyle('font-family', settings[pref + 'labels'].font.family);
            str += getGeneralStyle('font-size', '11px');
            str += getGeneralStyle('margin-top', '2px');
            str += getGeneralStyle('margin-left', '2px');
            str += getOverflowHiddenStyle();
            str += getWidthPercentStyle(100);
            str += '} ';

            //Inputs - Wrapper
            str += '.' + pref + 'form_inputs_wrapper {';
            str += getGeneralStyle('padding', '0');
            str += getFloatRightStyle();
            //str += getOverflowHiddenStyle();
            str += getOverflowVisibleStyle();
            str += getWidthPercentStyle((settings[pref + 'labels'].position == 'left') ? (100 - settings[pref + 'labels'].width - 2) : 100);
            str += '} ';

            if (settings.hasOwnProperty(pref + 'opt_in') && settings[pref + 'opt_in'].display) {
                //Opt In - Wrapper
                str += '#' + pref + 'form_input_opt_in_wrapper  {';
                str += (settings[pref + 'opt_in'].align == 'inputs' || settings[pref + 'labels'].position != 'left') ? getFloatRightStyle() : getFloatLeftStyle();
                str += getWidthPercentStyle((settings[pref + 'opt_in'].align == 'inputs' && settings[pref + 'labels'].position == 'left') ? (100 - settings[pref + 'labels'].width - 2) : 100);
                //str += getWidthStyle(settings.opt_in.width + 20);
                str += getGeneralStyle('margin-top', settings[pref + 'opt_in'].margin + 'px');
                str += '} ';

                //Opt In - Checkbox
                str += '#' + pref + 'form_input_opt_in {';
                str += getFloatLeftStyle();
                str += getGeneralStyle('margin', '0');
                str += '} ';

                //Opt In - Text
                str += '#' + pref + 'form_input_opt_in_text {';
                //str += getFloatRightStyle();
                str += getGeneralStyle('margin', '0');
                str += getFontStyle(settings[pref + 'opt_in'].font);
                str += getLineHeightStyle(settings[pref + 'opt_in'].font.size);
                //str += getWidthStyle(settings.opt_in.width);
                str += '} ';
            }



            //Custom Field - Checkbox
            var checkboxCnt = 0;
            var checkboxSequentialFloatMatchCtr = 0;
            var previousCbPropName = '';
            for (var n = 1; n <= 50; n++) {
                var propName = pref + 'custom' + n;
                if (settings.hasOwnProperty(propName) && settings[propName].display && settings[propName].hasOwnProperty('field_type') && settings[propName]['field_type'] === 'radio' && settings[propName].radio) {
                    //Custom Field - Radio Labels
                    str += '.' + pref + 'form_custom' + n + '_radio_labels {';
                    str += getLineHeightStyle(settings[propName].radio.font.size);
                    str += getFontStyle(settings[propName].radio.font);
                    str += getGeneralStyle('margin-left', '5px');
                    str += '} ';

                    str += '.' + pref + 'form_custom' + n + '_radio_inputs {';
                    str += getGeneralStyle('width', settings[propName].radio.size + 'px');
                    str += getGeneralStyle('height', settings[propName].radio.size + 'px');
                    str += getGeneralStyle('margin-top', '-3px');
                    str += getGeneralStyle('vertical-align', 'middle');
                    str += '} ';
                } else if (settings.hasOwnProperty(propName) && settings[propName].display && settings[propName].hasOwnProperty('field_type') && settings[propName]['field_type'] === 'checkbox' && settings[propName].checkbox) {
                    //logger(propName + ' checkbox found!');
                    checkboxCnt++;

                    //Custom Field - Checkbox Wrapper
                    str += '#' + pref + 'form_input_custom' + n + '_checkbox_wrapper {';

                    if (settings[propName].checkbox.align == 'inputs' || (settings[propName].checkbox.align == 'form' && settings[pref + 'labels'].position != 'left')) {
                        checkboxSequentialFloatMatchCtr = 0;
                        str += getFloatRightStyle();
                        if (settings[propName].checkbox.align == 'inputs' && settings[pref + 'labels'].position == 'left') {
                            var inputsConcreteWidth = Math.floor(settings[pref + 'form'].width * (100 - settings[pref + 'labels'].width) / 100);
                            str += getWidthStyle(inputsConcreteWidth - 7);
                        } else {
                            str += getWidthStyle(settings[pref + 'form'].width - 2);
                        }
                    } else if (settings[propName].checkbox.align == 'form' && settings[pref + 'labels'].position == 'left') {
                        checkboxSequentialFloatMatchCtr = 0;
                        str += getFloatLeftStyle();
                        str += getWidthStyle(settings[pref + 'form'].width - 2);
                    } else if (settings[propName].checkbox.align == 'float2col') {
                        checkboxSequentialFloatMatchCtr++;
                        str += getFloatLeftStyle();

                        var spacing = settings[pref + 'inputs'].spacing;
                        if (spacing < 10) spacing = 10;
                        if (spacing > 30) spacing = 30;

                        if (checkboxSequentialFloatMatchCtr % 2 === 1) {
                            str += getGeneralStyle('margin-right', spacing + 'px');
                        }

                        str += getWidthStyle(Math.floor((settings[pref + 'form'].width - spacing - 4) / 2));
                    }

                    if (settings[pref + 'inputs'].hasOwnProperty('checkboxes_margin') && settings[pref + 'inputs'].checkboxes_margin && (checkboxCnt == 1 || (checkboxCnt == 2 && settings[propName].checkbox.align == 'float2col' && settings[previousCbPropName].checkbox.align == 'float2col'))) {
                        str += getGeneralStyle('margin-top', (settings[pref + 'inputs'].spacing + settings[pref + 'inputs'].checkboxes_margin) + 'px');
                    } else {
                        str += getGeneralStyle('margin-top', settings[pref + 'inputs'].spacing + 'px');
                    }

                    str += '} ';


                    //Custom Field - Checkbox Input
                    str += '#' + pref + 'form_input_custom' + n + ' {';
                    str += getFloatLeftStyle();
                    str += getGeneralStyle('margin', '0');
                    str += '} ';


                    //Custom Field - Checkbox Text
                    str += '#' + pref + 'form_input_custom' + n + '_checkbox_text {';
                    str += getGeneralStyle('margin', '0');
                    str += getLineHeightStyle(settings[propName].checkbox.font.size);
                    str += getFontStyle(settings[propName].checkbox.font);
                    str += '} ';

                    previousCbPropName = propName;
                } else if (settings.hasOwnProperty(propName) && settings[propName].display && (!settings[propName].hasOwnProperty('field_type') || settings[propName]['field_type'] !== 'hidden')) {
                    checkboxSequentialFloatMatchCtr = 0;
                    logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - ' + propName + ' checkbox not found.');
                }
            }
        }


        if (boxapi.contains(pref, '_')) {
            pref = pref.split('_')[0];
        }

        if (pref === '') {
            $('head').append('<style id="element_styles" type="text/css">' + str + '</style>');
        } else {
            $('head').append('<style id="element_styles_' + pref + '" type="text/css">' + str + '</style>');
        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'buildStyles');
    }
}

function isNullOrWhitespace(input) {
    if (typeof input === 'undefined' || input == null) return true;
    return input.replace(/\s/g, '').length < 1;
}

function buildFormName(pref, form_ele) {
    if (pref !== '' && pref.indexOf('_') === -1) {
        pref += '_';
    }


    if (settings.hasOwnProperty(pref + 'name') && settings[pref + 'name'].display) {
        var style = '';
        if (settings[pref + 'name'].hidden === 'hidden') {
            style = 'display: none;';
        }

        form_ele.append("<div id='" + pref + "form_label_name' class='" + pref + "form_labels' style='" + style + "'>" + settings[pref + 'name'].label + "<span id='" + pref + "form_label_name_required' class='" + pref + "form_labels_required'></span></div>");

        if (settings[pref + 'name'].require && settings[pref + 'labels'].required.text.length > 0) {
            $('#' + pref + 'form_label_name_required').text(settings[pref + 'labels'].required.text);
        }

        if (settings[pref + 'labels'].position == 'left') {
            $('#' + pref + 'form_label_name').addClass(pref + 'form_labels_left');
        } else if (settings[pref + 'labels'].position == 'above') {
            $('#' + pref + 'form_label_name').addClass(pref + 'form_labels_above');
            if (isNullOrWhitespace(settings[pref + 'name'].label)) {
                $('#' + pref + 'form_label_name').css({
                    'height': '0px'
                });
            }
        } else {
            $('#' + pref + 'form_label_name').addClass(pref + 'form_labels_hide');
        }

        if (settings[pref + 'name'].mode == 'full') {
            //Full Name
            if (settings[pref + 'name'].hidden !== 'hidden') {
                form_ele.append("<label id='" + pref + "form_input_name_ada_label' for='" + pref + "form_input_full_name' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[pref + 'name'].label + "</label>");
            }

            form_ele.append("<div id='" + pref + "form_input_full_name_wrapper' class='" + pref + "form_inputs_wrapper' style='" + style + "'><input type='text' id='" + pref + "form_input_full_name' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_full_name_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_name_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");

            //Default Text
            if (settings[pref + 'name'].default_full) {
                $('#' + pref + 'form_input_full_name').val(settings[pref + 'name'].default_full);
            }

            //Placeholder Text
            if (settings[pref + 'name'].placeholder_full) {
                $('#' + pref + 'form_input_full_name').attr('placeholder', settings[pref + 'name'].placeholder_full);
            }

            //Help Text
            if (settings[pref + 'name'].display_help) {
                $('#' + pref + 'form_input_full_name_help').text(settings[pref + 'name'].help_full);
            } else {
                $('#' + pref + 'form_input_full_name_help').hide();
            }

            //Hover State
            if (!IS_MOBILE) {
                $('#' + pref + 'form_input_full_name').hover(function() {
                    $(this).addClass(pref + "form_inputs_hover");
                }, function() {
                    $(this).removeClass(pref + "form_inputs_hover");
                });
            }

            //Focus State
            $('#' + pref + 'form_input_full_name').focus(function() {
                $(this).addClass(pref + "form_inputs_focus");
            }).blur(function() {
                $(this).removeClass(pref + "form_inputs_focus");
            });

            //Hit Enter Key
            $('#' + pref + 'form_input_full_name').keypress(function(e) {
                if (e.which == 13) {
                    e.preventDefault();
                    processSubmit(pref, false, false, true);
                }
            });

        } else if (settings[pref + 'name'].mode == 'first') {
            //First Name
            if (settings[pref + 'name'].hidden !== 'hidden') {
                form_ele.append("<label id='" + pref + "form_input_name_ada_label' for='" + pref + "form_input_first_name' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[pref + 'name'].label + "</label>");
            }

            form_ele.append("<div id='" + pref + "form_input_first_name_wrapper' class='" + pref + "form_inputs_wrapper' style='" + style + "'><input type='text' id='" + pref + "form_input_first_name' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_first_name_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_name_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");

            //Default Text
            if (settings[pref + 'name'].default_first) {
                $('#' + pref + 'form_input_first_name').val(settings[pref + 'name'].default_first);
            }

            //Placeholder Text
            if (settings[pref + 'name'].placeholder_first) {
                $('#' + pref + 'form_input_first_name').attr('placeholder', settings[pref + 'name'].placeholder_first);
            }

            //Help Text
            if (settings[pref + 'name'].display_help) {
                $('#' + pref + 'form_input_first_name_help').text(settings[pref + 'name'].help_first);
            } else {
                $('#' + pref + 'form_input_first_name_help').hide();
            }

            //Hover State
            if (!IS_MOBILE) {
                $('#' + pref + 'form_input_first_name').hover(function() {
                    $(this).addClass(pref + "form_inputs_hover");
                }, function() {
                    $(this).removeClass(pref + "form_inputs_hover");
                });
            }

            //Focus State
            $('#' + pref + 'form_input_first_name').focus(function() {
                $(this).addClass(pref + "form_inputs_focus");
            }).blur(function() {
                $(this).removeClass(pref + "form_inputs_focus");
            });

            //Hit Enter Key
            $('#' + pref + 'form_input_first_name').keypress(function(e) {
                if (e.which == 13) {
                    e.preventDefault();
                    processSubmit(pref, false, false, true);
                }
            });
        } else if (settings[pref + 'name'].mode == 'both') {
            if (settings[pref + 'name'].hidden !== 'hidden') {
                form_ele.append("<label id='" + pref + "form_input_name_ada_label' for='" + pref + "form_input_first_name' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[pref + 'name'].label + "</label>");
            }

            if (settings[pref + 'name'].arrange == 'horizontal') {
                //Arrange first/last name horizontal

                //First and Last Name
                form_ele.append("<div id='" + pref + "form_input_first_and_last_name_wrapper' class='" + pref + "form_inputs_wrapper' style='" + style + "'>  <div id='" + pref + "form_input_first_name_wrapper'><input type='text' id='" + pref + "form_input_first_name' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_first_name_help' class='" + pref + "form_inputs_help'></div></div>  <div id='" + pref + "form_input_last_name_wrapper'><input type='text' id='" + pref + "form_input_last_name' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_last_name_help' class='" + pref + "form_inputs_help'></div></div>  <div id='" + pref + "form_input_name_error_text' class='" + pref + "form_inputs_error_text'></div>  </div>  <div style='float: none; clear: both;'></div>");

                //Wrapper - Last Name
                $('#' + pref + 'form_input_last_name_wrapper').css({
                    "float": 'right',
                    "width": '48%'
                });

                //Wrapper - First Name
                $('#' + pref + 'form_input_first_name_wrapper').css({
                    "float": 'left',
                    "width": '48%'
                });
            } else {
                //Arrange first/last name vertical

                //First and Last Name
                form_ele.append("<div id='" + pref + "form_input_first_and_last_name_wrapper' class='" + pref + "form_inputs_wrapper' style='" + style + "'>  <div id='" + pref + "form_input_first_name_wrapper'><input type='text' id='" + pref + "form_input_first_name' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_first_name_help' class='" + pref + "form_inputs_help'></div></div>  <div id='" + pref + "form_input_last_name_wrapper'><input type='text' id='" + pref + "form_input_last_name' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_last_name_help' class='" + pref + "form_inputs_help'></div></div>  <div id='" + pref + "form_input_name_error_text' class='" + pref + "form_inputs_error_text'></div>  </div>  <div style='float: none; clear: both;'></div>");

                //Wrapper - Last Name
                $('#' + pref + 'form_input_last_name_wrapper').css({
                    "float": 'right',
                    "width": '100%',
                    "margin-top": settings[pref + 'inputs'].spacing + 'px'
                });

                //Wrapper - First Name
                $('#' + pref + 'form_input_first_name_wrapper').css({
                    "float": 'right',
                    "width": '100%'
                });
            }

            //Default Text - Last Name
            if (settings[pref + 'name'].default_last) {
                $('#' + pref + 'form_input_last_name').val(settings[pref + 'name'].default_last);
            }

            //Default Text - First Name
            if (settings[pref + 'name'].default_first) {
                $('#' + pref + 'form_input_first_name').val(settings[pref + 'name'].default_first);
            }

            //Placeholder Text - Last Name
            if (settings[pref + 'name'].placeholder_last) {
                $('#' + pref + 'form_input_last_name').attr('placeholder', settings[pref + 'name'].placeholder_last);
            }

            //Placeholder Text - First Name
            if (settings[pref + 'name'].placeholder_first) {
                $('#' + pref + 'form_input_first_name').attr('placeholder', settings[pref + 'name'].placeholder_first);
            }

            //Help Text - Last Name
            if (settings[pref + 'name'].display_help) {
                $('#' + pref + 'form_input_last_name_help').text(settings[pref + 'name'].help_last);
            } else {
                $('#' + pref + 'form_input_last_name_help').hide();
            }

            //Help Text - First Name
            if (settings[pref + 'name'].display_help) {
                $('#' + pref + 'form_input_first_name_help').text(settings[pref + 'name'].help_first);
            } else {
                $('#' + pref + 'form_input_first_name_help').hide();
            }

            //Hover State - Last Name
            if (!IS_MOBILE) {
                $('#' + pref + 'form_input_last_name').hover(function() {
                    $(this).addClass(pref + "form_inputs_hover");
                }, function() {
                    $(this).removeClass(pref + "form_inputs_hover");
                });
            }

            //Focus State - Last Name
            $('#' + pref + 'form_input_last_name').focus(function() {
                $(this).addClass(pref + "form_inputs_focus");
            }).blur(function() {
                $(this).removeClass(pref + "form_inputs_focus");
            });

            //Hover State - First Name
            if (!IS_MOBILE) {
                $('#' + pref + 'form_input_first_name').hover(function() {
                    $(this).addClass(pref + "form_inputs_hover");
                }, function() {
                    $(this).removeClass(pref + "form_inputs_hover");
                });
            }

            //Focus State - First Name
            $('#' + pref + 'form_input_first_name').focus(function() {
                $(this).addClass(pref + "form_inputs_focus");
            }).blur(function() {
                $(this).removeClass(pref + "form_inputs_focus");
            });

            //Hit Enter Key
            $('#' + pref + 'form_input_last_name').keypress(function(e) {
                if (e.which == 13) {
                    e.preventDefault();
                    processSubmit(pref, false, false, true);
                }
            });

            $('#' + pref + 'form_input_first_name').keypress(function(e) {
                if (e.which == 13) {
                    e.preventDefault();
                    processSubmit(pref, false, false, true);
                }
            });
        }

        if (settings[pref + 'name'].hasOwnProperty('metadata_kvps')) {
            for (var k = 0; k < settings[pref + 'name'].metadata_kvps.length; k++) {
                if (settings[pref + 'name'].metadata_kvps[k].k && settings[pref + 'name'].metadata_kvps[k].v) {
                    if ($('#' + pref + 'form_input_full_name').length)
                        trySetAttribute(pref + "form_input_full_name", settings[pref + 'name'].metadata_kvps[k]);
                    if ($('#' + pref + 'form_input_first_name').length)
                        trySetAttribute(pref + "form_input_first_name", settings[pref + 'name'].metadata_kvps[k]);
                    if ($('#' + pref + 'form_input_last_name').length)
                        trySetAttribute(pref + "form_input_last_name", settings[pref + 'name'].metadata_kvps[k]);
                }
            }
        }
    }
}


function buildFormEmail(pref, form_ele) {
    if (pref !== '') {
        pref += '_';
    }

    if (settings.hasOwnProperty(pref + 'email') && settings[pref + 'email'].display) {
        var style = '';
        if (settings[pref + 'email'].hidden === 'hidden') {
            style = 'display: none;';
        }

        //Email
        if (settings[pref + 'email'].hidden !== 'hidden') {
            form_ele.append("<label id='" + pref + "form_input_email_ada_label' for='" + pref + "form_input_email' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[pref + 'email'].label + "</label>");
        }

        form_ele.append("<div id='" + pref + "form_label_email' class='" + pref + "form_labels " + pref + "form_spacing' style='" + style + "'>" + settings[pref + 'email'].label + "<span id='" + pref + "form_label_email_required' class='" + pref + "form_labels_required'></span></div>");
        form_ele.append("<div id='" + pref + "form_input_email_wrapper' class='" + pref + "form_inputs_wrapper' style='" + style + "'><input type='text' id='" + pref + "form_input_email' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_email_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_email_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");

        if (settings[pref + 'email'].require && settings[pref + 'labels'].required.text.length > 0) {
            $('#' + pref + 'form_label_email_required').text(settings[pref + 'labels'].required.text);
        }

        if (settings[pref + 'labels'].position == 'left') {
            $('#' + pref + 'form_label_email').addClass(pref + 'form_labels_left');
            $('#' + pref + 'form_input_email_wrapper').addClass(pref + 'form_spacing');
        } else if (settings[pref + 'labels'].position == 'above') {
            $('#' + pref + 'form_label_email').addClass(pref + 'form_labels_above');
            if (isNullOrWhitespace(settings[pref + 'email'].label)) {
                $('#' + pref + 'form_label_email').css({
                    'height': '0px'
                });
            }
        } else {
            $('#' + pref + 'form_label_email').addClass(pref + 'form_labels_hide');
            $('#' + pref + 'form_input_email_wrapper').addClass(pref + 'form_spacing');
        }

        //Default Text
        if (settings[pref + 'email']['default']) {
            $('#' + pref + 'form_input_email').val(settings[pref + 'email']['default']);
        }

        //Placeholder Text
        if (settings[pref + 'email'].placeholder) {
            $('#' + pref + 'form_input_email').attr('placeholder', settings[pref + 'email'].placeholder);
        }

        //Help Text
        if (settings[pref + 'email'].display_help) {
            $('#' + pref + 'form_input_email_help').text(settings[pref + 'email'].help);
        } else {
            $('#' + pref + 'form_input_email_help').hide();
        }

        //Hover State
        if (!IS_MOBILE) {
            $('#' + pref + 'form_input_email').hover(function() {
                $(this).addClass(pref + "form_inputs_hover");
            }, function() {
                $(this).removeClass(pref + "form_inputs_hover");
            });
        }

        //Focus State
        $('#' + pref + 'form_input_email').focus(function() {
            $(this).addClass(pref + "form_inputs_focus");
        }).blur(function() {
            $(this).removeClass(pref + "form_inputs_focus");
        });

        //Hit Enter Key
        $('#' + pref + 'form_input_email').keypress(function(e) {
            if (e.which == 13) {
                e.preventDefault();
                processSubmit(pref, false, false, true);
            }
        });

        //Metadata
        if ($('#' + pref + 'form_input_email').length && settings[pref + 'email'].hasOwnProperty('metadata_kvps')) {
            for (var k = 0; k < settings[pref + 'email'].metadata_kvps.length; k++) {
                if (settings[pref + 'email'].metadata_kvps[k].k && settings[pref + 'email'].metadata_kvps[k].v) {
                    trySetAttribute(pref + 'form_input_email', settings[pref + 'email'].metadata_kvps[k]);
                }
            }
        }
    }
}


function buildFormPhone(pref, form_ele) {
    if (pref !== '') {
        pref += '_';
    }

    if (settings.hasOwnProperty(pref + 'phone') && settings[pref + 'phone'].display) {
        var style = '';
        if (settings[pref + 'phone'].hidden === 'hidden') {
            style = 'display: none;';
        }

        //Phone
        if (settings[pref + 'phone'].hidden !== 'hidden') {
            form_ele.append("<label id='" + pref + "form_input_phone_ada_label' for='" + pref + "form_input_phone' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[pref + 'phone'].label + "</label>");
        }

        form_ele.append("<div id='" + pref + "form_label_phone' class='" + pref + "form_labels " + pref + "form_spacing' style='" + style + "'>" + settings[pref + 'phone'].label + "<span id='" + pref + "form_label_phone_required' class='" + pref + "form_labels_required'></span></div>");
        form_ele.append("<div id='" + pref + "form_input_phone_wrapper' class='" + pref + "form_inputs_wrapper' style='" + style + "'><input type='text' id='" + pref + "form_input_phone' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_phone_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_phone_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");

        if (settings[pref + 'phone'].require && settings[pref + 'labels'].required.text.length > 0) {
            $('#' + pref + 'form_label_phone_required').text(settings[pref + 'labels'].required.text);
        }

        if (settings[pref + 'labels'].position == 'left') {
            $('#' + pref + 'form_label_phone').addClass(pref + 'form_labels_left');
            $('#' + pref + 'form_input_phone_wrapper').addClass(pref + 'form_spacing');
        } else if (settings[pref + 'labels'].position == 'above') {
            $('#' + pref + 'form_label_phone').addClass(pref + 'form_labels_above');
            if (isNullOrWhitespace(settings[pref + 'phone'].label)) {
                $('#' + pref + 'form_label_phone').css({
                    'height': '0px'
                });
            }
        } else {
            $('#' + pref + 'form_label_phone').addClass(pref + 'form_labels_hide');
            $('#' + pref + 'form_input_phone_wrapper').addClass(pref + 'form_spacing');
        }

        //Default Text
        if (settings[pref + 'phone']['default']) {
            $('#' + pref + 'form_input_phone').val(settings[pref + 'phone']['default']);
        }

        //Placeholder Text
        if (settings[pref + 'phone'].placeholder) {
            $('#' + pref + 'form_input_phone').attr('placeholder', settings[pref + 'phone'].placeholder);
        }

        //Help Text
        if (settings[pref + 'phone'].display_help) {
            $('#' + pref + 'form_input_phone_help').text(settings[pref + 'phone'].help);
        } else {
            $('#' + pref + 'form_input_phone_help').hide();
        }

        //Hover State
        if (!IS_MOBILE) {
            $('#' + pref + 'form_input_phone').hover(function() {
                $(this).addClass(pref + "form_inputs_hover");
            }, function() {
                $(this).removeClass(pref + "form_inputs_hover");
            });
        }

        //Focus State
        $('#' + pref + 'form_input_phone').focus(function() {
            $(this).addClass(pref + "form_inputs_focus");
        }).blur(function() {
            $(this).removeClass(pref + "form_inputs_focus");
        });

        //Hit Enter Key
        $('#' + pref + 'form_input_phone').keypress(function(e) {
            if (e.which == 13) {
                e.preventDefault();
                processSubmit(pref, false, false, true);
            }
        });

        //Masked Input
        //$("#form_input_phone").mask("(999) 999-9999? x99999", { placeholder: " " });

        //Metadata
        if ($('#' + pref + 'form_input_phone').length && settings[pref + 'phone'].hasOwnProperty('metadata_kvps')) {
            for (var k = 0; k < settings[pref + 'phone'].metadata_kvps.length; k++) {
                if (settings[pref + 'phone'].metadata_kvps[k].k && settings[pref + 'phone'].metadata_kvps[k].v) {
                    trySetAttribute(pref + 'form_input_phone', settings[pref + 'phone'].metadata_kvps[k]);
                }
            }
        }
    }
}


function buildFormOptIn(pref, form_ele) {
    if (pref !== '') {
        pref += '_';
    }

    if (settings.hasOwnProperty(pref + 'opt_in') && settings[pref + 'opt_in'].display) {
        var style = '';
        if (settings[pref + 'opt_in'].hidden === 'hidden') {
            style = 'display: none;';
        }

        form_ele.append("<div id='" + pref + "form_input_opt_in_wrapper' style='" + style + "'><input type='checkbox' id='" + pref + "form_input_opt_in' /><p id='" + pref + "form_input_opt_in_text'>" + settings[pref + 'opt_in'].text + "</p> <div style='float: none; clear: both;'></div> <div id='" + pref + "form_input_opt_in_error_text' class='" + pref + "form_inputs_error_text'></div></div>");

        if (settings[pref + 'opt_in'].font.size <= 10) {
            $('#' + pref + 'form_input_opt_in_text').css({
                "margin-top": "2px",
                "margin-left": "20px"
            });
        } else if (settings[pref + 'opt_in'].font.size > 10 && settings[pref + 'opt_in'].font.size < 14) {
            $('#' + pref + 'form_input_opt_in_text').css({
                "margin-top": "1px",
                "margin-left": "20px"
            });
        } else if (settings[pref + 'opt_in'].font.size >= 14) {
            $('#' + pref + 'form_input_opt_in_text').css({
                "margin-top": "-1px",
                "margin-left": "20px"
            });
        }

        if (settings[pref + 'opt_in'].hasOwnProperty('default') && settings[pref + 'opt_in'].default === 'on') {
            $("#" + pref + "form_input_opt_in").prop('checked', true).attr('checked', 'checked');
        }

        $('#' + pref + "form_input_opt_in").keypress(function(e) {
            if ((e.keyCode ? e.keyCode : e.which) == 13) {
                $(this).trigger('click');
            }
        });

        $('#' + pref + "form_input_opt_in").change(function() {
            if (this.checked) {
                $(this).attr('checked', 'checked');
            } else {
                $(this).removeAttr('checked');
            }
        });

        //Metadata
        if ($('#' + pref + 'form_input_opt_in').length && settings[pref + 'opt_in'].hasOwnProperty('metadata_kvps')) {
            for (var k = 0; k < settings[pref + 'opt_in'].metadata_kvps.length; k++) {
                if (settings[pref + 'opt_in'].metadata_kvps[k].k && settings[pref + 'opt_in'].metadata_kvps[k].v) {
                    trySetAttribute(pref + 'form_input_opt_in', settings[pref + 'opt_in'].metadata_kvps[k]);
                }
            }
        }
    }
}


function buildFormCustomN(pref, propName, form_ele) {
    if (pref && pref !== '' && pref.indexOf('_') === -1) {
        pref += '_';
    }

    var customN = propName;
    if (propName.indexOf('_') > 0 && propName.indexOf('custom') > 0) {
        customN = propName.split('_')[1];
    }

    //buildFormCustomN('ep4', 'ep4_custom' + i, ep4_form);
    //buildFormCustomN('ep1', 'ep1_custom1', ep1_form);
    //pref = ep1
    //propName = ep1_custom7

    var n = propName.split('custom')[1];

    if (settings.hasOwnProperty(propName) && settings[propName].display) {
        if (settings[propName].hasOwnProperty('align') && settings[propName].align == 'h' && settings[propName].hasOwnProperty('field_type') && settings[propName].field_type !== 'radio' && settings[propName].field_type !== 'checkbox' && settings[propName].field_type !== 'hidden') {
            form_ele.append("<div id='" + pref + "form_float_" + customN + "' style=''></div>");
            form_ele = $('#' + pref + "form_float_" + customN);

            var consecutiveCnt = 1;
            for (var w = n - 1; w > 0; w--) {
                if (settings.hasOwnProperty(pref + 'custom' + w) && settings[pref + 'custom' + w].display && settings[pref + 'custom' + w].hasOwnProperty('align') && settings[pref + 'custom' + w].align == 'h' && settings[pref + 'custom' + w].hasOwnProperty('field_type') && settings[pref + 'custom' + w].field_type !== 'radio' && settings[pref + 'custom' + w].field_type !== 'checkbox' && settings[pref + 'custom' + w].field_type !== 'hidden') {
                    consecutiveCnt++;
                } else {
                    break;
                }
            }

            if (consecutiveCnt > 1) {
                var fieldWidth = (settings[pref + 'form'].width / consecutiveCnt) - (settings[pref + 'inputs'].spacing * (consecutiveCnt - 1) / consecutiveCnt);

                for (var w = n; w > (n - consecutiveCnt); w--) {
                    $('#' + pref + "form_float_custom" + w).css({
                        'width': fieldWidth + 'px',
                        'float': 'left'
                    });
                    if (w > n - consecutiveCnt + 1) {
                        $('#' + pref + "form_float_custom" + w).css({
                            'margin-left': settings[pref + 'inputs'].spacing + 'px'
                        });

                        if ($('#' + pref + "form_float_custom" + w + "_clear").length) {
                            $('#' + pref + "form_float_custom" + w + "_clear").remove();
                        }
                    }
                }

                form_ele.after("<div id='" + pref + "form_float_" + customN + "_clear' style='float:none;clear:both;'></div>");
            }

            //console.log('buildFormCustomN_float: ' + propName + ', ' + settings[propName].field_type);
        }

        //if (settings[propName].hasOwnProperty('field_type') && settings[propName].field_type !== 'checkbox' && settings[propName].field_type !== 'radio' && settings[propName].field_type !== 'hidden') {
        //    form_ele.append("<label id='" + pref + "form_input_" + customN + "_ada_label' for='" + pref + "form_input_" + customN + "' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[propName].label + "</label>");
        //}

        if (settings[propName].hasOwnProperty('field_type') && settings[propName].field_type !== 'hidden' && settings[propName].field_type !== 'checkbox' && settings[propName].field_type !== 'radio' && !isNullOrWhitespace(settings[propName].label)) {
            form_ele.append("<label id='" + pref + "form_input_" + customN + "_ada_label' for='" + pref + "form_input_" + customN + "' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[propName].label + "</label>");
        }

        if (!settings[propName].hasOwnProperty('field_type') || settings[propName].field_type == 'textbox') {
            form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
            form_ele.append("<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'><input type='text' id='" + pref + "form_input_" + customN + "' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");

            if (settings[propName].placeholder) {
                $('#' + pref + 'form_input_' + customN).attr('placeholder', settings[propName].placeholder);
            }

            if (settings[propName]['default']) {
                $('#' + pref + 'form_input_' + customN).val(settings[propName]['default']);
            }

        } else if (settings[propName].field_type == 'textarea') {
            form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
            form_ele.append("<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'><textarea id='" + pref + "form_input_" + customN + "' class='" + pref + "form_inputs' style='height: " + settings[propName].textarea_height + "px; margin-bottom: 0px;'></textarea><div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help' style='margin-top: 0px;'></div><div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");

            if (settings[propName].placeholder) {
                $('#' + pref + 'form_input_' + customN).attr('placeholder', settings[propName].placeholder);
            }

            if (settings[propName]['default']) {
                $('#' + pref + 'form_input_' + customN).val(settings[propName]['default']);
            }

        } else if (settings[propName].field_type == 'datepicker' && settings[propName].datepicker) {
            form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
            form_ele.append("<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'><input type='text' id='" + pref + "form_input_" + customN + "' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");

            if (!isNullOrWhiteSpace(settings[propName]['placeholder'])) {
                $('#' + pref + 'form_input_' + customN).attr('placeholder', settings[propName].placeholder);
            }

            initDatepicker(pref, propName, customN);

        } else if (settings[propName].field_type == 'datedrop' && settings[propName].datedrop) {
            form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
            //form_ele.append("<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'><input type='text' id='" + pref + "form_input_" + customN + "' class='" + pref + "form_inputs' /><div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help'></div></div><div style='float: none; clear: both;'></div>");

            if (settings[propName].datedrop.display_format == "MM-dd-yyyy" || settings[propName].datedrop.display_format == "") {
                var append_html = "<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'>"; //1

                //MM
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_mm_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_mm' class='" + pref + "form_inputs'><option value='MM'>MM</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_mm_help' class='" + pref + "form_inputs_help'></div></div>";
                //DD
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_dd_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_dd' class='" + pref + "form_inputs'><option value='dd'>DD</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_dd_help' class='" + pref + "form_inputs_help'></div></div>";
                //YYYY
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_yyyy_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_yyyy' class='" + pref + "form_inputs'><option value='yyyy'>YYYY</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_yyyy_help' class='" + pref + "form_inputs_help'></div></div>";

                append_html += "<div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div>";
                append_html += "</div>"; //1
                append_html += "<div style='float: none; clear: both;'></div>";

                form_ele.append(append_html);
                //form_ele.append("<div id='" + pref + "form_input_" + propName + "_wrapper' class='" + pref + "form_inputs_wrapper'>  <div id='" + pref + "form_input_" + propName + "_datedrop_mm_wrapper'><select id='" + pref + "form_input_" + propName + "_datedrop_mm' class='" + pref + "form_inputs'></select><div id='" + pref + "form_input_" + propName + "_help' class='" + pref + "form_inputs_help'></div></div></div><div style='float: none; clear: both;'></div>");

                //wrapper ==> #pref + "form_input_" + propName + "_datedrop_mm_wrapper"
                //select ==> #pref + "form_input_" + propName + "_datedrop_mm"
                //help ==> #pref + "form_input_" + propName + "_datedrop_mm_help"

                //Wrapper - YYYY
                $('#' + pref + "form_input_" + customN + "_datedrop_yyyy_wrapper").css({
                    "float": 'right',
                    "width": '38%'
                });

                //Wrapper - MM
                $('#' + pref + "form_input_" + customN + "_datedrop_mm_wrapper").css({
                    "float": 'left',
                    "width": '28%',
                    "margin-right": "3%"
                });

                //Wrapper - DD
                $('#' + pref + "form_input_" + customN + "_datedrop_dd_wrapper").css({
                    "float": 'left',
                    "width": '28%'
                });
            } else if (settings[propName].datedrop.display_format == "dd-MM-yyyy") {
                var append_html = "<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'>"; //1

                //DD
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_dd_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_dd' class='" + pref + "form_inputs'><option value='dd'>DD</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_dd_help' class='" + pref + "form_inputs_help'></div></div>";
                //MM
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_mm_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_mm' class='" + pref + "form_inputs'><option value='MM'>MM</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_mm_help' class='" + pref + "form_inputs_help'></div></div>";
                //YYYY
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_yyyy_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_yyyy' class='" + pref + "form_inputs'><option value='yyyy'>YYYY</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_yyyy_help' class='" + pref + "form_inputs_help'></div></div>";

                append_html += "<div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div>";
                append_html += "</div>"; //1
                append_html += "<div style='float: none; clear: both;'></div>";

                form_ele.append(append_html);
                //form_ele.append("<div id='" + pref + "form_input_" + propName + "_wrapper' class='" + pref + "form_inputs_wrapper'>  <div id='" + pref + "form_input_" + propName + "_datedrop_mm_wrapper'><select id='" + pref + "form_input_" + propName + "_datedrop_mm' class='" + pref + "form_inputs'></select><div id='" + pref + "form_input_" + propName + "_help' class='" + pref + "form_inputs_help'></div></div>                    </div>  <div style='float: none; clear: both;'></div>");

                //wrapper ==> #pref + "form_input_" + propName + "_datedrop_mm_wrapper"
                //select ==> #pref + "form_input_" + propName + "_datedrop_mm"
                //help ==> #pref + "form_input_" + propName + "_datedrop_mm_help"

                //Wrapper - YYYY
                $('#' + pref + "form_input_" + customN + "_datedrop_yyyy_wrapper").css({
                    "float": 'right',
                    "width": '38%'
                });

                //Wrapper - DD
                $('#' + pref + "form_input_" + customN + "_datedrop_dd_wrapper").css({
                    "float": 'left',
                    "width": '28%',
                    "margin-right": "3%"
                });

                //Wrapper - MM
                $('#' + pref + "form_input_" + customN + "_datedrop_mm_wrapper").css({
                    "float": 'left',
                    "width": '28%'
                });
            } else if (settings[propName].datedrop.display_format == "yyyy-MM-dd") {
                var append_html = "<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'>"; //1

                //YYYY
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_yyyy_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_yyyy' class='" + pref + "form_inputs'><option value='yyyy'>YYYY</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_yyyy_help' class='" + pref + "form_inputs_help'></div></div>";
                //DD
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_dd_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_dd' class='" + pref + "form_inputs'><option value='dd'>DD</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_dd_help' class='" + pref + "form_inputs_help'></div></div>";
                //MM
                append_html += "<div id='" + pref + "form_input_" + customN + "_datedrop_mm_wrapper'><select id='" + pref + "form_input_" + customN + "_datedrop_mm' class='" + pref + "form_inputs'><option value='MM'>MM</option></select><div id='" + pref + "form_input_" + customN + "_datedrop_mm_help' class='" + pref + "form_inputs_help'></div></div>";

                append_html += "<div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div>";
                append_html += "</div>"; //1
                append_html += "<div style='float: none; clear: both;'></div>";

                form_ele.append(append_html);
                //form_ele.append("<div id='" + pref + "form_input_" + propName + "_wrapper' class='" + pref + "form_inputs_wrapper'>  <div id='" + pref + "form_input_" + propName + "_datedrop_mm_wrapper'><select id='" + pref + "form_input_" + propName + "_datedrop_mm' class='" + pref + "form_inputs'></select><div id='" + pref + "form_input_" + propName + "_help' class='" + pref + "form_inputs_help'></div></div>                    </div>  <div style='float: none; clear: both;'></div>");

                //wrapper ==> #pref + "form_input_" + propName + "_datedrop_mm_wrapper"
                //select ==> #pref + "form_input_" + propName + "_datedrop_mm"
                //help ==> #pref + "form_input_" + propName + "_datedrop_mm_help"

                //Wrapper - YYYY
                $('#' + pref + "form_input_" + customN + "_datedrop_yyyy_wrapper").css({
                    "float": 'left',
                    "width": '38%'
                });

                //Wrapper - DD
                $('#' + pref + "form_input_" + customN + "_datedrop_dd_wrapper").css({
                    "float": 'right',
                    "width": '28%'
                });

                //Wrapper - MM
                $('#' + pref + "form_input_" + customN + "_datedrop_mm_wrapper").css({
                    "float": 'right',
                    "width": '28%',
                    "margin-right": "3%"
                });
            }

            var dropdown_yyyy = $('#' + pref + 'form_input_' + customN + '_datedrop_yyyy');
            var dropdown_mm = $('#' + pref + 'form_input_' + customN + '_datedrop_mm');
            var dropdown_dd = $('#' + pref + 'form_input_' + customN + '_datedrop_dd');
            var min_date = settings[propName].datedrop.min_date;
            var max_date = settings[propName].datedrop.max_date;
            var default_date = settings[propName].datedrop.default_date;
            var foundSelected = false;

            var yyyy_min = 1900;
            if (min_date && min_date.split('/').length == 3 && min_date.split('/')[2].trim().length == 4) {
                yyyy_min = parseInt(min_date.split('/')[2].trim());
            }

            var date_curr = new Date();
            var yyyy_max = date_curr.getFullYear();
            if (max_date && max_date.split('/').length == 3 && max_date.split('/')[2].trim().length == 4) {
                yyyy_max = parseInt(max_date.split('/')[2].trim());
            }

            var yyyy_default = "";
            if (default_date && default_date.split('/').length == 3 && default_date.split('/')[2].trim().length == 4) {
                yyyy_default = parseInt(default_date.split('/')[2].trim());
            }

            var mm_default = "";
            if (default_date && default_date.split('/').length == 3 && default_date.split('/')[0].trim().length == 2) {
                mm_default = parseInt(default_date.split('/')[0].trim());
            }

            var dd_default = "";
            if (default_date && default_date.split('/').length == 3 && default_date.split('/')[1].trim().length == 2) {
                dd_default = parseInt(default_date.split('/')[1].trim());
            }

            for (var i = yyyy_min; i <= yyyy_max; i++) {
                if (!foundSelected && i === yyyy_default) {
                    dropdown_yyyy.append("<option selected value='" + i + "'>" + i + "</option>");
                    foundSelected = true;
                } else {
                    dropdown_yyyy.append("<option value='" + i + "'>" + i + "</option>");
                }
            }

            foundSelected = false;
            var mm_disp = "";
            for (var i = 1; i <= 12; i++) {
                if (i < 10) mm_disp = "0" + i;
                else mm_disp = i;
                if (!foundSelected && i === mm_default) {
                    dropdown_mm.append("<option selected value='" + i + "'>" + mm_disp + "</option>");
                    foundSelected = true;
                } else {
                    dropdown_mm.append("<option value='" + i + "'>" + mm_disp + "</option>");
                }
            }

            foundSelected = false;
            var dd_disp = "";
            for (var i = 1; i <= 31; i++) {
                if (i < 10) dd_disp = "0" + i;
                else dd_disp = i;
                if (!foundSelected && i === dd_default) {
                    dropdown_dd.append("<option selected value='" + i + "'>" + dd_disp + "</option>");
                    foundSelected = true;
                } else {
                    dropdown_dd.append("<option value='" + i + "'>" + dd_disp + "</option>");
                }
            }

        } else if (settings[propName].field_type == 'dropdown') {
            form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
            form_ele.append("<div id='" + pref + "form_input_" + customN + "_wrapper' class='" + pref + "form_inputs_wrapper'><select id='" + pref + "form_input_" + customN + "' class='" + pref + "form_inputs'></select><div id='" + pref + "form_input_" + customN + "_help' class='" + pref + "form_inputs_help'></div><div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div></div><div style='float: none; clear: both;'></div>");
            if (settings[propName].dropdown_kvps.length > 0) {
                var dropdown = $('#' + pref + 'form_input_' + customN);
                var kvps = settings[propName].dropdown_kvps;
                var foundSelected = false;
                for (var i = 0; i < kvps.length; i++) {
                    if (!foundSelected && settings[propName]['default'] && (kvps[i].k == settings[propName]['default'] || kvps[i].v == settings[propName]['default'])) {
                        dropdown.append("<option selected value='" + kvps[i].k + "'>" + kvps[i].v + "</option>");
                    } else {
                        dropdown.append("<option value='" + kvps[i].k + "'>" + kvps[i].v + "</option>");
                    }
                }
            }

        } else if (settings[propName].field_type == 'radio') {
            if (settings[propName].hasOwnProperty('hide_label') && settings[propName].hide_label === 'show') {
                form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
            }

            var radioWrapperId = pref + "form_input_" + customN + "_radio_wrapper";
            form_ele.append("<div id='" + radioWrapperId + "'></div>");

            if (settings[propName].radio.kvps.length > 0) {
                var radioGroup = $('#' + radioWrapperId);
                var kvps = settings[propName].radio.kvps;
                var radioMargin = 10;
                if (typeof settings[propName].radio.margin == 'number') {
                    radioMargin = settings[propName].radio.margin;
                }
                var foundSelected = false;
                for (var i = 0; i < kvps.length; i++) {
                    if (!foundSelected && settings[propName]['radio']['default'] && (kvps[i].k == settings[propName]['radio']['default'] || kvps[i].v == settings[propName]['radio']['default'])) {
                        radioGroup.append("<div class='" + pref + "form_" + customN + "_radio_line_item' style='margin-bottom:" + radioMargin + "px;'><input checked type='radio' class='" + pref + "form_" + customN + "_radio_inputs' id='" + pref + "form_input_" + customN + "_" + i + "' name='" + pref + "form_input_" + customN + "' value='" + kvps[i].k + "'><label class='" + pref + "form_" + customN + "_radio_labels' id='" + pref + "form_label_" + customN + "_" + i + "' for='" + pref + "form_input_" + customN + "_" + i + "'>" + kvps[i].v + "</label></div>");
                    } else {
                        radioGroup.append("<div class='" + pref + "form_" + customN + "_radio_line_item' style='margin-bottom:" + radioMargin + "px;'><input type='radio' class='" + pref + "form_" + customN + "_radio_inputs' id='" + pref + "form_input_" + customN + "_" + i + "' name='" + pref + "form_input_" + customN + "' value='" + kvps[i].k + "'><label class='" + pref + "form_" + customN + "_radio_labels' id='" + pref + "form_label_" + customN + "_" + i + "' for='" + pref + "form_input_" + customN + "_" + i + "'>" + kvps[i].v + "</label></div>");
                    }
                }

                var inputsSpacing = settings[pref + 'inputs'].spacing;
                if (inputsSpacing > radioMargin) {
                    radioMargin = inputsSpacing;
                }

                $('#' + radioWrapperId).css({
                    'margin-top': radioMargin + 'px'
                });

                radioGroup.append("<div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div>");

                if (settings[propName]['radio']['align'] == 'h') {
                    //$('.' + pref + "form_" + customN + "_radio_line_item").css({ 'float': 'left', 'margin-right': radioMargin + 'px' });
                    $('.' + pref + "form_" + customN + "_radio_line_item").css({
                        'float': 'left',
                        'margin-right': '15px'
                    });
                    radioGroup.append("<div style='float:none;clear:both;'></div>");
                }

                if (settings[propName].hasOwnProperty('hide_label') && settings[propName].hide_label === 'show' && settings[pref + 'labels'].position == 'left') {
                    var radioGroupHeight = radioGroup.height();
                    if ($("#" + pref + "form_label_" + customN).height() < radioGroupHeight) {
                        $("#" + pref + "form_label_" + customN).height(radioGroupHeight);
                    }

                    setTimeout(function() {
                        var radioGroupHeight = radioGroup.height();
                        if ($("#" + pref + "form_label_" + customN).height() < radioGroupHeight) {
                            $("#" + pref + "form_label_" + customN).height(radioGroupHeight);
                        }

                        //console.log('radioGroupHeight: ' + "#" + radioWrapperId + ': ' + radioGroupHeight);
                    }, 1000);
                }
                //else if (settings[propName].hasOwnProperty('hide_label') && settings[propName].hide_label === 'show' && settings[pref + 'labels'].position == 'above')
                //{
                //    $("#" + pref + "form_label_" + customN).css('margin-bottom', '5px');
                //}
            }

        } else if (settings[propName].field_type == 'checkbox') {
            form_ele.append("<label id='" + pref + "form_input_" + customN + "_ada_label' for='" + pref + "form_input_" + customN + "' style='border: 0;clip: rect(0 0 0 0);height: 1px;width: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;'>" + settings[propName].checkbox.text + "</label>");

            if (settings[propName].hasOwnProperty('hide_label') && settings[propName].hide_label === 'show') {
                var labelMargin = -1 * settings[pref + 'inputs'].spacing + 5;

                if (settings[pref + 'labels'].position !== 'left')
                    form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing' style='margin-bottom: " + labelMargin + "px;'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
                else
                    form_ele.append("<div id='" + pref + "form_label_" + customN + "' class='" + pref + "form_labels " + pref + "form_spacing'>" + settings[propName].label + "<span id='" + pref + "form_label_" + customN + "_required' class='" + pref + "form_labels_required'></span></div>");
            }

            form_ele.append("<div id='" + pref + "form_input_" + customN + "_checkbox_wrapper'><input type='checkbox' id='" + pref + "form_input_" + customN + "' /><p id='" + pref + "form_input_" + customN + "_checkbox_text'>" + settings[propName].checkbox.text + "</p> <div style='float: none; clear: both;'></div> <div id='" + pref + "form_input_" + customN + "_error_text' class='" + pref + "form_inputs_error_text'></div> </div>");

            //var font_size = settings[propName].checkbox.font.size;
            //var text_margin_left;
            //var text_margin_top;

            if (settings[propName].checkbox.font.size <= 10) {
                $('#' + pref + 'form_input_' + customN + '_checkbox_text').css({
                    "margin-top": "1px",
                    "margin-left": "18px"
                });
            } else if (settings[propName].checkbox.font.size <= 12) {
                $('#' + pref + 'form_input_' + customN + '_checkbox_text').css({
                    "margin-top": "0px",
                    "margin-left": "18px"
                });
            } else if (settings[propName].checkbox.font.size <= 14) {
                $('#' + pref + 'form_input_' + customN + '_checkbox_text').css({
                    "margin-top": "-1px",
                    "margin-left": "18px"
                });
            } else {
                var mt = 14 - settings[propName].checkbox.font.size + "px";
                $('#' + pref + 'form_input_' + customN + '_checkbox_text').css({
                    "margin-top": mt,
                    "margin-left": "18px"
                });
            }

            if (settings[propName].checkbox.hasOwnProperty('default') && settings[propName].checkbox.default === 'on') {
                $("#" + pref + "form_input_" + customN).prop('checked', true).attr('checked', 'checked');
            }

            var nInt = parseInt(n);
            var nextPropName = propName.split('custom')[0] + 'custom' + (nInt + 1).toString();
            var customNPlusOne = 'custom' + (nInt + 1).toString();
            if (nInt === 50 ||
                settings.hasOwnProperty(nextPropName) && !settings[nextPropName].hasOwnProperty('field_type') ||
                settings.hasOwnProperty(nextPropName) && settings[nextPropName].hasOwnProperty('field_type') && settings[nextPropName].field_type !== 'checkbox' ||
                settings.hasOwnProperty(nextPropName) && settings[nextPropName].hasOwnProperty('field_type') && settings[nextPropName].field_type === 'checkbox' && !(settings[propName].checkbox.align.indexOf('float') >= 0 && settings[nextPropName].checkbox.align.indexOf('float') >= 0)) {
                form_ele.append("<div style='float:none;clear:both;height:1px;width:" + settings[pref + 'form'].width + "px;' id='" + pref + "form_input_" + customN + "_checkbox_float_clear' class='checkbox_float_clear'></div>");
                //logger('Appended ' + pref + "form_input_" + customN + "_checkbox_float_clear");
            } else {
                //logger('Did not append checkbox float clear: nextPropName ==> ' + nextPropName);
            }

            $("#" + pref + "form_input_" + customN).keypress(function(e) {
                if ((e.keyCode ? e.keyCode : e.which) == 13) {
                    $(this).trigger('click');
                }
            });

            $("#" + pref + "form_input_" + customN).change(function() {
                if (this.checked) {
                    $(this).attr('checked', 'checked');
                } else {
                    $(this).removeAttr('checked');
                }
            });

        } else if (settings[propName].field_type == 'hidden') {
            form_ele.append("<input type='hidden' id='" + pref + "form_input_" + customN + "' class='" + pref + "form_inputs' />");
            if (settings[propName]['default']) {
                $('#' + pref + 'form_input_' + customN).val(settings[propName]['default']);
            }
        }

        if (!settings[propName].hasOwnProperty('field_type') || settings[propName].field_type !== 'hidden') {
            if (settings[propName].require && settings[pref + 'labels'].required.text.length > 0) {
                $('#' + pref + 'form_label_' + customN + '_required').text(settings[pref + 'labels'].required.text);
            }

            if (settings[pref + 'labels'].position == 'left') {
                $('#' + pref + 'form_label_' + customN).addClass(pref + 'form_labels_left');
                $('#' + pref + 'form_input_' + customN + '_wrapper').addClass(pref + 'form_spacing');
            } else if (settings[pref + 'labels'].position == 'above') {
                $('#' + pref + 'form_label_' + customN).addClass(pref + 'form_labels_above');
                if (isNullOrWhitespace(settings[propName].label)) {
                    $('#' + pref + 'form_label_' + customN).css({
                        'height': '0px'
                    });
                }
            } else if (settings[propName].hasOwnProperty('hide_label') && settings[propName].hide_label === 'show') {
                $('#' + pref + 'form_label_' + customN).addClass(pref + 'form_labels_above');
                if (isNullOrWhitespace(settings[propName].label)) {
                    $('#' + pref + 'form_label_' + customN).css({
                        'height': '0px'
                    });
                }
            } else {
                $('#' + pref + 'form_label_' + customN).addClass(pref + 'form_labels_hide');
                $('#' + pref + 'form_input_' + customN + '_wrapper').addClass(pref + 'form_spacing');
            }

            //Help Text
            if (settings[propName].display_help) {
                $('#' + pref + 'form_input_' + customN + '_help').text(settings[propName].help);
            } else {
                $('#' + pref + 'form_input_' + customN + '_help').hide();
            }

            //Hover State
            if (!IS_MOBILE) {
                $('#' + pref + 'form_input_' + customN).hover(function() {
                    $(this).addClass(pref + "form_inputs_hover");
                }, function() {
                    $(this).removeClass(pref + "form_inputs_hover");
                });
            }

            //Focus State
            $('#' + pref + 'form_input_' + customN).focus(function() {
                $(this).addClass(pref + "form_inputs_focus");
            }).blur(function() {
                $(this).removeClass(pref + "form_inputs_focus");
            });

            if (!settings[propName].hasOwnProperty('field_type') || settings[propName].field_type == 'textbox' || settings[propName].field_type == 'dropdown') {
                //Hit Enter Key
                $('#' + pref + 'form_input_' + customN).keypress(function(e) {
                    if (e.which == 13) {
                        e.preventDefault();
                        processSubmit(pref, false, false, true);
                    }
                });
            }
        }
    } else if (settings.hasOwnProperty(propName)) {
        form_ele.append("<input type='hidden' id='" + pref + "form_input_" + customN + "' class='" + pref + "form_inputs' />");
    }

    if ($('#' + pref + 'form_input_' + customN).length && settings[propName].hasOwnProperty('metadata_kvps')) {
        for (var k = 0; k < settings[propName].metadata_kvps.length; k++) {
            if (settings[propName].metadata_kvps[k].k && settings[propName].metadata_kvps[k].v) {
                trySetAttribute(pref + "form_input_" + customN, settings[propName].metadata_kvps[k]);
            }
        }
    }
}

Date.prototype.addDays = function(days) {
    var dat = new Date(this.valueOf());
    dat.setDate(dat.getDate() + days);
    return dat;
}

function initDatepicker(pref, propName, customN) {
    try {
        if (!IsDatepickerScriptLoaded) {
            if (!IsDatepickerScriptLoading) {
                IsDatepickerScriptLoading = true;

                var themeUrl = '';
                if (settings[propName].datepicker.theme) {
                    if (settings[propName].datepicker.theme === 'dark') {
                        themeUrl = 'https://www.lightboxcdn.com/static/pikaday_dark.css';
                    }
                }

                var h = document.head || document.getElementsByTagName('head')[0];
                var b = document.getElementsByTagName('body')[0];

                var l = document.createElement('link');
                l.type = 'text/css';
                l.rel = 'stylesheet';
                l.media = 'screen';
                l.href = 'https://www.lightboxcdn.com/static/pikaday.css'; // + '?cb=' + new Date().getTime();
                h.appendChild(l);

                if (themeUrl) {
                    var lt = document.createElement('link');
                    lt.type = 'text/css';
                    lt.rel = 'stylesheet';
                    lt.media = 'screen';
                    lt.href = themeUrl; // + '?cb=' + new Date().getTime();
                    h.appendChild(lt);
                }

                var s = document.createElement("script");
                s.type = "text/javascript";
                s.src = 'https://www.lightboxcdn.com/static/pikaday.js';
                h.appendChild(s);
            }

            if (typeof Pikaday !== 'undefined') {
                IsDatepickerScriptLoaded = true;
                initDatepicker(pref, propName, customN);
            } else {
                setTimeout(function() {
                    initDatepicker(pref, propName, customN);
                }, 50);
            }
        } else {

            var dp = settings[propName].datepicker;

            var region = '';
            var splitChar = '';
            var format = 'MM/DD/YYYY';

            if (!isNullOrWhiteSpace(dp.format) && (dp.format.indexOf('/') > 0 || dp.format.indexOf('-') > 0 || dp.format.indexOf('.') > 0 || dp.format.indexOf(',') > 0 || dp.format.indexOf(' ') > 0)) {
                format = dp.format.trim().toUpperCase();
            }

            if (format.indexOf('/') > 0)
                splitChar = '/';
            else if (format.indexOf('-') > 0)
                splitChar = '-';
            else if (format.indexOf('.') > 0)
                splitChar = '.';
            else if (format.indexOf(',') > 0)
                splitChar = ',';
            else if (format.indexOf('_') > 0)
                splitChar = '_';
            else if (format.indexOf('|') > 0)
                splitChar = '|';
            else if (format.indexOf(' ') > 0)
                splitChar = ' ';

            //https://github.com/dbushell/Pikaday
            //**See ==> Internationalization
            //if (dp.region && !isNullOrWhiteSpace(dp.region)) {
            //    region = dp.region.trim();
            //}

            var picker = new Pikaday({
                field: document.getElementById(pref + "form_input_" + customN),
                //format: format,
                //minDate: new Date().addDays(min),
                //maxDate: new Date().addDays(max),
                //showMonthAfterYear: true,
                yearRange: [1900, 2050],
                toString: function(date, formatInternal) {
                    try {
                        var day = date.getDate();
                        var month = date.getMonth() + 1;
                        var year = date.getFullYear();

                        var strOut = '';
                        var formatParts = format.split(splitChar);
                        for (var i = 0; i < formatParts.length; i++) {
                            if (formatParts[i].indexOf('D') >= 0) {
                                strOut += day + splitChar;
                            } else if (formatParts[i].indexOf('M') >= 0) {
                                strOut += month + splitChar;
                            } else if (formatParts[i].indexOf('Y') >= 0) {
                                strOut += year + splitChar;
                            }
                        }

                        if (strOut) {
                            strOut = strOut.substr(0, strOut.length - 1);
                        }

                        //logger('Pikaday.toString = ' + strOut);

                        return strOut;
                    } catch (e) {
                        BOX_CUSTOM_JS.logError(e, 'initDatepicker_1');
                        var td = new Date();
                        return (td.getMonth() + 1) + splitChar + (td.getDate()) + splitChar + (td.getFullYear());
                    }
                },
                parse: function(dateString, formatInternal) {
                    try {
                        var dateParts = dateString.split(splitChar);
                        var formatParts = format.split(splitChar);

                        if (dateParts.length !== formatParts.length || dateParts.length === 0) {
                            return new Date();
                        }

                        var day = -1;
                        var month = -1;
                        var year = -1;

                        for (var i = 0; i < formatParts.length; i++) {
                            if (formatParts[i].indexOf('D') >= 0) {
                                day = parseInt(dateParts[i], 10);
                            } else if (formatParts[i].indexOf('M') >= 0) {
                                month = parseInt(dateParts[i] - 1, 10);
                            } else if (formatParts[i].indexOf('Y') >= 0) {
                                year = parseInt(dateParts[i], 10);
                            }
                        }

                        if (day === -1 || month === -1 || year === -1) {
                            return new Date();
                        }

                        var thedate = new Date(year, month, day);

                        //logger('Pikaday.parse = ' + ((thedate.getMonth() + 1) + splitChar + (thedate.getDate()) + splitChar + (thedate.getFullYear())));

                        return thedate;
                    } catch (e) {
                        BOX_CUSTOM_JS.logError(e, 'initDatepicker_2');
                        return new Date();
                    }
                },
                onSelect: function() {
                    //console.log(this.getDate());
                    parent.DIGIOH_API.log(this.toString(format));
                }
            });


            //var min = 0;
            //var max = 0;
            //var useMin = true;
            //var useMax = true;

            //if (!isNullOrWhiteSpace(dp.min)) {
            //    try {
            //        min = parseInt(dp.min.trim());
            //    }
            //    catch (e) {
            //        min = 0;
            //        useMin = false;
            //    }
            //}

            //if (!isNullOrWhiteSpace(dp.max)) {
            //    try {
            //        max = parseInt(dp.max.trim());
            //    }
            //    catch (e) {
            //        max = 0;
            //        useMax = false;
            //    }
            //}

            //if (max < min || (min == 0 && max == 0)) {
            //    useMin = false;
            //    useMax = false;
            //}

            //if (useMin) {
            //    var minDate = new Date().addDays(min);
            //    picker.setMinDate(minDate);
            //}

            //if (useMax) {
            //    var maxDate = new Date().addDays(max);
            //    picker.setMaxDate(maxDate);
            //}

            //Set the current selection. This will be restricted within the bounds of minDate and maxDate options if they're specified. 
            //You can optionally pass a boolean as the second parameter to prevent triggering of the onSelect callback (true), allowing the date to be set silently.
            if (!isNullOrWhiteSpace(settings[propName]['default'])) {
                var df = settings[propName]['default'].trim();
                if (df && (df.indexOf('/') > 0 || df.indexOf('-') > 0 || df.indexOf('.') > 0 || df.indexOf(',') > 0 || df.indexOf(' ') > 0)) {
                    picker.setDate(df, true);
                }
            }

            //Returns the selected date in a string format.
            //var selectedDateStr = picker.toString(format);

            //Returns a basic JavaScript Date object of the selected day, or null if no selection.
            //var selectedDate = picker.getDate();

        }
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'initDatepicker_3');
    }
}

function logger(msg, isJson) {
    parent.DIGIOH_API.log(msg, 'JS_BOXES_INTERNAL');
}




CJSAPPS_ARR = [];

CJSAPPS_BOXES = {};




CUSTOM_JS_GUIDS_ARR = ['51988623-9352-40cd-879b-26f45213ac1a', 'f9770af9-b63f-4318-ba11-30c37681e716', '4755a0af-3d19-441d-a594-bb42ccacbb48', '68030790-e31e-46a2-89ca-6d998b12b38d', '65dc3af7-f800-4304-b532-e3796460a9b3', '6e5cf285-b31c-4c36-9abd-a4f7666aab77'];

CUSTOM_JS_BOX_EMBED = {};
CUSTOM_JS_BOX_EMBED['51988623-9352-40cd-879b-26f45213ac1a'] = {};
CUSTOM_JS_BOX_EMBED['51988623-9352-40cd-879b-26f45213ac1a'].trigger = 'After Display';
CUSTOM_JS_BOX_EMBED['51988623-9352-40cd-879b-26f45213ac1a'].include_filter = '193496';
CUSTOM_JS_BOX_EMBED['51988623-9352-40cd-879b-26f45213ac1a'].exclude_filter = '';
CUSTOM_JS_BOX_EMBED['51988623-9352-40cd-879b-26f45213ac1a'].include_exclude_function = '';
CUSTOM_JS_BOX_EMBED['51988623-9352-40cd-879b-26f45213ac1a'].code = function(api, s, x) {
    var console = {};
    console.log = BOX_CUSTOM_JS.log;
    try {
        function copyToClipboard(elem) {
            // create hidden text element, if it doesn't already exist
            var targetId = "_hiddenCopyText_";
            var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA";
            var origSelectionStart, origSelectionEnd;
            if (isInput) {
                // can just use the original source element for the selection and copy
                target = elem;
                origSelectionStart = elem.selectionStart;
                origSelectionEnd = elem.selectionEnd;
            } else {
                // must use a temporary form element for the selection and copy
                target = document.getElementById(targetId);
                if (!target) {
                    var target = document.createElement("textarea");
                    target.style.position = "absolute";
                    target.style.left = "-9999px";
                    target.style.top = "0";
                    target.id = targetId;
                    document.body.appendChild(target);
                }
                target.textContent = elem.textContent;
            }
            // select the content
            var currentFocus = document.activeElement;
            target.focus();
            target.setSelectionRange(0, target.value.length);

            // copy the selection
            var succeed;
            try {
                succeed = document.execCommand("copy");
            } catch (e) {
                succeed = false;
            }
            // restore original focus
            if (currentFocus && typeof currentFocus.focus === "function") {
                currentFocus.focus();
            }

            if (isInput) {
                // restore prior selection
                elem.setSelectionRange(origSelectionStart, origSelectionEnd);
            } else {
                // clear temporary content
                target.textContent = "";
            }
            return succeed;
        }


        var couponElement = document.getElementById('thxtext2');
        var couponText = couponElement.innerText;

        $("#thxtext2").click(function() {
            copyToClipboard(couponElement);
            couponElement.innerText = "Copied";
            setTimeout(function() {
                couponElement.innerText = couponText;
            }, 1000);
        });

    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'custom_js_boxes');
        e.message = 'DIGIOH: Custom JS Boxes #1076 -- ' + e.message;
        window.console.error(e);
        return true;
    }
};
CUSTOM_JS_BOX_EMBED['f9770af9-b63f-4318-ba11-30c37681e716'] = {};
CUSTOM_JS_BOX_EMBED['f9770af9-b63f-4318-ba11-30c37681e716'].trigger = 'After Display';
CUSTOM_JS_BOX_EMBED['f9770af9-b63f-4318-ba11-30c37681e716'].include_filter = '194042';
CUSTOM_JS_BOX_EMBED['f9770af9-b63f-4318-ba11-30c37681e716'].exclude_filter = '';
CUSTOM_JS_BOX_EMBED['f9770af9-b63f-4318-ba11-30c37681e716'].include_exclude_function = '';
CUSTOM_JS_BOX_EMBED['f9770af9-b63f-4318-ba11-30c37681e716'].code = function(api, s, x) {
    var console = {};
    console.log = BOX_CUSTOM_JS.log;
    try {
        function copyToClipboard(elem) {
            // create hidden text element, if it doesn't already exist
            var targetId = "_hiddenCopyText_";
            var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA";
            var origSelectionStart, origSelectionEnd;
            if (isInput) {
                // can just use the original source element for the selection and copy
                target = elem;
                origSelectionStart = elem.selectionStart;
                origSelectionEnd = elem.selectionEnd;
            } else {
                // must use a temporary form element for the selection and copy
                target = document.getElementById(targetId);
                if (!target) {
                    var target = document.createElement("textarea");
                    target.style.position = "absolute";
                    target.style.left = "-9999px";
                    target.style.top = "0";
                    target.id = targetId;
                    document.body.appendChild(target);
                }
                target.textContent = elem.textContent;
            }
            // select the content
            var currentFocus = document.activeElement;
            target.focus();
            target.setSelectionRange(0, target.value.length);

            // copy the selection
            var succeed;
            try {
                succeed = document.execCommand("copy");
            } catch (e) {
                succeed = false;
            }
            // restore original focus
            if (currentFocus && typeof currentFocus.focus === "function") {
                currentFocus.focus();
            }

            if (isInput) {
                // restore prior selection
                elem.setSelectionRange(origSelectionStart, origSelectionEnd);
            } else {
                // clear temporary content
                target.textContent = "";
            }
            return succeed;
        }


        var couponElement = document.getElementById('text3');
        var couponText = couponElement.innerText;

        $("#text3").click(function() {
            copyToClipboard(couponElement);
            couponElement.innerText = "Copied";
            setTimeout(function() {
                couponElement.innerText = couponText;
            }, 1000);
        });

    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'custom_js_boxes');
        e.message = 'DIGIOH: Custom JS Boxes #1077 -- ' + e.message;
        window.console.error(e);
        return true;
    }
};
CUSTOM_JS_BOX_EMBED['4755a0af-3d19-441d-a594-bb42ccacbb48'] = {};
CUSTOM_JS_BOX_EMBED['4755a0af-3d19-441d-a594-bb42ccacbb48'].trigger = 'After Display';
CUSTOM_JS_BOX_EMBED['4755a0af-3d19-441d-a594-bb42ccacbb48'].include_filter = '';
CUSTOM_JS_BOX_EMBED['4755a0af-3d19-441d-a594-bb42ccacbb48'].exclude_filter = '';
CUSTOM_JS_BOX_EMBED['4755a0af-3d19-441d-a594-bb42ccacbb48'].include_exclude_function = '';
CUSTOM_JS_BOX_EMBED['4755a0af-3d19-441d-a594-bb42ccacbb48'].code = function(api, s, x) {
    var console = {};
    console.log = BOX_CUSTOM_JS.log;
    try {
        api.GA.logDisplay(s);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'custom_js_boxes');
        e.message = 'DIGIOH: Custom JS Boxes #2097 -- ' + e.message;
        window.console.error(e);
        return true;
    }
};
CUSTOM_JS_BOX_EMBED['68030790-e31e-46a2-89ca-6d998b12b38d'] = {};
CUSTOM_JS_BOX_EMBED['68030790-e31e-46a2-89ca-6d998b12b38d'].trigger = 'After Submit';
CUSTOM_JS_BOX_EMBED['68030790-e31e-46a2-89ca-6d998b12b38d'].include_filter = '';
CUSTOM_JS_BOX_EMBED['68030790-e31e-46a2-89ca-6d998b12b38d'].exclude_filter = '';
CUSTOM_JS_BOX_EMBED['68030790-e31e-46a2-89ca-6d998b12b38d'].include_exclude_function = '';
CUSTOM_JS_BOX_EMBED['68030790-e31e-46a2-89ca-6d998b12b38d'].code = function(api, s, x) {
    var console = {};
    console.log = BOX_CUSTOM_JS.log;
    try {
        api.GA.logSubmit(s);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'custom_js_boxes');
        e.message = 'DIGIOH: Custom JS Boxes #2098 -- ' + e.message;
        window.console.error(e);
        return true;
    }
};
CUSTOM_JS_BOX_EMBED['65dc3af7-f800-4304-b532-e3796460a9b3'] = {};
CUSTOM_JS_BOX_EMBED['65dc3af7-f800-4304-b532-e3796460a9b3'].trigger = 'After Redirect';
CUSTOM_JS_BOX_EMBED['65dc3af7-f800-4304-b532-e3796460a9b3'].include_filter = '';
CUSTOM_JS_BOX_EMBED['65dc3af7-f800-4304-b532-e3796460a9b3'].exclude_filter = '';
CUSTOM_JS_BOX_EMBED['65dc3af7-f800-4304-b532-e3796460a9b3'].include_exclude_function = '';
CUSTOM_JS_BOX_EMBED['65dc3af7-f800-4304-b532-e3796460a9b3'].code = function(api, s, x) {
    var console = {};
    console.log = BOX_CUSTOM_JS.log;
    try {
        api.GA.logRedirect(s);
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'custom_js_boxes');
        e.message = 'DIGIOH: Custom JS Boxes #2099 -- ' + e.message;
        window.console.error(e);
        return true;
    }
};
CUSTOM_JS_BOX_EMBED['6e5cf285-b31c-4c36-9abd-a4f7666aab77'] = {};
CUSTOM_JS_BOX_EMBED['6e5cf285-b31c-4c36-9abd-a4f7666aab77'].trigger = 'After Submit';
CUSTOM_JS_BOX_EMBED['6e5cf285-b31c-4c36-9abd-a4f7666aab77'].include_filter = '204282';
CUSTOM_JS_BOX_EMBED['6e5cf285-b31c-4c36-9abd-a4f7666aab77'].exclude_filter = '';
CUSTOM_JS_BOX_EMBED['6e5cf285-b31c-4c36-9abd-a4f7666aab77'].include_exclude_function = '';
CUSTOM_JS_BOX_EMBED['6e5cf285-b31c-4c36-9abd-a4f7666aab77'].code = function(api, s, x) {
    var console = {};
    console.log = BOX_CUSTOM_JS.log;
    try {
        const options = {
            method: 'POST',
            headers: {
                Accept: 'text/html',
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                data: `{"token": "R7R52E", "event": "Submitted Survey", "customer_properties": {"$email": "${$("#form_input_custom1").val()}"}, "properties": {"item_name": "Wooden Toy","$value": 32}}`
            })
        };

        fetch('https://a.klaviyo.com/api/track', options)
            .then(response => response.json())
            .then(response => console.log(response))
            .catch(err => console.error(err));


    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'custom_js_boxes');
        e.message = 'DIGIOH: Custom JS Boxes #6401 -- ' + e.message;
        window.console.error(e);
        return true;
    }
};




function getCustomJsGuidsToRun(event_trigger, params_obj) {
    var customJsGuidsToRun = [];

    for (var i = 0; i < CUSTOM_JS_GUIDS_ARR.length; i++) {
        if (CUSTOM_JS_BOX_EMBED.hasOwnProperty(CUSTOM_JS_GUIDS_ARR[i]) && CUSTOM_JS_BOX_EMBED[CUSTOM_JS_GUIDS_ARR[i]].trigger === event_trigger) {

            var skip_exclude_filter = false;
            var skip_include_exclude_function = false;

            var ev = CUSTOM_JS_BOX_EMBED[CUSTOM_JS_GUIDS_ARR[i]];

            //Check Include Filter
            //If it is empty, all Boxes will be included, and we will then check against the Exclude Filter and Include/Exclude Function. 
            //If it is not empty, only run for Boxes listed, and also SKIP Exclude Filter and Include/Exclude Function.
            if (typeof ev.include_filter === 'string' && ev.include_filter.trim().length > 0) {
                var include_filter_parts = ev.include_filter.split(',');
                if (include_filter_parts.length > 0) {
                    skip_exclude_filter = true;
                    skip_include_exclude_function = true;
                    for (var j = 0; j < include_filter_parts.length; j++) {
                        if (IS_VARIATION && VARIATION_GUID.trim().toLowerCase() === include_filter_parts[j].trim().toLowerCase() && $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                            customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
                        } else if (IS_VARIATION && VARIATION_SHORT_ID.trim().toLowerCase() === include_filter_parts[j].trim().toLowerCase() && $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                            customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
                        } else if (LIGHTBOX_GUID.trim().toLowerCase() === include_filter_parts[j].trim().toLowerCase() && $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                            customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
                        } else if (LIGHTBOX_SHORT_ID.trim().toLowerCase() === include_filter_parts[j].trim().toLowerCase() && $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                            customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
                        }
                    }
                } else if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                    customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
                }
            } else if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
            }

            //Check Exclude Filter
            //If it is empty, continue on to check against the Include/Exclude Function. 
            //If it is not empty, and it contains this Box, then don't run this function, and skip the Include/Exclude Function. 
            //If it is not empty, and it does not contain this Box, then continue on to check against the Include/Exclude Function. 
            if (!skip_exclude_filter && typeof ev.exclude_filter === 'string' && ev.exclude_filter.trim().length > 0) {
                var exclude_filter_parts = ev.exclude_filter.split(',');
                if (exclude_filter_parts.length > 0) {
                    for (var j = 0; j < exclude_filter_parts.length; j++) {
                        if (IS_VARIATION && VARIATION_GUID.trim().toLowerCase() === exclude_filter_parts[j].trim().toLowerCase()) {
                            if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) !== -1) {
                                var index = $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun);
                                customJsGuidsToRun.splice(index, 1);
                            }
                            skip_include_exclude_function = true;
                            break;
                        } else if (IS_VARIATION && VARIATION_SHORT_ID.trim().toLowerCase() === exclude_filter_parts[j].trim().toLowerCase()) {
                            if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) !== -1) {
                                var index = $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun);
                                customJsGuidsToRun.splice(index, 1);
                            }
                            skip_include_exclude_function = true;
                            break;
                        } else if (LIGHTBOX_GUID.trim().toLowerCase() === exclude_filter_parts[j].trim().toLowerCase()) {
                            if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) !== -1) {
                                var index = $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun);
                                customJsGuidsToRun.splice(index, 1);
                            }
                            skip_include_exclude_function = true;
                            break;
                        } else if (LIGHTBOX_SHORT_ID.trim().toLowerCase() === exclude_filter_parts[j].trim().toLowerCase()) {
                            if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) !== -1) {
                                var index = $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun);
                                customJsGuidsToRun.splice(index, 1);
                            }
                            skip_include_exclude_function = true;
                            break;
                        }
                    }
                }
            }

            //Check Include/Exclude Function
            if (!skip_include_exclude_function && typeof ev.include_exclude_function === 'function') {
                var ief_res = ev.include_exclude_function(parent.DIGIOH_API, STANDARD_OBJ, params_obj);
                if (typeof ief_res === 'boolean' && ief_res === true) {
                    if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                        customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
                    }
                } else {
                    if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) !== -1) {
                        var index = $.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun);
                        customJsGuidsToRun.splice(index, 1);
                    }
                }
            } else if (!skip_include_exclude_function && typeof ev.include_exclude_function !== 'function') {
                if ($.inArray(CUSTOM_JS_GUIDS_ARR[i], customJsGuidsToRun) === -1) {
                    customJsGuidsToRun.push(CUSTOM_JS_GUIDS_ARR[i]);
                }
            }
        }
    }

    if (customJsGuidsToRun.length > 0) {
        //logger('(BOX #' + LIGHTBOX_SHORT_ID + ') - getCustomJsGuidsToRun(' + event_trigger + ')');
        //logger(customJsGuidsToRun);
    }

    return customJsGuidsToRun;
}

function mergeObjectData(obj1, obj2) {
    var obj3 = {};
    for (var attrname in obj1) {
        obj3[attrname] = obj1[attrname];
    }
    for (var attrname in obj2) {
        obj3[attrname] = obj2[attrname];
    }
    return obj3;
}


function calculateCustomJsResponses(res, res_final, calling_fctn_name) {
    if (typeof res === 'undefined' || res === null) {
        if (res_final === 'temp') {
            res_final = true;
        }
    } else if (typeof res === 'boolean') {
        if (res === false && (calling_fctn_name == 'runCustomJsBeforeFormValidation' || calling_fctn_name == 'runCustomJsAfterFormValidation' || calling_fctn_name == 'runCustomJsBeforeSubmit' || calling_fctn_name == 'runCustomJsAfterSubmit')) {
            res_final = 'short_circuit_break';
        } else if (res_final === 'temp') {
            res_final = res;
        } else if (typeof res_final === 'boolean' || typeof res_final === 'number') {
            res_final = res_final && res;
        }
    } else if (typeof res === 'number') {
        if (res_final === 'temp') {
            res_final = res;
        } else if (typeof res_final === 'number') {
            res_final += res;
        }
    } else if (typeof res === 'string') {
        if (res_final === 'temp' || typeof res_final !== 'string') {
            res_final = res;
        } else {
            res_final += res;
        }
    } else if (typeof res === 'object') {
        if (res_final === 'temp') {
            res_final = res;
        } else if (typeof res_final === 'object') {
            res_final = mergeObjectData(res_final, res);
        }
    }

    return res_final;
}


function runCustomJsSnippetsSync(calling_fctn_name, cjs_apps_trigger, custom_js_guids_to_run, params_obj, return_type) {
    var res_final = 'temp';

    try {
        if (typeof CJSAPPS_BOXES !== 'undefined' && CJSAPPS_BOXES !== null && typeof CJSAPPS_ARR !== 'undefined' && CJSAPPS_ARR !== null && CJSAPPS_ARR.length > 0) {
            for (var i = 0; i < CJSAPPS_ARR.length; i++) {
                var appId = CJSAPPS_ARR[i];
                if (CJSAPPS_BOXES.hasOwnProperty(appId) && CJSAPPS_BOXES[appId].hasOwnProperty(cjs_apps_trigger) && typeof CJSAPPS_BOXES[appId][cjs_apps_trigger] === 'function') {
                    logger('RUNNER: runCustomJsSnippetsSync(LINKED APP #' + appId + ' - ' + cjs_apps_trigger + ', ' + return_type + ', BOX_ID=' + boxapi.getId() + ')');

                    if (return_type === 'void' || return_type === '') {
                        CJSAPPS_BOXES[appId][cjs_apps_trigger](parent.DIGIOH_API, STANDARD_OBJ, params_obj);
                    } else {
                        var res = CJSAPPS_BOXES[appId][cjs_apps_trigger](parent.DIGIOH_API, STANDARD_OBJ, params_obj);
                        res_final = calculateCustomJsResponses(res, res_final, calling_fctn_name);

                        if (typeof res_final === 'string' && res_final === 'short_circuit_break') {
                            return false;
                        }
                    }
                }
            }
        }

        if (custom_js_guids_to_run.length > 0) {
            for (var i = 0; i < custom_js_guids_to_run.length; i++) {
                if (typeof CUSTOM_JS_BOX_EMBED[custom_js_guids_to_run[i]].code === 'function') {
                    logger('RUNNER: runCustomJsSnippetsSync(' + calling_fctn_name + ', ' + return_type + ')');

                    if (return_type === 'void' || return_type === '') {
                        CUSTOM_JS_BOX_EMBED[custom_js_guids_to_run[i]].code(parent.DIGIOH_API, STANDARD_OBJ, params_obj);
                    } else {
                        var res = CUSTOM_JS_BOX_EMBED[custom_js_guids_to_run[i]].code(parent.DIGIOH_API, STANDARD_OBJ, params_obj);
                        res_final = calculateCustomJsResponses(res, res_final, calling_fctn_name);

                        if (typeof res_final === 'string' && res_final === 'short_circuit_break') {
                            return false;
                        }
                    }
                }
            }
        }

        if (res_final === 'temp') return;
        else if (return_type === 'void' || return_type === '') return;
        else if (return_type.indexOf(typeof res_final) === -1) return;
        else return res_final;
    } catch (e) {
        BOX_CUSTOM_JS.logError(e, 'runCustomJsSnippetsSync');

        if (res_final === 'temp') return;
        else if (return_type === 'void' || return_type === '') return;
        else if (return_type.indexOf(typeof res_final) === -1) return;
        else return res_final;
    }
}



//function runCustomJsGuidsSync(calling_fctn_name, custom_js_guids_to_run, params_obj, return_type) {
//    var res_final = 'temp';

//    try {
//        if (custom_js_guids_to_run.length > 0) {
//            for (var i = 0; i < custom_js_guids_to_run.length; i++) {
//                if (typeof CUSTOM_JS_BOX_EMBED[custom_js_guids_to_run[i]].code === 'function') {
//                    logger('RUNNER: runCustomJsGuidsSync(' + calling_fctn_name + ', ' + return_type + ')');

//                    if (return_type === 'void' || return_type === '') {
//                        CUSTOM_JS_BOX_EMBED[custom_js_guids_to_run[i]].code(parent.DIGIOH_API, STANDARD_OBJ, params_obj);
//                    } else {
//                        var res = CUSTOM_JS_BOX_EMBED[custom_js_guids_to_run[i]].code(parent.DIGIOH_API, STANDARD_OBJ, params_obj);
//                        if (typeof res === 'undefined' || res === null) {
//                            if (res_final === 'temp') {
//                                res_final = true;
//                            }
//                        }
//                        else if (typeof res === 'boolean') {
//                            if (res === false && (calling_fctn_name == 'runCustomJsBeforeFormValidation' || calling_fctn_name == 'runCustomJsAfterFormValidation' || calling_fctn_name == 'runCustomJsBeforeSubmit' || calling_fctn_name == 'runCustomJsAfterSubmit')) {
//                                res_final = false;
//                                break;
//                            } if (res_final === 'temp') {
//                                res_final = res;
//                            } else if (typeof res_final === 'boolean' || typeof res_final === 'number') {
//                                res_final = res_final && res;
//                            }
//                        }
//                        else if (typeof res === 'number') {
//                            if (res_final === 'temp') {
//                                res_final = res;
//                            } else if (typeof res_final === 'number') {
//                                res_final += res;
//                            }
//                        }
//                        else if (typeof res === 'string') {
//                            if (res_final === 'temp' || typeof res_final !== 'string') {
//                                res_final = res;
//                            } else {
//                                res_final += res;
//                            }
//                        }
//                        else if (typeof res === 'object') {
//                            if (res_final === 'temp') {
//                                res_final = res;
//                            } else if (typeof res_final === 'object') {
//                                res_final = mergeObjectData(res_final, res);
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        else {
//            return;
//        }

//        if (return_type === 'void' || return_type === '') {
//            return;
//        } else if (return_type.indexOf(typeof res_final) === -1) {
//            return;
//        }
//        return res_final;
//    }
//    catch (e) {
//        BOX_CUSTOM_JS.logError(e, 'runCustomJsGuidsSync');

//        if (return_type === 'void' || return_type === '') {
//            return;
//        } else if (return_type.indexOf(typeof res_final) === -1) {
//            return;
//        }
//        return res_final;
//    }
//}


//BOX_CUSTOM_JS =
//{
//    runCustomJsBeforeDOMReady: function () {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before DOM Ready', {});
//            var res = runCustomJsGuidsSync('runCustomJsBeforeDOMReady', customJsGuidsToRun, {}, 'boolean');
//            return res;
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeDOMReady');
//            return true;
//        }
//    },

//    runCustomJsAfterDOMReady: function () {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After DOM Ready', {});
//            var res = runCustomJsGuidsSync('runCustomJsAfterDOMReady', customJsGuidsToRun, {}, 'boolean');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterDOMReady');
//            return true;
//        }
//    },

//    runCustomJsBeforeDisplay: function () {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Display', {});
//            var res = runCustomJsGuidsSync('runCustomJsBeforeDisplay', customJsGuidsToRun, {}, 'boolean');
//            if (res === false) {
//                //hide lightbox
//            }
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeDisplay');
//            return true;
//        }
//    },

//    runCustomJsAfterDisplay: function () {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Display', {});
//            var res = runCustomJsGuidsSync('runCustomJsAfterDisplay', customJsGuidsToRun, {}, 'boolean');
//            if (res === false) {
//                //hide lightbox
//            }
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterDisplay');
//            return true;
//        }
//    },

//    runCustomJsBeforeFormValidation: function (form) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Form Validation', form);
//            return runCustomJsGuidsSync('runCustomJsBeforeFormValidation', customJsGuidsToRun, form, 'boolean,string,object');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeFormValidation');
//            return true;
//        }
//    },

//    runCustomJsAfterFormValidation: function (form) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Form Validation', form);
//            return runCustomJsGuidsSync('runCustomJsAfterFormValidation', customJsGuidsToRun, form, 'boolean,string,object');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterFormValidation');
//            return true;
//        }
//    },

//    runCustomJsBeforeSubmit: function (form) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Submit', form);
//            return runCustomJsGuidsSync('runCustomJsBeforeSubmit', customJsGuidsToRun, form, 'boolean,string,object');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeSubmit');
//            return true;
//        }
//    },

//    runCustomJsAfterSubmit: function (form) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Submit', form);
//            return runCustomJsGuidsSync('runCustomJsAfterSubmit', customJsGuidsToRun, form, 'boolean');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterSubmit');
//            return true;
//        }
//    },

//    runCustomJsBeforeRedirect: function (element, trigger) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Redirect', { element: element, trigger: trigger });
//            return runCustomJsGuidsSync('runCustomJsBeforeRedirect', customJsGuidsToRun, { element: element, trigger: trigger }, 'boolean');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeRedirect');
//            return true;
//        }
//    },

//    runCustomJsAfterRedirect: function (element, trigger) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Redirect', { element: element, trigger: trigger });
//            return runCustomJsGuidsSync('runCustomJsAfterRedirect', customJsGuidsToRun, { element: element, trigger: trigger }, 'void');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterRedirect');
//            return;
//        }
//    },

//    runCustomJsBeforeDownload: function (page, name, element) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Download', { page: page, name: name, element: element });
//            return runCustomJsGuidsSync('runCustomJsBeforeDownload', customJsGuidsToRun, { page: page, name: name, element: element }, 'boolean');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeDownload');
//            return true;
//        }
//    },

//    runCustomJsAfterDownload: function (page, name, element) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Download', { page: page, name: name, element: element });
//            return runCustomJsGuidsSync('runCustomJsAfterDownload', customJsGuidsToRun, { page: page, name: name, element: element }, 'void');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterDownload');
//            return;
//        }
//    },

//    runCustomJsBeforeOpenAnotherBox: function (target_lightbox_guid, trigger) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Open Another Box', { target_lightbox_guid: target_lightbox_guid, trigger: trigger });
//            return runCustomJsGuidsSync('runCustomJsBeforeOpenAnotherBox', customJsGuidsToRun, { target_lightbox_guid: target_lightbox_guid, trigger: trigger }, 'boolean');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeOpenAnotherBox');
//            return true;
//        }
//    },

//    runCustomJsAfterOpenAnotherBox: function (target_lightbox_guid, trigger) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Open Another Box', { target_lightbox_guid: target_lightbox_guid, trigger: trigger });
//            return runCustomJsGuidsSync('runCustomJsAfterOpenAnotherBox', customJsGuidsToRun, { target_lightbox_guid: target_lightbox_guid, trigger: trigger }, 'void');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterOpenAnotherBox');
//            return;
//        }
//    },

//    runCustomJsBeforeChangePages: function (old_page, new_page, name, element, trigger) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Change Pages', { old_page: old_page, new_page: new_page, name: name, element: element, trigger: trigger });
//            return runCustomJsGuidsSync('runCustomJsBeforeChangePages', customJsGuidsToRun, { old_page: old_page, new_page: new_page, name: name, element: element, trigger: trigger }, 'boolean');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeChangePages');
//            return true;
//        }
//    },

//    runCustomJsAfterChangePages: function (old_page, new_page, name, element, trigger) {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Change Pages', { old_page: old_page, new_page: new_page, name: name, element: element, trigger: trigger });
//            return runCustomJsGuidsSync('runCustomJsAfterChangePages', customJsGuidsToRun, { old_page: old_page, new_page: new_page, name: name, element: element, trigger: trigger }, 'void');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterChangePages');
//            return;
//        }
//    },

//    runCustomJsBeforeClose: function () {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Close', {});
//            var res = runCustomJsGuidsSync('runCustomJsBeforeClose', customJsGuidsToRun, {}, 'void');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeClose');
//            return;
//        }
//    },

//    runCustomJsAfterClose: function () {
//        try {
//            var customJsGuidsToRun = getCustomJsGuidsToRun('After Close', {});
//            var res = runCustomJsGuidsSync('(BOX #' + LIGHTBOX_SHORT_ID + ') - runCustomJsAfterClose', customJsGuidsToRun, {}, 'void');
//        }
//        catch (e) {
//            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterClose');
//            return;
//        }
//    },

//    log: function (msg) {
//        try {
//            parent.DIGIOH_API.log(msg, 'CUSTOM_JS_BOXES (BoxID=' + boxapi.getId() + ')');
//        }
//        catch (e) {
//        }
//    },

//    logError: function (e, msg) {
//        try {
//            parent.DIGIOH_API.log(e.message, 'CUSTOM_JS_BOXES.' + msg + ' (BoxID=' + boxapi.getId() + ')');
//            parent.DIGIOH_API.logErrorFromBox(e, msg);
//        }
//        catch (e) {
//        }
//    }
//};



BOX_CUSTOM_JS = {
    runCustomJsBeforeDOMReady: function() {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before DOM Ready', {});
            var res = runCustomJsSnippetsSync('runCustomJsBeforeDOMReady', 'Before DOM Ready', customJsGuidsToRun, {}, 'boolean');
            return res;
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeDOMReady');
            return true;
        }
    },

    runCustomJsAfterDOMReady: function() {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After DOM Ready', {});
            var res = runCustomJsSnippetsSync('runCustomJsAfterDOMReady', 'After DOM Ready', customJsGuidsToRun, {}, 'boolean');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterDOMReady');
            return true;
        }
    },

    runCustomJsBeforeDisplay: function() {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Display', {});
            var res = runCustomJsSnippetsSync('runCustomJsBeforeDisplay', 'Before Display', customJsGuidsToRun, {}, 'boolean');
            if (res === false) {
                //hide lightbox
            }
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeDisplay');
            return true;
        }
    },

    runCustomJsAfterDisplay: function() {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Display', {});
            var res = runCustomJsSnippetsSync('runCustomJsAfterDisplay', 'After Display', customJsGuidsToRun, {}, 'boolean');
            if (res === false) {
                //hide lightbox
            }
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterDisplay');
            return true;
        }
    },

    runCustomJsBeforeFormValidation: function(form) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Form Validation', form);
            return runCustomJsSnippetsSync('runCustomJsBeforeFormValidation', 'Before Form Validation', customJsGuidsToRun, form, 'boolean,string,object');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeFormValidation');
            return true;
        }
    },

    runCustomJsAfterFormValidation: function(form) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Form Validation', form);
            return runCustomJsSnippetsSync('runCustomJsAfterFormValidation', 'After Form Validation', customJsGuidsToRun, form, 'boolean,string,object');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterFormValidation');
            return true;
        }
    },

    runCustomJsBeforeSubmit: function(form) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Submit', form);
            return runCustomJsSnippetsSync('runCustomJsBeforeSubmit', 'Before Submit', customJsGuidsToRun, form, 'boolean,string,object');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeSubmit');
            return true;
        }
    },

    runCustomJsAfterSubmit: function(form) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Submit', form);
            return runCustomJsSnippetsSync('runCustomJsAfterSubmit', 'After Submit', customJsGuidsToRun, form, 'boolean');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterSubmit');
            return true;
        }
    },

    runCustomJsBeforeRedirect: function(element, trigger) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Redirect', {
                element: element,
                trigger: trigger
            });
            return runCustomJsSnippetsSync('runCustomJsBeforeRedirect', 'Before Redirect', customJsGuidsToRun, {
                element: element,
                trigger: trigger
            }, 'boolean');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeRedirect');
            return true;
        }
    },

    runCustomJsAfterRedirect: function(element, trigger) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Redirect', {
                element: element,
                trigger: trigger
            });
            return runCustomJsSnippetsSync('runCustomJsAfterRedirect', 'After Redirect', customJsGuidsToRun, {
                element: element,
                trigger: trigger
            }, 'void');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterRedirect');
            return;
        }
    },

    runCustomJsBeforeDownload: function(page, name, element) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Download', {
                page: page,
                name: name,
                element: element
            });
            return runCustomJsSnippetsSync('runCustomJsBeforeDownload', 'Before Download', customJsGuidsToRun, {
                page: page,
                name: name,
                element: element
            }, 'boolean');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeDownload');
            return true;
        }
    },

    runCustomJsAfterDownload: function(page, name, element) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Download', {
                page: page,
                name: name,
                element: element
            });
            return runCustomJsSnippetsSync('runCustomJsAfterDownload', 'After Download', customJsGuidsToRun, {
                page: page,
                name: name,
                element: element
            }, 'void');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterDownload');
            return;
        }
    },

    runCustomJsBeforeOpenAnotherBox: function(target_lightbox_guid, trigger) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Open Another Box', {
                target_lightbox_guid: target_lightbox_guid,
                trigger: trigger
            });
            return runCustomJsSnippetsSync('runCustomJsBeforeOpenAnotherBox', 'Before Open Another Box', customJsGuidsToRun, {
                target_lightbox_guid: target_lightbox_guid,
                trigger: trigger
            }, 'boolean');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeOpenAnotherBox');
            return true;
        }
    },

    runCustomJsAfterOpenAnotherBox: function(target_lightbox_guid, trigger) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Open Another Box', {
                target_lightbox_guid: target_lightbox_guid,
                trigger: trigger
            });
            return runCustomJsSnippetsSync('runCustomJsAfterOpenAnotherBox', 'After Open Another Box', customJsGuidsToRun, {
                target_lightbox_guid: target_lightbox_guid,
                trigger: trigger
            }, 'void');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterOpenAnotherBox');
            return;
        }
    },

    runCustomJsBeforeChangePages: function(old_page, new_page, name, element, trigger) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Change Pages', {
                old_page: old_page,
                new_page: new_page,
                name: name,
                element: element,
                trigger: trigger
            });
            return runCustomJsSnippetsSync('runCustomJsBeforeChangePages', 'Before Change Pages', customJsGuidsToRun, {
                old_page: old_page,
                new_page: new_page,
                name: name,
                element: element,
                trigger: trigger
            }, 'boolean');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeChangePages');
            return true;
        }
    },

    runCustomJsAfterChangePages: function(old_page, new_page, name, element, trigger) {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Change Pages', {
                old_page: old_page,
                new_page: new_page,
                name: name,
                element: element,
                trigger: trigger
            });
            return runCustomJsSnippetsSync('runCustomJsAfterChangePages', 'After Change Pages', customJsGuidsToRun, {
                old_page: old_page,
                new_page: new_page,
                name: name,
                element: element,
                trigger: trigger
            }, 'void');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterChangePages');
            return;
        }
    },

    runCustomJsBeforeClose: function() {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('Before Close', {});
            var res = runCustomJsSnippetsSync('runCustomJsBeforeClose', 'Before Close', customJsGuidsToRun, {}, 'void');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsBeforeClose');
            return;
        }
    },

    runCustomJsAfterClose: function() {
        try {
            var customJsGuidsToRun = getCustomJsGuidsToRun('After Close', {});
            var res = runCustomJsSnippetsSync('runCustomJsAfterClose', 'After Close', customJsGuidsToRun, {}, 'void');
            //var res = runCustomJsSnippetsSync('(BOX #' + LIGHTBOX_SHORT_ID + ') - runCustomJsAfterClose', 'After Close', customJsGuidsToRun, {}, 'void');
        } catch (e) {
            BOX_CUSTOM_JS.logError(e, 'runCustomJsAfterClose');
            return;
        }
    },

    log: function(msg) {
        try {
            parent.DIGIOH_API.log(msg, 'CUSTOM_JS_BOXES (BoxID=' + boxapi.getId() + ')');
        } catch (e) {}
    },

    logError: function(e, msg) {
        try {
            parent.DIGIOH_API.log(e.message, 'CUSTOM_JS_BOXES.' + msg + ' (BoxID=' + boxapi.getId() + ')');
            parent.DIGIOH_API.logErrorFromBox(e, msg);
        } catch (e) {}
    }
};


checkJqLoaded();