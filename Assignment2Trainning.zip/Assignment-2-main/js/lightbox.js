(function() {
    if (window.location.href.indexOf('boxqamode') > 0) {
        window.sessionStorage.setItem('xdibx_boxqamode', 1);
    }
    var a = document,
        b = a.createElement('script');
    b.type = 'text/javascript';
    b.async = !0;
    b.src = (a.location.protocol.toString().indexOf('http') === 0 ? '' : 'https:') + '//www.lightboxcdn.com/vendor/4f02cfb8-cb31-44d6-a14e-fc5c5bec2c17/user' + ((window.sessionStorage.getItem('xdibx_boxqamode') == 1) ? '_qa' : '') + '.js?cb=638257214496058059';
    a = a.getElementsByTagName('script')[0];
    a.parentNode.insertBefore(b, a)
})();